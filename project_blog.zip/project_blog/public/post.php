<?php
session_start();
require_once '../config/database.php';

// Ambil ID artikel dari URL
$article_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($article_id == 0) {
    header("Location: index.php");
    exit();
}

// Ambil data artikel
$article_query = "SELECT a.*, c.name as category_name, c.slug as category_slug, 
                         ad.username as author_name, ad.full_name as author_full_name
                  FROM articles a 
                  LEFT JOIN categories c ON a.category_id = c.id 
                  LEFT JOIN admins ad ON a.author_id = ad.id 
                  WHERE a.id = $article_id AND a.is_published = 1";
$article_result = mysqli_query($konek, $article_query);

if (mysqli_num_rows($article_result) == 0) {
    header("Location: index.php");
    exit();
}

$article = mysqli_fetch_assoc($article_result);

// Update view count
mysqli_query($konek, "UPDATE articles SET view_count = view_count + 1 WHERE id = $article_id");

// Ambil komentar artikel
$comments_query = "SELECT c.*, u.username, u.full_name 
                   FROM comments c 
                   JOIN users u ON c.user_id = u.id 
                   WHERE c.article_id = $article_id AND c.parent_id IS NULL 
                   ORDER BY c.created_at DESC";
$comments = mysqli_query($konek, $comments_query);

// Ambil total komentar
$total_comments = mysqli_fetch_assoc(mysqli_query($konek, 
    "SELECT COUNT(*) as total FROM comments WHERE article_id = $article_id"))['total'];

// Cek apakah user sudah like artikel ini
$is_liked = false;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $like_check = mysqli_query($konek, 
        "SELECT * FROM article_likes WHERE article_id = $article_id AND user_id = $user_id");
    $is_liked = mysqli_num_rows($like_check) > 0;
}

// Hitung total likes
$total_likes = mysqli_fetch_assoc(mysqli_query($konek, 
    "SELECT COUNT(*) as total FROM article_likes WHERE article_id = $article_id"))['total'];

// Handle like action
if (isset($_POST['like_action']) && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    
    if ($is_liked) {
        // Unlike
        mysqli_query($konek, "DELETE FROM article_likes WHERE article_id = $article_id AND user_id = $user_id");
        $is_liked = false;
        $total_likes--;
    } else {
        // Like
        mysqli_query($konek, "INSERT INTO article_likes (article_id, user_id) VALUES ($article_id, $user_id)");
        $is_liked = true;
        $total_likes++;
    }
    
    // Redirect untuk menghindari resubmit
    header("Location: post.php?id=$article_id");
    exit();
}

// Handle komentar
if (isset($_POST['submit_comment']) && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $comment_content = mysqli_real_escape_string($konek, $_POST['comment_content']);
    $parent_id = isset($_POST['parent_id']) ? intval($_POST['parent_id']) : 0;
    
    if (!empty($comment_content)) {
        $insert_comment = "INSERT INTO comments (article_id, user_id, parent_id, content) 
                           VALUES ($article_id, $user_id, " . ($parent_id > 0 ? $parent_id : 'NULL') . ", '$comment_content')";
        mysqli_query($konek, $insert_comment);
        
        // Redirect untuk menghindari resubmit
        header("Location: post.php?id=$article_id");
        exit();
    }
}

// Ambil artikel terkait (dalam kategori yang sama)
$related_query = "SELECT * FROM articles 
                  WHERE category_id = {$article['category_id']} 
                  AND id != $article_id 
                  AND is_published = 1 
                  ORDER BY created_at DESC 
                  LIMIT 3";
$related_articles = mysqli_query($konek, $related_query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($article['title']); ?> - Blog</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #f8f9fa;
        }
        .header {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
            text-decoration: none;
            color: white;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .nav-links a:hover {
            background: rgba(255,255,255,0.1);
        }
        .article-header {
            padding: 60px 0 40px;
            text-align: center;
            max-width: 800px;
            margin: 0 auto;
        }
        .category-tag {
            display: inline-block;
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 8px 20px;
            border-radius: 25px;
            font-size: 14px;
            margin-bottom: 20px;
            text-decoration: none;
        }
        .article-title {
            font-size: 2.8em;
            margin-bottom: 20px;
            line-height: 1.2;
        }
        .article-meta {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-top: 25px;
            font-size: 14px;
            opacity: 0.9;
        }
        .meta-item {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .main-content {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 40px;
            padding: 40px 0;
        }
        .article-content {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
        }
        .article-body {
            font-size: 18px;
            line-height: 1.8;
            color: #444;
            margin-bottom: 40px;
        }
        .article-body p {
            margin-bottom: 20px;
        }
        .article-body h2 {
            margin: 30px 0 15px;
            color: #333;
        }
        .article-body img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
            margin: 20px 0;
        }
        .article-actions {
            display: flex;
            gap: 20px;
            margin: 40px 0;
            padding: 20px 0;
            border-top: 1px solid #eee;
            border-bottom: 1px solid #eee;
        }
        .action-btn {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            background: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 5px;
            color: #333;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s;
        }
        .action-btn:hover {
            background: #f093fb;
            color: white;
            border-color: #f093fb;
        }
        .like-btn.liked {
            background: #f5576c;
            color: white;
            border-color: #f5576c;
        }
        .comments-section {
            margin-top: 40px;
        }
        .comments-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }
        .comment-form {
            background: #f8f9fa;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .comment-form textarea {
            width: 100%;
            padding: 15px;
            border: 2px solid #ddd;
            border-radius: 5px;
            font-family: inherit;
            font-size: 16px;
            resize: vertical;
            min-height: 100px;
            margin-bottom: 15px;
        }
        .comment-form button {
            padding: 12px 30px;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
        }
        .comment-list {
            list-style: none;
        }
        .comment-item {
            background: white;
            padding: 25px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .comment-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        .comment-author {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .author-avatar {
            width: 40px;
            height: 40px;
            background: #f093fb;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        .comment-content {
            color: #444;
            line-height: 1.6;
        }
        .comment-date {
            font-size: 12px;
            color: #999;
        }
        .sidebar {
            position: sticky;
            top: 20px;
            height: fit-content;
        }
        .sidebar-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .author-card {
            text-align: center;
        }
        .author-avatar-large {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            font-weight: bold;
            margin: 0 auto 20px;
        }
        .related-articles {
            list-style: none;
        }
        .related-item {
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        .related-item:last-child {
            border-bottom: none;
        }
        .related-link {
            color: #333;
            text-decoration: none;
            font-weight: 500;
            display: block;
            margin-bottom: 5px;
        }
        .related-link:hover {
            color: #f093fb;
        }
        .related-date {
            font-size: 12px;
            color: #999;
        }
        .article-stats {
            display: flex;
            justify-content: space-around;
            text-align: center;
            margin-bottom: 20px;
        }
        .stat-item {
            padding: 15px;
        }
        .stat-number {
            font-size: 24px;
            font-weight: bold;
            color: #f093fb;
            display: block;
        }
        .stat-label {
            font-size: 12px;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .footer {
            background: #333;
            color: white;
            padding: 40px 0;
            margin-top: 60px;
        }
        .copyright {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid #444;
            margin-top: 30px;
            font-size: 14px;
            opacity: 0.7;
        }
        .login-prompt {
            text-align: center;
            padding: 30px;
            background: #f8f9fa;
            border-radius: 10px;
            margin: 20px 0;
        }
        @media (max-width: 768px) {
            .main-content {
                grid-template-columns: 1fr;
            }
            .article-title {
                font-size: 2em;
            }
            .article-meta {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="navbar">
            <a href="index.php" class="logo">MyBlog</a>
            <div class="nav-links">
                <a href="index.php">Beranda</a>
                <a href="article.php">Artikel</a>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="../user/dashboard.php">Dashboard</a>
                    <a href="../user/logout.php">Logout</a>
                <?php else: ?>
                    <a href="../user/login.php">Login</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="article-header">
            <?php if($article['category_name']): ?>
                <a href="article.php?category=<?php echo $article['category_id']; ?>" class="category-tag">
                    <?php echo $article['category_name']; ?>
                </a>
            <?php endif; ?>
            
            <h1 class="article-title"><?php echo htmlspecialchars($article['title']); ?></h1>
            
            <div class="article-meta">
                <div class="meta-item">
                    <span>👤</span>
                    <span><?php echo $article['author_full_name'] ?: $article['author_name']; ?></span>
                </div>
                <div class="meta-item">
                    <span>📅</span>
                    <span><?php echo date('d M Y', strtotime($article['created_at'])); ?></span>
                </div>
                <div class="meta-item">
                    <span>👁️</span>
                    <span><?php echo number_format($article['view_count']); ?> views</span>
                </div>
            </div>
        </div>

        <div class="main-content">
            <div>
                <div class="article-content">
                    <?php if($article['featured_image']): ?>
                        <img src="../uploads/<?php echo $article['featured_image']; ?>" 
                             alt="<?php echo htmlspecialchars($article['title']); ?>">
                    <?php endif; ?>
                    
                    <div class="article-body">
                        <?php echo nl2br(htmlspecialchars($article['content'])); ?>
                    </div>
                    
                    <div class="article-actions">
                        <form method="POST" style="display: inline;">
                            <button type="submit" name="like_action" 
                                    class="action-btn like-btn <?php echo $is_liked ? 'liked' : ''; ?>">
                                <span><?php echo $is_liked ? '❤️' : '🤍'; ?></span>
                                <span>Suka (<?php echo $total_likes; ?>)</span>
                            </button>
                        </form>
                        <a href="#comments" class="action-btn">
                            <span>💬</span>
                            <span>Komentar (<?php echo $total_comments; ?>)</span>
                        </a>
                        <a href="#" class="action-btn">
                            <span>📤</span>
                            <span>Bagikan</span>
                        </a>
                    </div>
                    
                    <div class="comments-section" id="comments">
                        <div class="comments-header">
                            <h2>Komentar (<?php echo $total_comments; ?>)</h2>
                        </div>
                        
                        <?php if(isset($_SESSION['user_id'])): ?>
                            <div class="comment-form">
                                <form method="POST">
                                    <textarea name="comment_content" 
                                              placeholder="Tulis komentar Anda di sini..." 
                                              required></textarea>
                                    <button type="submit" name="submit_comment">Kirim Komentar</button>
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="login-prompt">
                                <p>Silakan <a href="../user/login.php">login</a> untuk menulis komentar.</p>
                            </div>
                        <?php endif; ?>
                        
                        <?php if(mysqli_num_rows($comments) > 0): ?>
                            <ul class="comment-list">
                                <?php while($comment = mysqli_fetch_assoc($comments)): ?>
                                    <li class="comment-item">
                                        <div class="comment-header">
                                            <div class="comment-author">
                                                <div class="author-avatar">
                                                    <?php echo strtoupper(substr($comment['username'], 0, 1)); ?>
                                                </div>
                                                <div>
                                                    <strong><?php echo htmlspecialchars($comment['full_name'] ?: $comment['username']); ?></strong>
                                                    <div class="comment-date">
                                                        <?php echo date('d M Y H:i', strtotime($comment['created_at'])); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="comment-content">
                                            <?php echo nl2br(htmlspecialchars($comment['content'])); ?>
                                        </div>
                                    </li>
                                <?php endwhile; ?>
                            </ul>
                        <?php else: ?>
                            <div style="text-align: center; padding: 40px; color: #666;">
                                <p>Belum ada komentar. Jadilah yang pertama berkomentar!</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="sidebar">
                <div class="sidebar-card author-card">
                    <div class="author-avatar-large">
                        <?php echo strtoupper(substr($article['author_name'], 0, 1)); ?>
                    </div>
                    <h3><?php echo $article['author_full_name'] ?: $article['author_name']; ?></h3>
                    <p>Penulis Artikel</p>
                </div>
                
                <div class="sidebar-card article-stats">
                    <div class="stat-item">
                        <span class="stat-number"><?php echo number_format($article['view_count']); ?></span>
                        <span class="stat-label">Views</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number"><?php echo $total_likes; ?></span>
                        <span class="stat-label">Likes</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number"><?php echo $total_comments; ?></span>
                        <span class="stat-label">Komentar</span>
                    </div>
                </div>
                
                <?php if(mysqli_num_rows($related_articles) > 0): ?>
                    <div class="sidebar-card">
                        <h3>Artikel Terkait</h3>
                        <ul class="related-articles">
                            <?php while($related = mysqli_fetch_assoc($related_articles)): ?>
                                <li class="related-item">
                                    <a href="post.php?id=<?php echo $related['id']; ?>" class="related-link">
                                        <?php echo htmlspecialchars($related['title']); ?>
                                    </a>
                                    <div class="related-date">
                                        <?php echo date('d M Y', strtotime($related['created_at'])); ?>
                                    </div>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="footer">
        <div class="container">
            <div class="copyright">
                © <?php echo date('Y'); ?> MyBlog. Semua hak dilindungi.
            </div>
        </div>
    </div>
</body>
</html>