<?php
session_start();
require_once '../config/database.php';

// Hitung statistik untuk ditampilkan
$total_articles = mysqli_fetch_assoc(mysqli_query($konek, 
    "SELECT COUNT(*) as total FROM articles WHERE is_published = 1"))['total'];

$total_categories = mysqli_fetch_assoc(mysqli_query($konek, 
    "SELECT COUNT(*) as total FROM categories"))['total'];

$total_users = mysqli_fetch_assoc(mysqli_query($konek, 
    "SELECT COUNT(*) as total FROM users"))['total'];

$total_views = mysqli_fetch_assoc(mysqli_query($konek, 
    "SELECT SUM(view_count) as total FROM articles"))['total'];
$total_views = $total_views ?: 0;

// Ambil tim admin
$admins = mysqli_query($konek, "SELECT * FROM admins ORDER BY created_at LIMIT 4");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tentang Kami - Blog</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #f8f9fa;
        }
        .header {
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
            text-decoration: none;
            color: white;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .nav-links a:hover {
            background: rgba(255,255,255,0.1);
        }
        .hero {
            text-align: center;
            padding: 80px 20px;
        }
        .hero h1 {
            font-size: 3.5em;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
        }
        .hero p {
            font-size: 1.2em;
            max-width: 700px;
            margin: 0 auto;
            opacity: 0.9;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 60px 0;
        }
        .stat-card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            font-size: 40px;
            margin-bottom: 15px;
        }
        .stat-number {
            font-size: 36px;
            font-weight: bold;
            color: #43e97b;
            margin: 10px 0;
        }
        .stat-label {
            font-size: 16px;
            color: #666;
        }
        .content-section {
            background: white;
            padding: 60px;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            margin-bottom: 60px;
        }
        .section-title {
            text-align: center;
            font-size: 2.2em;
            margin-bottom: 40px;
            color: #333;
            position: relative;
        }
        .section-title:after {
            content: '';
            display: block;
            width: 80px;
            height: 4px;
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            margin: 15px auto 30px;
            border-radius: 2px;
        }
        .mission-vision {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 40px;
            margin: 40px 0;
        }
        .mission, .vision {
            background: #f8f9fa;
            padding: 30px;
            border-radius: 10px;
            border-left: 5px solid #43e97b;
        }
        .mission h3, .vision h3 {
            color: #43e97b;
            margin-bottom: 15px;
            font-size: 1.4em;
        }
        .team {
            margin-top: 60px;
        }
        .team-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }
        .team-member {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            transition: all 0.3s;
            text-align: center;
        }
        .team-member:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }
        .member-photo {
            height: 200px;
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 60px;
        }
        .member-info {
            padding: 25px;
        }
        .member-name {
            font-size: 1.3em;
            margin-bottom: 5px;
            color: #333;
        }
        .member-role {
            color: #43e97b;
            font-weight: 500;
            margin-bottom: 15px;
            font-size: 14px;
        }
        .member-bio {
            color: #666;
            font-size: 14px;
            line-height: 1.5;
        }
        .values {
            margin-top: 60px;
        }
        .values-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-top: 40px;
        }
        .value-item {
            text-align: center;
            padding: 30px;
            background: #f8f9fa;
            border-radius: 10px;
            transition: all 0.3s;
        }
        .value-item:hover {
            background: white;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .value-icon {
            font-size: 50px;
            margin-bottom: 20px;
            color: #43e97b;
        }
        .value-title {
            font-size: 1.2em;
            margin-bottom: 15px;
            color: #333;
        }
        .footer {
            background: #333;
            color: white;
            padding: 60px 0 30px;
            margin-top: 80px;
        }
        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }
        .footer-section h3 {
            margin-bottom: 20px;
            color: #43e97b;
            font-size: 1.2em;
        }
        .footer-section p {
            opacity: 0.8;
            font-size: 14px;
            line-height: 1.6;
        }
        .footer-links {
            list-style: none;
        }
        .footer-links li {
            margin-bottom: 10px;
        }
        .footer-links a {
            color: white;
            text-decoration: none;
            opacity: 0.8;
            transition: opacity 0.3s;
        }
        .footer-links a:hover {
            opacity: 1;
        }
        .copyright {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid #444;
            font-size: 14px;
            opacity: 0.7;
        }
        .cta-section {
            text-align: center;
            padding: 60px 20px;
            background: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            color: white;
            margin-top: 60px;
            border-radius: 15px;
        }
        .cta-title {
            font-size: 2.5em;
            margin-bottom: 20px;
        }
        .cta-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin-top: 30px;
            flex-wrap: wrap;
        }
        .cta-btn {
            padding: 15px 30px;
            background: white;
            color: #43e97b;
            border: none;
            border-radius: 30px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }
        .cta-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .cta-btn.outline {
            background: transparent;
            border: 2px solid white;
            color: white;
        }
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 2.5em;
            }
            .content-section {
                padding: 30px 20px;
            }
            .cta-buttons {
                flex-direction: column;
                align-items: center;
            }
            .cta-btn {
                width: 100%;
                max-width: 300px;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="navbar">
            <a href="index.php" class="logo">MyBlog</a>
            <div class="nav-links">
                <a href="index.php">Beranda</a>
                <a href="article.php">Artikel</a>
                <a href="search.php">Cari</a>
                <a href="contact.php">Kontak</a>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="../user/dashboard.php">Dashboard</a>
                    <a href="../user/logout.php">Logout</a>
                <?php else: ?>
                    <a href="../user/login.php">Login</a>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="hero">
            <h1>Tentang Kami</h1>
            <p>Menginspirasi dan mengedukasi melalui konten berkualitas sejak 2024</p>
        </div>
    </div>

    <div class="container">
        <div class="stats">
            <div class="stat-card">
                <div class="stat-icon">📝</div>
                <div class="stat-number"><?php echo $total_articles; ?></div>
                <div class="stat-label">Artikel</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">📚</div>
                <div class="stat-number"><?php echo $total_categories; ?></div>
                <div class="stat-label">Kategori</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">👥</div>
                <div class="stat-number"><?php echo $total_users; ?></div>
                <div class="stat-label">Anggota</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">👁️</div>
                <div class="stat-number"><?php echo number_format($total_views); ?></div>
                <div class="stat-label">Total Views</div>
            </div>
        </div>

        <div class="content-section">
            <h2 class="section-title">Siapa Kami</h2>
            <p style="text-align: center; font-size: 18px; color: #666; max-width: 800px; margin: 0 auto 40px;">
                MyBlog adalah platform blog yang didedikasikan untuk berbagi pengetahuan, inspirasi, 
                dan informasi terkini dalam bidang teknologi, pemrograman, desain, dan bisnis.
            </p>
            
            <div class="mission-vision">
                <div class="mission">
                    <h3>Misi Kami</h3>
                    <p>Menyediakan konten berkualitas tinggi yang mengedukasi, menginspirasi, dan memberdayakan 
                       pembaca untuk berkembang dalam bidang teknologi dan digital.</p>
                </div>
                <div class="vision">
                    <h3>Visi Kami</h3>
                    <p>Menjadi platform blog terdepan di Indonesia yang menjadi sumber referensi utama 
                       untuk pembelajaran dan perkembangan skill digital.</p>
                </div>
            </div>

            <div class="values">
                <h2 class="section-title">Nilai-Nilai Kami</h2>
                <div class="values-grid">
                    <div class="value-item">
                        <div class="value-icon">🎯</div>
                        <h3 class="value-title">Kualitas</h3>
                        <p>Setiap artikel ditulis dengan riset mendalam dan penyajian yang akurat.</p>
                    </div>
                    <div class="value-item">
                        <div class="value-icon">🤝</div>
                        <h3 class="value-title">Komunitas</h3>
                        <p>Membangun komunitas pembaca yang saling mendukung dan berbagi pengetahuan.</p>
                    </div>
                    <div class="value-item">
                        <div class="value-icon">🚀</div>
                        <h3 class="value-title">Inovasi</h3>
                        <p>Selalu mengikuti perkembangan terbaru dan tren dalam industri digital.</p>
                    </div>
                    <div class="value-item">
                        <div class="value-icon">💡</div>
                        <h3 class="value-title">Inspirasi</h3>
                        <p>Menginspirasi pembaca untuk belajar, berkembang, dan menciptakan.</p>
                    </div>
                </div>
            </div>

            <div class="team">
                <h2 class="section-title">Tim Kami</h2>
                <div class="team-grid">
                    <?php if(mysqli_num_rows($admins) > 0): ?>
                        <?php while($admin = mysqli_fetch_assoc($admins)): ?>
                            <div class="team-member">
                                <div class="member-photo">
                                    <?php echo strtoupper(substr($admin['username'], 0, 1)); ?>
                                </div>
                                <div class="member-info">
                                    <h3 class="member-name"><?php echo $admin['full_name'] ?: $admin['username']; ?></h3>
                                    <div class="member-role">Penulis & Editor</div>
                                    <p class="member-bio">Ahli dalam bidang teknologi dan konten digital dengan pengalaman bertahun-tahun.</p>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div style="grid-column: 1 / -1; text-align: center; padding: 40px;">
                            <p style="color: #666;">Tim kami sedang berkembang...</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="cta-section">
            <h2 class="cta-title">Bergabunglah dengan Komunitas Kami</h2>
            <p style="font-size: 1.1em; max-width: 600px; margin: 0 auto;">
                Dapatkan akses ke artikel eksklusif, diskusi komunitas, dan konten terbaru 
                seputar teknologi dan perkembangan digital.
            </p>
            
            <div class="cta-buttons">
                <a href="../user/register.php" class="cta-btn">Daftar Sekarang</a>
                <a href="contact.php" class="cta-btn outline">Hubungi Kami</a>
            </div>
        </div>
    </div>

    <div class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>MyBlog</h3>
                    <p>Platform berbagi pengetahuan dan inspirasi melalui artikel-artikel berkualitas tentang teknologi, pemrograman, desain, dan bisnis.</p>
                </div>
                <div class="footer-section">
                    <h3>Link Cepat</h3>
                    <ul class="footer-links">
                        <li><a href="index.php">Beranda</a></li>
                        <li><a href="article.php">Artikel</a></li>
                        <li><a href="search.php">Pencarian</a></li>
                        <li><a href="about.php">Tentang Kami</a></li>
                        <li><a href="contact.php">Kontak</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Kategori</h3>
                    <ul class="footer-links">
                        <li><a href="search.php?category=1">Teknologi</a></li>
                        <li><a href="search.php?category=2">Pemrograman</a></li>
                        <li><a href="search.php?category=3">Desain</a></li>
                        <li><a href="search.php?category=4">Bisnis</a></li>
                    </ul>
                </div>
            </div>
            <div class="copyright">
                © <?php echo date('Y'); ?> MyBlog. Semua hak dilindungi.
            </div>
        </div>
    </div>
</body>
</html>