<?php
session_start();
require_once '../config/database.php';

// Ambil parameter filter
$category_id = isset($_GET['category']) ? intval($_GET['category']) : 0;
$search = isset($_GET['search']) ? mysqli_real_escape_string($konek, $_GET['search']) : '';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 9;
$offset = ($page - 1) * $limit;

// Query dasar
$query = "SELECT a.*, c.name as category_name, ad.username as author_name 
          FROM articles a 
          LEFT JOIN categories c ON a.category_id = c.id 
          LEFT JOIN admins ad ON a.author_id = ad.id 
          WHERE a.is_published = 1";

// Tambahkan filter
if ($category_id > 0) {
    $query .= " AND a.category_id = $category_id";
}

if (!empty($search)) {
    $query .= " AND (a.title LIKE '%$search%' OR a.content LIKE '%$search%')";
}

// Hitung total untuk pagination
$count_query = "SELECT COUNT(*) as total FROM ($query) as count_table";
$count_result = mysqli_query($konek, $count_query);
$total_rows = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_rows / $limit);

// Tambahkan sorting dan limit
$query .= " ORDER BY a.published_at DESC LIMIT $limit OFFSET $offset";
$articles = mysqli_query($konek, $query);

// Ambil semua kategori untuk filter
$categories = mysqli_query($konek, "SELECT * FROM categories ORDER BY name");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Semua Artikel - Blog</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #f8f9fa;
        }
        .header {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
            text-decoration: none;
            color: white;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .nav-links a:hover {
            background: rgba(255,255,255,0.1);
        }
        .page-title {
            text-align: center;
            padding: 40px 20px;
        }
        .page-title h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
        }
        .filters {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .filter-form {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            align-items: center;
        }
        .filter-group {
            flex: 1;
            min-width: 200px;
        }
        .filter-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
            color: #555;
        }
        select, input[type="text"] {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 5px;
            font-size: 16px;
        }
        .btn-filter {
            padding: 10px 30px;
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            height: 42px;
        }
        .btn-filter:hover {
            opacity: 0.9;
        }
        .articles-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }
        .article-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }
        .article-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        .article-header {
            height: 200px;
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
        .category-badge {
            position: absolute;
            top: 15px;
            left: 15px;
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
        }
        .article-icon {
            font-size: 60px;
        }
        .article-content {
            padding: 25px;
        }
        .article-title {
            font-size: 1.4em;
            margin-bottom: 15px;
            line-height: 1.4;
        }
        .article-title a {
            color: #333;
            text-decoration: none;
        }
        .article-title a:hover {
            color: #4facfe;
        }
        .article-excerpt {
            color: #666;
            margin-bottom: 20px;
            font-size: 15px;
            line-height: 1.6;
        }
        .article-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 15px;
            border-top: 1px solid #eee;
            font-size: 13px;
            color: #888;
        }
        .author {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .author-icon {
            width: 25px;
            height: 25px;
            background: #4facfe;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 12px;
        }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin: 40px 0;
        }
        .page-link {
            padding: 10px 15px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            color: #333;
            text-decoration: none;
            transition: all 0.3s;
        }
        .page-link:hover {
            background: #4facfe;
            color: white;
            border-color: #4facfe;
        }
        .page-link.active {
            background: #4facfe;
            color: white;
            border-color: #4facfe;
        }
        .results-info {
            text-align: center;
            margin-bottom: 20px;
            color: #666;
        }
        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
        }
        .empty-state h3 {
            font-size: 1.5em;
            margin-bottom: 10px;
            color: #333;
        }
        .footer {
            background: #333;
            color: white;
            padding: 40px 0;
            margin-top: 60px;
        }
        .copyright {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid #444;
            margin-top: 30px;
            font-size: 14px;
            opacity: 0.7;
        }
        @media (max-width: 768px) {
            .articles-container {
                grid-template-columns: 1fr;
            }
            .filter-form {
                flex-direction: column;
            }
            .filter-group {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="navbar">
            <a href="index.php" class="logo">MyBlog</a>
            <div class="nav-links">
                <a href="index.php">Beranda</a>
                <a href="article.php">Artikel</a>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="../user/dashboard.php">Dashboard</a>
                    <a href="../user/logout.php">Logout</a>
                <?php else: ?>
                    <a href="../user/login.php">Login</a>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="page-title">
            <h1>Semua Artikel</h1>
            <p>Temukan artikel menarik sesuai minat Anda</p>
        </div>
    </div>

    <div class="container">
        <div class="filters">
            <form method="GET" action="" class="filter-form">
                <div class="filter-group">
                    <label>Kategori</label>
                    <select name="category">
                        <option value="0">Semua Kategori</option>
                        <?php while($cat = mysqli_fetch_assoc($categories)): ?>
                            <option value="<?php echo $cat['id']; ?>" 
                                <?php echo ($category_id == $cat['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cat['name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label>Cari Artikel</label>
                    <input type="text" name="search" placeholder="Kata kunci..." 
                           value="<?php echo htmlspecialchars($search); ?>">
                </div>
                
                <button type="submit" class="btn-filter">Filter</button>
                
                <?php if($category_id > 0 || !empty($search)): ?>
                    <a href="article.php" style="
                        padding: 10px 20px;
                        background: #f8f9fa;
                        color: #333;
                        text-decoration: none;
                        border-radius: 5px;
                        border: 1px solid #ddd;
                    ">
                        Reset
                    </a>
                <?php endif; ?>
            </form>
        </div>

        <div class="results-info">
            Menampilkan <?php echo min($limit, $total_rows); ?> dari <?php echo $total_rows; ?> artikel
            <?php if($category_id > 0): ?>
                dalam kategori <?php 
                    $cat_name = mysqli_fetch_assoc(mysqli_query($konek, 
                        "SELECT name FROM categories WHERE id = $category_id"))['name'];
                    echo htmlspecialchars($cat_name);
                ?>
            <?php endif; ?>
        </div>

        <?php if(mysqli_num_rows($articles) > 0): ?>
            <div class="articles-container">
                <?php while($article = mysqli_fetch_assoc($articles)): ?>
                    <div class="article-card">
                        <div class="article-header">
                            <?php if($article['category_name']): ?>
                                <span class="category-badge"><?php echo $article['category_name']; ?></span>
                            <?php endif; ?>
                            <div class="article-icon">📝</div>
                        </div>
                        <div class="article-content">
                            <h2 class="article-title">
                                <a href="post.php?id=<?php echo $article['id']; ?>">
                                    <?php echo htmlspecialchars($article['title']); ?>
                                </a>
                            </h2>
                            <p class="article-excerpt">
                                <?php 
                                $excerpt = $article['excerpt'] ?: substr(strip_tags($article['content']), 0, 200);
                                echo htmlspecialchars($excerpt) . '...'; 
                                ?>
                            </p>
                            <div class="article-meta">
                                <div class="author">
                                    <div class="author-icon">
                                        <?php echo strtoupper(substr($article['author_name'], 0, 1)); ?>
                                    </div>
                                    <span><?php echo $article['author_name']; ?></span>
                                </div>
                                <div>
                                    <span><?php echo date('d M Y', strtotime($article['created_at'])); ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>

            <?php if($total_pages > 1): ?>
                <div class="pagination">
                    <?php if($page > 1): ?>
                        <a href="article.php?page=<?php echo $page-1; ?>&category=<?php echo $category_id; ?>&search=<?php echo urlencode($search); ?>" 
                           class="page-link">← Prev</a>
                    <?php endif; ?>
                    
                    <?php for($i = 1; $i <= $total_pages; $i++): ?>
                        <?php if($i == $page): ?>
                            <span class="page-link active"><?php echo $i; ?></span>
                        <?php else: ?>
                            <a href="article.php?page=<?php echo $i; ?>&category=<?php echo $category_id; ?>&search=<?php echo urlencode($search); ?>" 
                               class="page-link"><?php echo $i; ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if($page < $total_pages): ?>
                        <a href="article.php?page=<?php echo $page+1; ?>&category=<?php echo $category_id; ?>&search=<?php echo urlencode($search); ?>" 
                           class="page-link">Next →</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
        <?php else: ?>
            <div class="empty-state">
                <h3>Tidak ada artikel ditemukan</h3>
                <p><?php 
                    if($category_id > 0) {
                        echo "Tidak ada artikel dalam kategori yang dipilih.";
                    } elseif(!empty($search)) {
                        echo "Tidak ada artikel dengan kata kunci '$search'.";
                    } else {
                        echo "Belum ada artikel yang tersedia.";
                    }
                ?></p>
                <a href="article.php" style="
                    display: inline-block;
                    margin-top: 15px;
                    padding: 10px 25px;
                    background: #4facfe;
                    color: white;
                    text-decoration: none;
                    border-radius: 5px;
                ">
                    Lihat Semua Artikel
                </a>
            </div>
        <?php endif; ?>
    </div>

    <div class="footer">
        <div class="container">
            <div class="copyright">
                © <?php echo date('Y'); ?> MyBlog. Semua hak dilindungi.
            </div>
        </div>
    </div>
</body>
</html>