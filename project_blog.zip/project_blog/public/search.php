<?php
session_start();
require_once '../config/database.php';

// Ambil parameter pencarian
$keyword = isset($_GET['q']) ? mysqli_real_escape_string($konek, $_GET['q']) : '';
$category_id = isset($_GET['category']) ? intval($_GET['category']) : 0;
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'recent';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 12;
$offset = ($page - 1) * $limit;

// Query dasar
$query = "SELECT a.*, c.name as category_name, ad.username as author_name 
          FROM articles a 
          LEFT JOIN categories c ON a.category_id = c.id 
          LEFT JOIN admins ad ON a.author_id = ad.id 
          WHERE a.is_published = 1";

// Tambahkan filter pencarian
if (!empty($keyword)) {
    $query .= " AND (a.title LIKE '%$keyword%' 
                OR a.content LIKE '%$keyword%' 
                OR a.excerpt LIKE '%$keyword%'
                OR c.name LIKE '%$keyword%'
                OR ad.username LIKE '%$keyword%')";
}

if ($category_id > 0) {
    $query .= " AND a.category_id = $category_id";
}

// Hitung total untuk pagination
$count_query = "SELECT COUNT(*) as total FROM ($query) as count_table";
$count_result = mysqli_query($konek, $count_query);
$total_rows = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_rows / $limit);

// Tambahkan sorting
switch($sort) {
    case 'views':
        $query .= " ORDER BY a.view_count DESC";
        break;
    case 'oldest':
        $query .= " ORDER BY a.created_at ASC";
        break;
    case 'recent':
    default:
        $query .= " ORDER BY a.created_at DESC";
        break;
}

// Tambahkan limit
$query .= " LIMIT $limit OFFSET $offset";
$articles = mysqli_query($konek, $query);

// Ambil semua kategori untuk filter
$categories = mysqli_query($konek, "SELECT * FROM categories ORDER BY name");

// Ambil artikel populer untuk sidebar
$popular_articles = mysqli_query($konek, 
    "SELECT id, title, view_count FROM articles 
     WHERE is_published = 1 
     ORDER BY view_count DESC 
     LIMIT 5");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pencarian - Blog</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #f8f9fa;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
            text-decoration: none;
            color: white;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .nav-links a:hover {
            background: rgba(255,255,255,0.1);
        }
        .search-header {
            text-align: center;
            padding: 60px 20px;
        }
        .search-header h1 {
            font-size: 2.5em;
            margin-bottom: 20px;
        }
        .search-box {
            max-width: 600px;
            margin: 0 auto 30px;
        }
        .search-form {
            display: flex;
            gap: 10px;
        }
        .search-input {
            flex: 1;
            padding: 15px 20px;
            border: none;
            border-radius: 30px;
            font-size: 16px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .search-btn {
            padding: 0 30px;
            background: white;
            color: #667eea;
            border: none;
            border-radius: 30px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }
        .search-btn:hover {
            background: #f8f9fa;
            transform: translateY(-2px);
        }
        .main-content {
            display: grid;
            grid-template-columns: 1fr 300px;
            gap: 40px;
            padding: 40px 0;
        }
        .filters {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .filter-group {
            margin-bottom: 20px;
        }
        .filter-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }
        select {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 5px;
            font-size: 16px;
        }
        .results-info {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .results-count {
            color: #666;
            font-size: 16px;
        }
        .sort-options {
            display: flex;
            gap: 10px;
        }
        .sort-btn {
            padding: 8px 15px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            color: #666;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s;
        }
        .sort-btn:hover, .sort-btn.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        .articles-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        .article-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }
        .article-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        .article-image {
            height: 180px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 40px;
        }
        .article-content {
            padding: 20px;
        }
        .category-tag {
            display: inline-block;
            background: #f0f0f0;
            color: #667eea;
            padding: 4px 10px;
            border-radius: 15px;
            font-size: 11px;
            margin-bottom: 10px;
            font-weight: 500;
        }
        .article-title {
            font-size: 1.2em;
            margin-bottom: 10px;
            line-height: 1.4;
        }
        .article-title a {
            color: #333;
            text-decoration: none;
        }
        .article-title a:hover {
            color: #667eea;
        }
        .article-excerpt {
            color: #666;
            font-size: 14px;
            line-height: 1.5;
            margin-bottom: 15px;
        }
        .article-meta {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #999;
        }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin: 40px 0;
        }
        .page-link {
            padding: 10px 15px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            color: #333;
            text-decoration: none;
            transition: all 0.3s;
        }
        .page-link:hover {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        .page-link.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        .sidebar {
            position: sticky;
            top: 20px;
            height: fit-content;
        }
        .sidebar-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .sidebar-title {
            font-size: 1.1em;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
            color: #333;
        }
        .popular-list {
            list-style: none;
        }
        .popular-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .popular-item:last-child {
            border-bottom: none;
        }
        .popular-rank {
            width: 30px;
            height: 30px;
            background: #667eea;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            font-weight: bold;
        }
        .popular-content {
            flex: 1;
        }
        .popular-title {
            font-size: 14px;
            margin-bottom: 5px;
        }
        .popular-title a {
            color: #333;
            text-decoration: none;
        }
        .popular-title a:hover {
            color: #667eea;
        }
        .popular-views {
            font-size: 12px;
            color: #999;
        }
        .category-list {
            list-style: none;
        }
        .category-item {
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .category-item:last-child {
            border-bottom: none;
        }
        .category-link {
            color: #333;
            text-decoration: none;
            display: flex;
            justify-content: space-between;
        }
        .category-link:hover {
            color: #667eea;
        }
        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
        }
        .empty-state h3 {
            font-size: 1.5em;
            margin-bottom: 10px;
            color: #333;
        }
        .search-tips {
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }
        .footer {
            background: #333;
            color: white;
            padding: 40px 0;
            margin-top: 60px;
        }
        .copyright {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid #444;
            margin-top: 30px;
            font-size: 14px;
            opacity: 0.7;
        }
        @media (max-width: 768px) {
            .main-content {
                grid-template-columns: 1fr;
            }
            .articles-grid {
                grid-template-columns: 1fr;
            }
            .search-form {
                flex-direction: column;
            }
            .search-btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="navbar">
            <a href="index.php" class="logo">MyBlog</a>
            <div class="nav-links">
                <a href="index.php">Beranda</a>
                <a href="article.php">Artikel</a>
                <a href="about.php">Tentang</a>
                <a href="contact.php">Kontak</a>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="../user/dashboard.php">Dashboard</a>
                    <a href="../user/logout.php">Logout</a>
                <?php else: ?>
                    <a href="../user/login.php">Login</a>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="search-header">
            <h1>Cari Artikel</h1>
            <div class="search-box">
                <form method="GET" action="" class="search-form">
                    <input type="text" name="q" class="search-input" 
                           placeholder="Ketik kata kunci..." 
                           value="<?php echo htmlspecialchars($keyword); ?>">
                    <button type="submit" class="search-btn">🔍 Cari</button>
                </form>
            </div>
            <p>Temukan artikel yang Anda cari</p>
        </div>
    </div>

    <div class="container">
        <div class="main-content">
            <div>
                <div class="filters">
                    <form method="GET" action="">
                        <input type="hidden" name="q" value="<?php echo htmlspecialchars($keyword); ?>">
                        <div class="filter-group">
                            <label>Filter Kategori</label>
                            <select name="category">
                                <option value="0">Semua Kategori</option>
                                <?php while($cat = mysqli_fetch_assoc($categories)): ?>
                                    <option value="<?php echo $cat['id']; ?>" 
                                        <?php echo ($category_id == $cat['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($cat['name']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        <button type="submit" style="
                            width: 100%;
                            padding: 12px;
                            background: #667eea;
                            color: white;
                            border: none;
                            border-radius: 5px;
                            cursor: pointer;
                            font-size: 16px;
                        ">
                            Terapkan Filter
                        </button>
                    </form>
                </div>

                <div class="results-info">
                    <div class="results-count">
                        <?php echo $total_rows; ?> hasil ditemukan
                        <?php if(!empty($keyword)): ?>
                            untuk "<strong><?php echo htmlspecialchars($keyword); ?></strong>"
                        <?php endif; ?>
                    </div>
                    
                    <div class="sort-options">
                        <a href="?q=<?php echo urlencode($keyword); ?>&category=<?php echo $category_id; ?>&sort=recent" 
                           class="sort-btn <?php echo $sort == 'recent' ? 'active' : ''; ?>">
                            Terbaru
                        </a>
                        <a href="?q=<?php echo urlencode($keyword); ?>&category=<?php echo $category_id; ?>&sort=views" 
                           class="sort-btn <?php echo $sort == 'views' ? 'active' : ''; ?>">
                            Populer
                        </a>
                        <a href="?q=<?php echo urlencode($keyword); ?>&category=<?php echo $category_id; ?>&sort=oldest" 
                           class="sort-btn <?php echo $sort == 'oldest' ? 'active' : ''; ?>">
                            Terlama
                        </a>
                    </div>
                </div>

                <?php if(mysqli_num_rows($articles) > 0): ?>
                    <div class="articles-grid">
                        <?php 
                        $counter = 0;
                        while($article = mysqli_fetch_assoc($articles)): 
                            $counter++;
                        ?>
                            <div class="article-card">
                                <div class="article-image">
                                    <?php echo $counter; ?>
                                </div>
                                <div class="article-content">
                                    <?php if($article['category_name']): ?>
                                        <span class="category-tag"><?php echo $article['category_name']; ?></span>
                                    <?php endif; ?>
                                    <h3 class="article-title">
                                        <a href="post.php?id=<?php echo $article['id']; ?>">
                                            <?php echo htmlspecialchars($article['title']); ?>
                                        </a>
                                    </h3>
                                    <p class="article-excerpt">
                                        <?php 
                                        $excerpt = $article['excerpt'] ?: substr(strip_tags($article['content']), 0, 120);
                                        echo htmlspecialchars($excerpt) . '...'; 
                                        ?>
                                    </p>
                                    <div class="article-meta">
                                        <span>By <?php echo $article['author_name']; ?></span>
                                        <span><?php echo date('d M Y', strtotime($article['created_at'])); ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>

                    <?php if($total_pages > 1): ?>
                        <div class="pagination">
                            <?php if($page > 1): ?>
                                <a href="?q=<?php echo urlencode($keyword); ?>&category=<?php echo $category_id; ?>&sort=<?php echo $sort; ?>&page=<?php echo $page-1; ?>" 
                                   class="page-link">← Sebelumnya</a>
                            <?php endif; ?>
                            
                            <?php 
                            $start = max(1, $page - 2);
                            $end = min($total_pages, $page + 2);
                            
                            for($i = $start; $i <= $end; $i++): 
                            ?>
                                <?php if($i == $page): ?>
                                    <span class="page-link active"><?php echo $i; ?></span>
                                <?php else: ?>
                                    <a href="?q=<?php echo urlencode($keyword); ?>&category=<?php echo $category_id; ?>&sort=<?php echo $sort; ?>&page=<?php echo $i; ?>" 
                                       class="page-link"><?php echo $i; ?></a>
                                <?php endif; ?>
                            <?php endfor; ?>
                            
                            <?php if($page < $total_pages): ?>
                                <a href="?q=<?php echo urlencode($keyword); ?>&category=<?php echo $category_id; ?>&sort=<?php echo $sort; ?>&page=<?php echo $page+1; ?>" 
                                   class="page-link">Selanjutnya →</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                <?php else: ?>
                    <div class="empty-state">
                        <?php if(!empty($keyword)): ?>
                            <h3>Tidak ada hasil ditemukan</h3>
                            <p>Tidak ada artikel yang cocok dengan pencarian "<strong><?php echo htmlspecialchars($keyword); ?></strong>"</p>
                        <?php else: ?>
                            <h3>Silakan masukkan kata kunci pencarian</h3>
                            <p>Gunakan form di atas untuk mencari artikel</p>
                        <?php endif; ?>
                        
                        <div class="search-tips">
                            <p><strong>Tips pencarian:</strong></p>
                            <ul style="text-align: left; max-width: 400px; margin: 10px auto;">
                                <li>Gunakan kata kunci yang lebih spesifik</li>
                                <li>Coba gunakan sinonim</li>
                                <li>Cek ejaan kata kunci Anda</li>
                                <li>Gunakan filter kategori untuk mempersempit hasil</li>
                            </ul>
                        </div>
                        
                        <a href="article.php" style="
                            display: inline-block;
                            margin-top: 20px;
                            padding: 12px 30px;
                            background: #667eea;
                            color: white;
                            text-decoration: none;
                            border-radius: 5px;
                        ">
                            Lihat Semua Artikel
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <div class="sidebar">
                <div class="sidebar-card">
                    <h3 class="sidebar-title">Artikel Populer</h3>
                    <ul class="popular-list">
                        <?php 
                        $rank = 1;
                        while($popular = mysqli_fetch_assoc($popular_articles)): 
                        ?>
                            <li class="popular-item">
                                <div class="popular-rank"><?php echo $rank; ?></div>
                                <div class="popular-content">
                                    <div class="popular-title">
                                        <a href="post.php?id=<?php echo $popular['id']; ?>">
                                            <?php echo htmlspecialchars($popular['title']); ?>
                                        </a>
                                    </div>
                                    <div class="popular-views">
                                        <?php echo number_format($popular['view_count']); ?> views
                                    </div>
                                </div>
                            </li>
                            <?php $rank++; ?>
                        <?php endwhile; ?>
                    </ul>
                </div>

                <div class="sidebar-card">
                    <h3 class="sidebar-title">Kategori</h3>
                    <ul class="category-list">
                        <?php 
                        // Reset pointer categories
                        mysqli_data_seek($categories, 0);
                        while($cat = mysqli_fetch_assoc($categories)): 
                            // Hitung jumlah artikel per kategori
                            $count_query = mysqli_query($konek, 
                                "SELECT COUNT(*) as count FROM articles 
                                 WHERE category_id = {$cat['id']} AND is_published = 1");
                            $count = mysqli_fetch_assoc($count_query)['count'];
                        ?>
                            <li class="category-item">
                                <a href="search.php?category=<?php echo $cat['id']; ?>" class="category-link">
                                    <span><?php echo htmlspecialchars($cat['name']); ?></span>
                                    <span><?php echo $count; ?></span>
                                </a>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="footer">
        <div class="container">
            <div class="copyright">
                © <?php echo date('Y'); ?> MyBlog. Semua hak dilindungi.
            </div>
        </div>
    </div>
</body>
</html>