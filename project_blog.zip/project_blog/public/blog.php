<?php
session_start();
require_once '../config/database.php';

// Ambil parameter filter
$category_id = isset($_GET['category']) ? intval($_GET['category']) : 0;
$author_id = isset($_GET['author']) ? intval($_GET['author']) : 0;
$year = isset($_GET['year']) ? intval($_GET['year']) : 0;
$month = isset($_GET['month']) ? intval($_GET['month']) : 0;
$tag = isset($_GET['tag']) ? mysqli_real_escape_string($konek, $_GET['tag']) : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'recent';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 12;
$offset = ($page - 1) * $limit;

// Query dasar
$query = "SELECT a.*, c.name as category_name, c.slug as category_slug, 
                 ad.username as author_name, ad.full_name as author_full_name
          FROM articles a 
          LEFT JOIN categories c ON a.category_id = c.id 
          LEFT JOIN admins ad ON a.author_id = ad.id 
          WHERE a.is_published = 1";

// Tambahkan filter
$filter_text = '';

if ($category_id > 0) {
    $query .= " AND a.category_id = $category_id";
    $cat_name = mysqli_fetch_assoc(mysqli_query($konek, 
        "SELECT name FROM categories WHERE id = $category_id"))['name'];
    $filter_text .= " dalam kategori <strong>" . htmlspecialchars($cat_name) . "</strong>";
}

if ($author_id > 0) {
    $query .= " AND a.author_id = $author_id";
    $author_name = mysqli_fetch_assoc(mysqli_query($konek, 
        "SELECT username FROM admins WHERE id = $author_id"))['username'];
    $filter_text .= " oleh penulis <strong>" . htmlspecialchars($author_name) . "</strong>";
}

if ($year > 0) {
    $query .= " AND YEAR(a.created_at) = $year";
    $filter_text .= " tahun <strong>$year</strong>";
    
    if ($month > 0 && $month <= 12) {
        $query .= " AND MONTH(a.created_at) = $month";
        $month_names = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 
                       'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
        $filter_text .= " bulan <strong>" . $month_names[$month-1] . "</strong>";
    }
}

if (!empty($tag)) {
    // Search in title, content, or excerpt
    $query .= " AND (a.title LIKE '%$tag%' OR a.content LIKE '%$tag%' OR a.excerpt LIKE '%$tag%')";
    $filter_text .= " dengan tag <strong>" . htmlspecialchars($tag) . "</strong>";
}

// Hitung total untuk pagination
$count_query = "SELECT COUNT(*) as total FROM ($query) as count_table";
$count_result = mysqli_query($konek, $count_query);
$total_rows = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_rows / $limit);

// Tambahkan sorting
switch($sort) {
    case 'popular':
        $query .= " ORDER BY a.view_count DESC";
        break;
    case 'liked':
        // Artikel dengan likes terbanyak
        $query = "SELECT a.*, c.name as category_name, c.slug as category_slug, 
                         ad.username as author_name, ad.full_name as author_full_name,
                         COUNT(al.id) as like_count
                  FROM articles a 
                  LEFT JOIN categories c ON a.category_id = c.id 
                  LEFT JOIN admins ad ON a.author_id = ad.id 
                  LEFT JOIN article_likes al ON a.id = al.article_id 
                  WHERE a.is_published = 1" . 
                  ($category_id > 0 ? " AND a.category_id = $category_id" : "") . 
                  ($author_id > 0 ? " AND a.author_id = $author_id" : "") . 
                  ($year > 0 ? " AND YEAR(a.created_at) = $year" : "") . 
                  ($month > 0 ? " AND MONTH(a.created_at) = $month" : "") . 
                  (!empty($tag) ? " AND (a.title LIKE '%$tag%' OR a.content LIKE '%$tag%')" : "") . 
                  " GROUP BY a.id 
                   ORDER BY like_count DESC";
        break;
    case 'commented':
        // Artikel dengan komentar terbanyak
        $query = "SELECT a.*, c.name as category_name, c.slug as category_slug, 
                         ad.username as author_name, ad.full_name as author_full_name,
                         COUNT(cm.id) as comment_count
                  FROM articles a 
                  LEFT JOIN categories c ON a.category_id = c.id 
                  LEFT JOIN admins ad ON a.author_id = ad.id 
                  LEFT JOIN comments cm ON a.id = cm.article_id 
                  WHERE a.is_published = 1" . 
                  ($category_id > 0 ? " AND a.category_id = $category_id" : "") . 
                  ($author_id > 0 ? " AND a.author_id = $author_id" : "") . 
                  ($year > 0 ? " AND YEAR(a.created_at) = $year" : "") . 
                  ($month > 0 ? " AND MONTH(a.created_at) = $month" : "") . 
                  (!empty($tag) ? " AND (a.title LIKE '%$tag%' OR a.content LIKE '%$tag%')" : "") . 
                  " GROUP BY a.id 
                   ORDER BY comment_count DESC";
        break;
    case 'oldest':
        $query .= " ORDER BY a.created_at ASC";
        break;
    case 'recent':
    default:
        $query .= " ORDER BY a.created_at DESC";
        break;
}

// Tambahkan limit untuk non-aggregate queries
if ($sort != 'liked' && $sort != 'commented') {
    $query .= " LIMIT $limit OFFSET $offset";
} else {
    // Untuk aggregate queries, kita perlu subquery untuk limit
    $query = "SELECT * FROM ($query) as sorted_results LIMIT $limit OFFSET $offset";
}

$articles = mysqli_query($konek, $query);

// Ambil semua kategori
$categories = mysqli_query($konek, "SELECT * FROM categories ORDER BY name");

// Ambil semua penulis (admin)
$authors = mysqli_query($konek, "SELECT id, username, full_name FROM admins ORDER BY username");

// Ambil arsip tahun
$archive_years = mysqli_query($konek, 
    "SELECT YEAR(created_at) as year, COUNT(*) as count 
     FROM articles 
     WHERE is_published = 1 
     GROUP BY YEAR(created_at) 
     ORDER BY year DESC");

// Ambil tag populer (dari judul artikel)
$tags_result = mysqli_query($konek, 
    "SELECT LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(title, ' ', n), ' ', -1)) as tag, 
            COUNT(*) as count
     FROM articles 
     CROSS JOIN (
         SELECT 1 n UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5
     ) numbers
     WHERE is_published = 1 
       AND CHAR_LENGTH(title) - CHAR_LENGTH(REPLACE(title, ' ', '')) >= n - 1
       AND LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(title, ' ', n), ' ', -1)) REGEXP '^[a-z]+$'
     GROUP BY tag 
     HAVING COUNT(*) >= 1 
     ORDER BY count DESC 
     LIMIT 20");

// Ambil artikel populer untuk sidebar
$popular_articles = mysqli_query($konek, 
    "SELECT a.id, a.title, a.view_count, c.name as category_name 
     FROM articles a 
     LEFT JOIN categories c ON a.category_id = c.id 
     WHERE a.is_published = 1 
     ORDER BY a.view_count DESC 
     LIMIT 5");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Archive - Koleksi Artikel Lengkap</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #f8f9fa;
        }
        .header {
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
            text-decoration: none;
            color: white;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .nav-links a:hover {
            background: rgba(255,255,255,0.1);
        }
        .blog-header {
            text-align: center;
            padding: 60px 20px;
        }
        .blog-header h1 {
            font-size: 3em;
            margin-bottom: 15px;
        }
        .blog-header p {
            font-size: 1.2em;
            max-width: 700px;
            margin: 0 auto;
            opacity: 0.9;
        }
        .main-content {
            display: grid;
            grid-template-columns: 250px 1fr 250px;
            gap: 40px;
            padding: 40px 0;
        }
        .filter-sidebar, .right-sidebar {
            position: sticky;
            top: 20px;
            height: fit-content;
        }
        .filter-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .filter-title {
            font-size: 1.1em;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
            color: #333;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .filter-title i {
            color: #6a11cb;
        }
        .filter-group {
            margin-bottom: 20px;
        }
        .filter-group:last-child {
            margin-bottom: 0;
        }
        select, input[type="text"] {
            width: 100%;
            padding: 10px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 5px;
            font-size: 14px;
        }
        .filter-btn {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            margin-top: 10px;
        }
        .reset-btn {
            width: 100%;
            padding: 10px;
            background: #f8f9fa;
            color: #333;
            border: 1px solid #ddd;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            margin-top: 10px;
        }
        .filter-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 10px;
        }
        .tag {
            background: #f0f0f0;
            color: #666;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            text-decoration: none;
            transition: all 0.3s;
        }
        .tag:hover {
            background: #6a11cb;
            color: white;
        }
        .archive-list, .author-list {
            list-style: none;
        }
        .archive-item, .author-item {
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .archive-item:last-child, .author-item:last-child {
            border-bottom: none;
        }
        .archive-link, .author-link {
            color: #333;
            text-decoration: none;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .archive-link:hover, .author-link:hover {
            color: #6a11cb;
        }
        .archive-count, .author-count {
            background: #f0f0f0;
            color: #666;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 12px;
        }
        .results-header {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .results-info h2 {
            font-size: 1.4em;
            margin-bottom: 10px;
            color: #333;
        }
        .results-count {
            color: #666;
            font-size: 14px;
        }
        .sort-options {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .sort-btn {
            padding: 8px 15px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            color: #666;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s;
        }
        .sort-btn:hover, .sort-btn.active {
            background: #6a11cb;
            color: white;
            border-color: #6a11cb;
        }
        .articles-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }
        .article-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }
        .article-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
        }
        .article-header {
            height: 180px;
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
        .article-category {
            position: absolute;
            top: 15px;
            left: 15px;
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            text-decoration: none;
        }
        .article-stats {
            position: absolute;
            bottom: 15px;
            right: 15px;
            display: flex;
            gap: 10px;
            font-size: 12px;
            background: rgba(0,0,0,0.7);
            padding: 5px 10px;
            border-radius: 15px;
        }
        .stat-item {
            display: flex;
            align-items: center;
            gap: 5px;
        }
        .article-icon {
            font-size: 50px;
            opacity: 0.8;
        }
        .article-content {
            padding: 25px;
        }
        .article-title {
            font-size: 1.3em;
            margin-bottom: 15px;
            line-height: 1.4;
        }
        .article-title a {
            color: #333;
            text-decoration: none;
        }
        .article-title a:hover {
            color: #6a11cb;
        }
        .article-excerpt {
            color: #666;
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        .article-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 15px;
            border-top: 1px solid #eee;
            font-size: 13px;
            color: #888;
        }
        .article-author {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .author-avatar {
            width: 25px;
            height: 25px;
            background: #6a11cb;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 12px;
        }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin: 40px 0;
            flex-wrap: wrap;
        }
        .page-link {
            padding: 10px 15px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            color: #333;
            text-decoration: none;
            transition: all 0.3s;
        }
        .page-link:hover {
            background: #6a11cb;
            color: white;
            border-color: #6a11cb;
        }
        .page-link.active {
            background: #6a11cb;
            color: white;
            border-color: #6a11cb;
        }
        .page-link.disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 60px 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
        }
        .empty-state h3 {
            font-size: 1.5em;
            margin-bottom: 10px;
            color: #333;
        }
        .featured-section {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 40px;
            border-radius: 15px;
            margin-bottom: 40px;
            text-align: center;
        }
        .featured-title {
            font-size: 2em;
            margin-bottom: 20px;
        }
        .featured-desc {
            font-size: 1.1em;
            max-width: 600px;
            margin: 0 auto 30px;
            opacity: 0.9;
        }
        .featured-link {
            display: inline-block;
            padding: 12px 30px;
            background: white;
            color: #f5576c;
            text-decoration: none;
            border-radius: 30px;
            font-weight: 600;
            transition: all 0.3s;
        }
        .featured-link:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .right-sidebar .filter-card {
            background: linear-gradient(135deg, #ff9a9e 0%, #fad0c4 100%);
            color: #333;
        }
        .right-sidebar .filter-title {
            border-bottom-color: rgba(255,255,255,0.3);
        }
        .footer {
            background: #333;
            color: white;
            padding: 60px 0 30px;
            margin-top: 80px;
        }
        .copyright {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid #444;
            font-size: 14px;
            opacity: 0.7;
        }
        .month-filter {
            display: none;
            margin-top: 10px;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 5px;
        }
        .month-filter.active {
            display: block;
        }
        .month-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 5px;
            margin-top: 10px;
        }
        .month-link {
            padding: 5px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 3px;
            text-align: center;
            font-size: 12px;
            text-decoration: none;
            color: #333;
        }
        .month-link:hover, .month-link.active {
            background: #6a11cb;
            color: white;
            border-color: #6a11cb;
        }
        @media (max-width: 1024px) {
            .main-content {
                grid-template-columns: 1fr;
            }
            .filter-sidebar, .right-sidebar {
                position: static;
            }
        }
        @media (max-width: 768px) {
            .articles-grid {
                grid-template-columns: 1fr;
            }
            .results-header {
                flex-direction: column;
                align-items: flex-start;
            }
            .sort-options {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="navbar">
            <a href="index.php" class="logo">MyBlog</a>
            <div class="nav-links">
                <a href="index.php">Beranda</a>
                <a href="blog.php" style="background: rgba(255,255,255,0.2);">Blog</a>
                <a href="search.php">Cari</a>
                <a href="about.php">Tentang</a>
                <a href="contact.php">Kontak</a>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="../user/dashboard.php">Dashboard</a>
                    <a href="../user/logout.php">Logout</a>
                <?php else: ?>
                    <a href="../user/login.php">Login</a>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="blog-header">
            <h1>Blog Archive</h1>
            <p>Jelajahi koleksi lengkap artikel kami dengan berbagai filter dan kategori</p>
        </div>
    </div>

    <div class="container">
        <div class="featured-section">
            <h2 class="featured-title">📚 Koleksi Artikel Terlengkap</h2>
            <p class="featured-desc">Temukan artikel menarik dari berbagai kategori, penulis, dan periode waktu. Gunakan filter di samping untuk menemukan konten yang sesuai dengan minat Anda.</p>
            <a href="index.php" class="featured-link">← Kembali ke Beranda</a>
        </div>

        <div class="main-content">
            <!-- Left Sidebar - Filters -->
            <div class="filter-sidebar">
                <div class="filter-card">
                    <h3 class="filter-title"><span>🔍</span> Filter Artikel</h3>
                    <form method="GET" action="">
                        <div class="filter-group">
                            <label>Kategori</label>
                            <select name="category">
                                <option value="0">Semua Kategori</option>
                                <?php while($cat = mysqli_fetch_assoc($categories)): ?>
                                    <option value="<?php echo $cat['id']; ?>" 
                                        <?php echo ($category_id == $cat['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($cat['name']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        
                        <div class="filter-group">
                            <label>Penulis</label>
                            <select name="author">
                                <option value="0">Semua Penulis</option>
                                <?php while($author = mysqli_fetch_assoc($authors)): ?>
                                    <option value="<?php echo $author['id']; ?>" 
                                        <?php echo ($author_id == $author['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($author['full_name'] ?: $author['username']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                        
                        <div class="filter-group">
                            <label>Tahun</label>
                            <select name="year" id="yearSelect" onchange="toggleMonthFilter()">
                                <option value="0">Semua Tahun</option>
                                <?php while($year_row = mysqli_fetch_assoc($archive_years)): ?>
                                    <option value="<?php echo $year_row['year']; ?>" 
                                        <?php echo ($year == $year_row['year']) ? 'selected' : ''; ?>>
                                        <?php echo $year_row['year']; ?> (<?php echo $year_row['count']; ?>)
                                    </option>
                                <?php endwhile; ?>
                            </select>
                            
                            <div class="month-filter <?php echo ($year > 0) ? 'active' : ''; ?>" id="monthFilter">
                                <label style="font-size: 12px; margin-bottom: 5px; display: block;">Bulan:</label>
                                <div class="month-grid">
                                    <?php 
                                    $month_names = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 
                                                   'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
                                    for($i = 1; $i <= 12; $i++): 
                                    ?>
                                        <a href="?category=<?php echo $category_id; ?>&author=<?php echo $author_id; ?>&year=<?php echo $year; ?>&month=<?php echo $i; ?>&sort=<?php echo $sort; ?>" 
                                           class="month-link <?php echo ($month == $i) ? 'active' : ''; ?>">
                                            <?php echo $month_names[$i-1]; ?>
                                        </a>
                                    <?php endfor; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="filter-group">
                            <label>Tag / Kata Kunci</label>
                            <input type="text" name="tag" placeholder="contoh: php, javascript, web" 
                                   value="<?php echo htmlspecialchars($tag); ?>">
                        </div>
                        
                        <button type="submit" class="filter-btn">Terapkan Filter</button>
                        <button type="button" class="reset-btn" onclick="window.location.href='blog.php'">Reset Filter</button>
                    </form>
                </div>
                
                <div class="filter-card">
                    <h3 class="filter-title"><span>🏷️</span> Tag Populer</h3>
                    <div class="filter-tags">
                        <?php 
                        $tag_counter = 0;
                        while($tag_row = mysqli_fetch_assoc($tags_result)): 
                            if($tag_counter < 15): // Tampilkan maksimal 15 tag
                        ?>
                            <a href="blog.php?tag=<?php echo urlencode($tag_row['tag']); ?>" class="tag">
                                <?php echo htmlspecialchars($tag_row['tag']); ?> (<?php echo $tag_row['count']; ?>)
                            </a>
                        <?php 
                            endif;
                            $tag_counter++;
                        endwhile; 
                        
                        if($tag_counter == 0): 
                        ?>
                            <span style="color: #666; font-size: 14px;">Belum ada tag</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Main Content Area -->
            <div>
                <div class="results-header">
                    <div class="results-info">
                        <h2>Artikel Terbaru <?php echo $filter_text; ?></h2>
                        <div class="results-count">
                            Menampilkan <?php echo min($limit, $total_rows); ?> dari <?php echo $total_rows; ?> artikel
                        </div>
                    </div>
                    
                    <div class="sort-options">
                        <a href="?category=<?php echo $category_id; ?>&author=<?php echo $author_id; ?>&year=<?php echo $year; ?>&month=<?php echo $month; ?>&tag=<?php echo urlencode($tag); ?>&sort=recent" 
                           class="sort-btn <?php echo $sort == 'recent' ? 'active' : ''; ?>">
                            Terbaru
                        </a>
                        <a href="?category=<?php echo $category_id; ?>&author=<?php echo $author_id; ?>&year=<?php echo $year; ?>&month=<?php echo $month; ?>&tag=<?php echo urlencode($tag); ?>&sort=popular" 
                           class="sort-btn <?php echo $sort == 'popular' ? 'active' : ''; ?>">
                            Populer
                        </a>
                        <a href="?category=<?php echo $category_id; ?>&author=<?php echo $author_id; ?>&year=<?php echo $year; ?>&month=<?php echo $month; ?>&tag=<?php echo urlencode($tag); ?>&sort=liked" 
                           class="sort-btn <?php echo $sort == 'liked' ? 'active' : ''; ?>">
                            Paling Disukai
                        </a>
                        <a href="?category=<?php echo $category_id; ?>&author=<?php echo $author_id; ?>&year=<?php echo $year; ?>&month=<?php echo $month; ?>&tag=<?php echo urlencode($tag); ?>&sort=commented" 
                           class="sort-btn <?php echo $sort == 'commented' ? 'active' : ''; ?>">
                            Banyak Komentar
                        </a>
                        <a href="?category=<?php echo $category_id; ?>&author=<?php echo $author_id; ?>&year=<?php echo $year; ?>&month=<?php echo $month; ?>&tag=<?php echo urlencode($tag); ?>&sort=oldest" 
                           class="sort-btn <?php echo $sort == 'oldest' ? 'active' : ''; ?>">
                            Terlama
                        </a>
                    </div>
                </div>

                <?php if(mysqli_num_rows($articles) > 0): ?>
                    <div class="articles-grid">
                        <?php while($article = mysqli_fetch_assoc($articles)): 
                            // Hitung likes dan komentar
                            $likes_count = mysqli_fetch_assoc(mysqli_query($konek, 
                                "SELECT COUNT(*) as count FROM article_likes WHERE article_id = {$article['id']}"))['count'];
                            
                            $comments_count = mysqli_fetch_assoc(mysqli_query($konek, 
                                "SELECT COUNT(*) as count FROM comments WHERE article_id = {$article['id']}"))['count'];
                        ?>
                            <div class="article-card">
                                <div class="article-header">
                                    <?php if($article['category_name']): ?>
                                        <a href="blog.php?category=<?php echo $article['category_id']; ?>" 
                                           class="article-category">
                                            <?php echo $article['category_name']; ?>
                                        </a>
                                    <?php endif; ?>
                                    
                                    <div class="article-icon">
                                        <?php 
                                        $first_letter = strtoupper(substr($article['title'], 0, 1));
                                        echo $first_letter; 
                                        ?>
                                    </div>
                                    
                                    <div class="article-stats">
                                        <div class="stat-item" title="Views">
                                            👁️ <?php echo number_format($article['view_count']); ?>
                                        </div>
                                        <div class="stat-item" title="Likes">
                                            ❤️ <?php echo $likes_count; ?>
                                        </div>
                                        <div class="stat-item" title="Comments">
                                            💬 <?php echo $comments_count; ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="article-content">
                                    <h3 class="article-title">
                                        <a href="post.php?id=<?php echo $article['id']; ?>">
                                            <?php echo htmlspecialchars($article['title']); ?>
                                        </a>
                                    </h3>
                                    <p class="article-excerpt">
                                        <?php 
                                        $excerpt = $article['excerpt'] ?: substr(strip_tags($article['content']), 0, 150);
                                        echo htmlspecialchars($excerpt) . '...'; 
                                        ?>
                                    </p>
                                    <div class="article-meta">
                                        <div class="article-author">
                                            <div class="author-avatar">
                                                <?php echo strtoupper(substr($article['author_name'], 0, 1)); ?>
                                            </div>
                                            <span><?php echo $article['author_full_name'] ?: $article['author_name']; ?></span>
                                        </div>
                                        <div>
                                            <span><?php echo date('d M Y', strtotime($article['created_at'])); ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>

                    <?php if($total_pages > 1): ?>
                        <div class="pagination">
                            <?php if($page > 1): ?>
                                <a href="?category=<?php echo $category_id; ?>&author=<?php echo $author_id; ?>&year=<?php echo $year; ?>&month=<?php echo $month; ?>&tag=<?php echo urlencode($tag); ?>&sort=<?php echo $sort; ?>&page=<?php echo $page-1; ?>" 
                                   class="page-link">← Prev</a>
                            <?php endif; ?>
                            
                            <?php 
                            $start = max(1, $page - 2);
                            $end = min($total_pages, $page + 2);
                            
                            if($start > 1): ?>
                                <a href="?category=<?php echo $category_id; ?>&author=<?php echo $author_id; ?>&year=<?php echo $year; ?>&month=<?php echo $month; ?>&tag=<?php echo urlencode($tag); ?>&sort=<?php echo $sort; ?>&page=1" 
                                   class="page-link">1</a>
                                <?php if($start > 2): ?>
                                    <span class="page-link disabled">...</span>
                                <?php endif; ?>
                            <?php endif; ?>
                            
                            <?php for($i = $start; $i <= $end; $i++): ?>
                                <?php if($i == $page): ?>
                                    <span class="page-link active"><?php echo $i; ?></span>
                                <?php else: ?>
                                    <a href="?category=<?php echo $category_id; ?>&author=<?php echo $author_id; ?>&year=<?php echo $year; ?>&month=<?php echo $month; ?>&tag=<?php echo urlencode($tag); ?>&sort=<?php echo $sort; ?>&page=<?php echo $i; ?>" 
                                       class="page-link"><?php echo $i; ?></a>
                                <?php endif; ?>
                            <?php endfor; ?>
                            
                            <?php if($end < $total_pages): ?>
                                <?php if($end < $total_pages - 1): ?>
                                    <span class="page-link disabled">...</span>
                                <?php endif; ?>
                                <a href="?category=<?php echo $category_id; ?>&author=<?php echo $author_id; ?>&year=<?php echo $year; ?>&month=<?php echo $month; ?>&tag=<?php echo urlencode($tag); ?>&sort=<?php echo $sort; ?>&page=<?php echo $total_pages; ?>" 
                                   class="page-link"><?php echo $total_pages; ?></a>
                            <?php endif; ?>
                            
                            <?php if($page < $total_pages): ?>
                                <a href="?category=<?php echo $category_id; ?>&author=<?php echo $author_id; ?>&year=<?php echo $year; ?>&month=<?php echo $month; ?>&tag=<?php echo urlencode($tag); ?>&sort=<?php echo $sort; ?>&page=<?php echo $page+1; ?>" 
                                   class="page-link">Next →</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                <?php else: ?>
                    <div class="empty-state">
                        <h3>Tidak ada artikel ditemukan</h3>
                        <p>
                            <?php if(!empty($filter_text)): ?>
                                Tidak ada artikel yang cocok dengan filter yang Anda pilih. 
                            <?php else: ?>
                                Belum ada artikel yang tersedia.
                            <?php endif; ?>
                        </p>
                        <a href="blog.php" style="
                            display: inline-block;
                            margin-top: 20px;
                            padding: 12px 30px;
                            background: #6a11cb;
                            color: white;
                            text-decoration: none;
                            border-radius: 5px;
                        ">
                            Lihat Semua Artikel
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Right Sidebar -->
            <div class="right-sidebar">
                <div class="filter-card">
                    <h3 class="filter-title"><span>📊</span> Statistik Blog</h3>
                    <div style="font-size: 14px;">
                        <div style="margin-bottom: 10px; padding-bottom: 10px; border-bottom: 1px dashed rgba(255,255,255,0.3);">
                            <strong>Total Artikel:</strong> <?php echo $total_articles; ?>
                        </div>
                        <div style="margin-bottom: 10px; padding-bottom: 10px; border-bottom: 1px dashed rgba(255,255,255,0.3);">
                            <strong>Total Views:</strong> <?php echo number_format($total_views); ?>
                        </div>
                        <div style="margin-bottom: 10px; padding-bottom: 10px; border-bottom: 1px dashed rgba(255,255,255,0.3);">
                            <strong>Kategori:</strong> <?php echo $total_categories; ?>
                        </div>
                        <div>
                            <strong>Penulis:</strong> <?php echo mysqli_num_rows($authors); ?>
                        </div>
                    </div>
                </div>
                
                <div class="filter-card">
                    <h3 class="filter-title"><span>📈</span> Artikel Populer</h3>
                    <ul class="archive-list">
                        <?php while($popular = mysqli_fetch_assoc($popular_articles)): ?>
                            <li class="archive-item">
                                <a href="post.php?id=<?php echo $popular['id']; ?>" class="archive-link">
                                    <span style="
                                        display: -webkit-box;
                                        -webkit-line-clamp: 2;
                                        -webkit-box-orient: vertical;
                                        overflow: hidden;
                                        line-height: 1.3;
                                    ">
                                        <?php echo htmlspecialchars($popular['title']); ?>
                                    </span>
                                    <span class="archive-count"><?php echo number_format($popular['view_count']); ?></span>
                                </a>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                </div>
                
                <div class="filter-card">
                    <h3 class="filter-title"><span>📅</span> Arsip Tahun</h3>
                    <ul class="archive-list">
                        <?php 
                        // Reset pointer archive_years
                        mysqli_data_seek($archive_years, 0);
                        while($year_row = mysqli_fetch_assoc($archive_years)): 
                        ?>
                            <li class="archive-item">
                                <a href="blog.php?year=<?php echo $year_row['year']; ?>" class="archive-link">
                                    <span>Tahun <?php echo $year_row['year']; ?></span>
                                    <span class="archive-count"><?php echo $year_row['count']; ?></span>
                                </a>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="footer">
        <div class="container">
            <div class="copyright">
                © <?php echo date('Y'); ?> MyBlog. Semua hak dilindungi.
            </div>
        </div>
    </div>

    <script>
    function toggleMonthFilter() {
        const yearSelect = document.getElementById('yearSelect');
        const monthFilter = document.getElementById('monthFilter');
        
        if (yearSelect.value > 0) {
            monthFilter.classList.add('active');
        } else {
            monthFilter.classList.remove('active');
        }
    }
    
    // Auto focus pada filter pertama
    document.addEventListener('DOMContentLoaded', function() {
        const yearSelect = document.getElementById('yearSelect');
        if (yearSelect && yearSelect.value > 0) {
            document.getElementById('monthFilter').classList.add('active');
        }
    });
    
    // Smooth scroll untuk pagination
    document.querySelectorAll('.page-link').forEach(link => {
        link.addEventListener('click', function(e) {
            if (!this.classList.contains('disabled') && !this.classList.contains('active')) {
                window.scrollTo({
                    top: document.querySelector('.results-header').offsetTop - 100,
                    behavior: 'smooth'
                });
            }
        });
    });
    </script>
</body>
</html>