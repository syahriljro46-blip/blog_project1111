<?php
session_start();
require_once '../config/database.php';

// Ambil artikel terbaru (6 artikel terbaru)
$query = "SELECT a.*, c.name as category_name, ad.username as author_name 
          FROM articles a 
          LEFT JOIN categories c ON a.category_id = c.id 
          LEFT JOIN admins ad ON a.author_id = ad.id 
          WHERE a.is_published = 1 
          ORDER BY a.published_at DESC 
          LIMIT 6";
$articles = mysqli_query($konek, $query);

// Ambil kategori populer
$categories = mysqli_query($konek, "SELECT * FROM categories ORDER BY name LIMIT 5");

// Hitung total artikel
$total_articles = mysqli_fetch_assoc(mysqli_query($konek, 
    "SELECT COUNT(*) as total FROM articles WHERE is_published = 1"))['total'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog - Artikel Terbaru</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #f8f9fa;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
            text-decoration: none;
            color: white;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .nav-links a:hover {
            background: rgba(255,255,255,0.1);
        }
        .btn-login {
            background: #f093fb;
            padding: 8px 20px !important;
        }
        .hero {
            text-align: center;
            padding: 60px 20px;
        }
        .hero h1 {
            font-size: 3em;
            margin-bottom: 15px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
        }
        .hero p {
            font-size: 1.2em;
            max-width: 700px;
            margin: 0 auto 30px;
            opacity: 0.9;
        }
        .main-content {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
            padding: 40px 0;
        }
        .articles-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 25px;
        }
        .article-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .article-card:hover {
            transform: translateY(-5px);
        }
        .article-image {
            height: 200px;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 50px;
        }
        .article-content {
            padding: 20px;
        }
        .category-tag {
            display: inline-block;
            background: #667eea;
            color: white;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            margin-bottom: 10px;
        }
        .article-title {
            font-size: 1.3em;
            margin-bottom: 10px;
            color: #333;
            text-decoration: none;
            display: block;
        }
        .article-title:hover {
            color: #667eea;
        }
        .article-excerpt {
            color: #666;
            margin-bottom: 15px;
            font-size: 14px;
        }
        .article-meta {
            display: flex;
            justify-content: space-between;
            font-size: 12px;
            color: #999;
            border-top: 1px solid #eee;
            padding-top: 10px;
        }
        .sidebar {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            height: fit-content;
        }
        .sidebar-title {
            font-size: 1.2em;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
            color: #333;
        }
        .category-list {
            list-style: none;
        }
        .category-item {
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .category-item:last-child {
            border-bottom: none;
        }
        .category-link {
            color: #333;
            text-decoration: none;
            display: flex;
            justify-content: space-between;
        }
        .category-link:hover {
            color: #667eea;
        }
        .stats {
            display: flex;
            justify-content: space-around;
            text-align: center;
            margin: 30px 0;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
        }
        .stat-item {
            padding: 0 15px;
        }
        .stat-number {
            font-size: 2em;
            font-weight: bold;
            color: #667eea;
            display: block;
        }
        .stat-label {
            font-size: 14px;
            color: #666;
        }
        .footer {
            background: #333;
            color: white;
            padding: 40px 0;
            margin-top: 60px;
        }
        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
        }
        .footer-section h3 {
            margin-bottom: 15px;
            color: #f093fb;
        }
        .footer-section p {
            opacity: 0.8;
            font-size: 14px;
        }
        .copyright {
            text-align: center;
            padding-top: 20px;
            border-top: 1px solid #444;
            margin-top: 30px;
            font-size: 14px;
            opacity: 0.7;
        }
        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }
        .empty-state h3 {
            font-size: 1.5em;
            margin-bottom: 10px;
        }
        @media (max-width: 768px) {
            .main-content {
                grid-template-columns: 1fr;
            }
            .navbar {
                flex-direction: column;
                gap: 15px;
            }
            .hero h1 {
                font-size: 2em;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="navbar">
            <a href="index.php" class="logo">MyBlog</a>
            <div class="nav-links">
                <a href="index.php">Beranda</a>
                <a href="article.php">Artikel</a>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="../user/dashboard.php">Dashboard</a>
                    <a href="../user/logout.php">Logout</a>
                <?php else: ?>
                    <a href="../user/login.php" class="btn-login">Login</a>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="hero">
            <h1>Selamat Datang di Blog Kami</h1>
            <p>Temukan artikel menarik tentang teknologi, pemrograman, desain, dan bisnis dari para ahli</p>
        </div>
    </div>

    <div class="container">
        <div class="stats">
            <div class="stat-item">
                <span class="stat-number"><?php echo $total_articles; ?></span>
                <span class="stat-label">Artikel</span>
            </div>
            <div class="stat-item">
                <span class="stat-number">4</span>
                <span class="stat-label">Kategori</span>
            </div>
            <div class="stat-item">
                <span class="stat-number">1</span>
                <span class="stat-label">Penulis</span>
            </div>
        </div>

        <div class="main-content">
            <div>
                <h2 style="margin-bottom: 20px;">Artikel Terbaru</h2>
                
                <?php if(mysqli_num_rows($articles) > 0): ?>
                    <div class="articles-grid">
                        <?php while($article = mysqli_fetch_assoc($articles)): ?>
                            <div class="article-card">
                                <div class="article-image">
                                    <?php 
                                    $first_letter = strtoupper(substr($article['title'], 0, 1));
                                    echo $first_letter; 
                                    ?>
                                </div>
                                <div class="article-content">
                                    <?php if($article['category_name']): ?>
                                        <span class="category-tag"><?php echo $article['category_name']; ?></span>
                                    <?php endif; ?>
                                    <a href="post.php?id=<?php echo $article['id']; ?>" class="article-title">
                                        <?php echo htmlspecialchars($article['title']); ?>
                                    </a>
                                    <p class="article-excerpt">
                                        <?php 
                                        $excerpt = $article['excerpt'] ?: substr(strip_tags($article['content']), 0, 150);
                                        echo htmlspecialchars($excerpt) . '...'; 
                                        ?>
                                    </p>
                                    <div class="article-meta">
                                        <span>By <?php echo $article['author_name']; ?></span>
                                        <span><?php echo date('d M Y', strtotime($article['created_at'])); ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                    
                    <div style="text-align: center; margin-top: 40px;">
                        <a href="article.php" style="
                            display: inline-block;
                            padding: 12px 30px;
                            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                            color: white;
                            text-decoration: none;
                            border-radius: 25px;
                            font-weight: bold;
                            transition: transform 0.3s;
                        ">
                            Lihat Semua Artikel →
                        </a>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <h3>Belum ada artikel tersedia</h3>
                        <p>Silakan kembali nanti</p>
                    </div>
                <?php endif; ?>
            </div>

            <div class="sidebar">
                <h3 class="sidebar-title">Kategori</h3>
                <ul class="category-list">
                    <?php while($category = mysqli_fetch_assoc($categories)): 
                        // Hitung jumlah artikel per kategori
                        $count_query = mysqli_query($konek, 
                            "SELECT COUNT(*) as count FROM articles 
                             WHERE category_id = {$category['id']} AND is_published = 1");
                        $count = mysqli_fetch_assoc($count_query)['count'];
                    ?>
                        <li class="category-item">
                            <a href="article.php?category=<?php echo $category['id']; ?>" class="category-link">
                                <span><?php echo $category['name']; ?></span>
                                <span><?php echo $count; ?></span>
                            </a>
                        </li>
                    <?php endwhile; ?>
                </ul>
                
                <div style="margin-top: 30px;">
                    <h3 class="sidebar-title">Tentang Blog</h3>
                    <p style="font-size: 14px; color: #666; line-height: 1.6;">
                        Blog ini berisi artikel-artikel menarik tentang perkembangan teknologi terbaru, 
                        tutorial pemrograman, tips desain, dan strategi bisnis digital.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>MyBlog</h3>
                    <p>Platform berbagi pengetahuan dan inspirasi melalui artikel-artikel berkualitas.</p>
                </div>
                <div class="footer-section">
                    <h3>Kategori</h3>
                    <p>Teknologi<br>Pemrograman<br>Desain<br>Bisnis</p>
                </div>
                <div class="footer-section">
                    <h3>Link Cepat</h3>
                    <p>
                        <a href="index.php" style="color: white; text-decoration: none;">Beranda</a><br>
                        <a href="article.php" style="color: white; text-decoration: none;">Artikel</a><br>
                        <a href="../user/login.php" style="color: white; text-decoration: none;">Login</a><br>
                        <a href="../user/register.php" style="color: white; text-decoration: none;">Daftar</a>
                    </p>
                </div>
            </div>
            <div class="copyright">
                © <?php echo date('Y'); ?> MyBlog. Semua hak dilindungi.
            </div>
        </div>
    </div>
</body>
</html>