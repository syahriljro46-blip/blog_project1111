<?php
session_start();
require_once '../config/database.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($konek, $_POST['name']);
    $email = mysqli_real_escape_string($konek, $_POST['email']);
    $subject = mysqli_real_escape_string($konek, $_POST['subject']);
    $message = mysqli_real_escape_string($konek, $_POST['message']);
    
    // Validasi sederhana
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error = "Semua field harus diisi!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Format email tidak valid!";
    } else {
        // Simpan ke database (buat tabel contacts jika belum ada)
        $create_table = "CREATE TABLE IF NOT EXISTS contacts (
            id INT PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(255) NOT NULL,
            subject VARCHAR(200) NOT NULL,
            message TEXT NOT NULL,
            is_read BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        mysqli_query($konek, $create_table);
        
        // Insert pesan
        $insert_query = "INSERT INTO contacts (name, email, subject, message) 
                         VALUES ('$name', '$email', '$subject', '$message')";
        
        if (mysqli_query($konek, $insert_query)) {
            $success = "Pesan Anda telah berhasil dikirim! Kami akan membalas secepatnya.";
            
            // Reset form
            $_POST = array();
        } else {
            $error = "Gagal mengirim pesan. Silakan coba lagi.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kontak Kami - Blog</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #f8f9fa;
        }
        .header {
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
            text-decoration: none;
            color: white;
        }
        .nav-links {
            display: flex;
            gap: 20px;
            align-items: center;
        }
        .nav-links a {
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .nav-links a:hover {
            background: rgba(255,255,255,0.1);
        }
        .contact-hero {
            text-align: center;
            padding: 80px 20px;
        }
        .contact-hero h1 {
            font-size: 3em;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
        }
        .contact-hero p {
            font-size: 1.2em;
            max-width: 600px;
            margin: 0 auto;
            opacity: 0.9;
        }
        .contact-content {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            padding: 60px 0;
        }
        .contact-form {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
        }
        .form-title {
            font-size: 1.8em;
            margin-bottom: 30px;
            color: #333;
            position: relative;
        }
        .form-title:after {
            content: '';
            display: block;
            width: 60px;
            height: 4px;
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            margin-top: 10px;
            border-radius: 2px;
        }
        .form-group {
            margin-bottom: 25px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }
        .form-control {
            width: 100%;
            padding: 15px;
            border: 2px solid #e1e1e1;
            border-radius: 8px;
            font-size: 16px;
            font-family: inherit;
            transition: border 0.3s;
        }
        .form-control:focus {
            border-color: #fa709a;
            outline: none;
        }
        textarea.form-control {
            min-height: 150px;
            resize: vertical;
        }
        .submit-btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(250, 112, 154, 0.3);
        }
        .contact-info {
            padding: 20px 0;
        }
        .info-title {
            font-size: 1.8em;
            margin-bottom: 30px;
            color: #333;
            position: relative;
        }
        .info-title:after {
            content: '';
            display: block;
            width: 60px;
            height: 4px;
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            margin-top: 10px;
            border-radius: 2px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        .info-card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s;
        }
        .info-card:hover {
            transform: translateY(-5px);
        }
        .info-icon {
            font-size: 40px;
            margin-bottom: 20px;
            color: #fa709a;
        }
        .info-detail h3 {
            font-size: 1.1em;
            margin-bottom: 10px;
            color: #333;
        }
        .info-detail p {
            color: #666;
            font-size: 14px;
        }
        .faq-section {
            margin-top: 40px;
        }
        .faq-title {
            font-size: 1.5em;
            margin-bottom: 20px;
            color: #333;
        }
        .faq-item {
            background: white;
            margin-bottom: 15px;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .faq-question {
            padding: 20px;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-weight: 500;
            background: #f8f9fa;
            transition: background 0.3s;
        }
        .faq-question:hover {
            background: #f0f0f0;
        }
        .faq-answer {
            padding: 0 20px;
            max-height: 0;
            overflow: hidden;
            transition: all 0.3s;
        }
        .faq-answer.open {
            padding: 20px;
            max-height: 500px;
        }
        .faq-toggle {
            font-size: 20px;
            transition: transform 0.3s;
        }
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #28a745;
        }
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #dc3545;
        }
        .social-links {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 40px;
        }
        .social-link {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            text-decoration: none;
            transition: transform 0.3s;
        }
        .social-link:hover {
            transform: translateY(-5px);
        }
        .map-placeholder {
            background: white;
            height: 300px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #666;
            box-shadow: 0 3px 15px rgba(0,0,0,0.1);
            margin-top: 40px;
        }
        .footer {
            background: #333;
            color: white;
            padding: 60px 0 30px;
            margin-top: 80px;
        }
        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }
        .footer-section h3 {
            margin-bottom: 20px;
            color: #fa709a;
            font-size: 1.2em;
        }
        .footer-section p {
            opacity: 0.8;
            font-size: 14px;
            line-height: 1.6;
        }
        .copyright {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid #444;
            font-size: 14px;
            opacity: 0.7;
        }
        @media (max-width: 768px) {
            .contact-content {
                grid-template-columns: 1fr;
                gap: 40px;
            }
            .contact-hero h1 {
                font-size: 2.5em;
            }
            .contact-form {
                padding: 25px;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="navbar">
            <a href="index.php" class="logo">MyBlog</a>
            <div class="nav-links">
                <a href="index.php">Beranda</a>
                <a href="article.php">Artikel</a>
                <a href="search.php">Cari</a>
                <a href="about.php">Tentang</a>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="../user/dashboard.php">Dashboard</a>
                    <a href="../user/logout.php">Logout</a>
                <?php else: ?>
                    <a href="../user/login.php">Login</a>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="contact-hero">
            <h1>Hubungi Kami</h1>
            <p>Punya pertanyaan, saran, atau ingin bekerja sama? Kami siap membantu!</p>
        </div>
    </div>

    <div class="container">
        <div class="contact-content">
            <div class="contact-form">
                <h2 class="form-title">Kirim Pesan</h2>
                
                <?php if($success): ?>
                    <div class="success-message"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <?php if($error): ?>
                    <div class="error-message"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="name">Nama Lengkap</label>
                        <input type="text" id="name" name="name" class="form-control" 
                               value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" class="form-control" 
                               value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="subject">Subjek</label>
                        <input type="text" id="subject" name="subject" class="form-control" 
                               value="<?php echo isset($_POST['subject']) ? htmlspecialchars($_POST['subject']) : ''; ?>" 
                               required>
                    </div>
                    
                    <div class="form-group">
                        <label for="message">Pesan</label>
                        <textarea id="message" name="message" class="form-control" 
                                  required><?php echo isset($_POST['message']) ? htmlspecialchars($_POST['message']) : ''; ?></textarea>
                    </div>
                    
                    <button type="submit" class="submit-btn">Kirim Pesan</button>
                </form>
            </div>
            
            <div class="contact-info">
                <h2 class="info-title">Informasi Kontak</h2>
                
                <div class="info-grid">
                    <div class="info-card">
                        <div class="info-icon">📍</div>
                        <div class="info-detail">
                            <h3>Alamat</h3>
                            <p>Jl. Parjhugha No. 123<br>Madura, Indonesia</p>
                        </div>
                    </div>
                    
                    <div class="info-card">
                        <div class="info-icon">📧</div>
                        <div class="info-detail">
                            <h3>Email</h3>
                            <p>info@myblog.com<br>support@myblog.com</p>
                        </div>
                    </div>
                    
                    <div class="info-card">
                        <div class="info-icon">📱</div>
                        <div class="info-detail">
                            <h3>Telepon</h3>
                            <p>+62 812 3456 7890<br>+62 823 4567 8901</p>
                        </div>
                    </div>
                    
                    <div class="info-card">
                        <div class="info-icon">⏰</div>
                        <div class="info-detail">
                            <h3>Jam Operasional</h3>
                            <p>Senin - Jumat<br>08:00 - 17:00 WIB</p>
                        </div>
                    </div>
                </div>
                
                <div class="faq-section">
                    <h3 class="faq-title">Pertanyaan Umum</h3>
                    
                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFAQ(this)">
                            <span>Bagaimana cara bergabung sebagai penulis?</span>
                            <span class="faq-toggle">+</span>
                        </div>
                        <div class="faq-answer">
                            <p>Silakan kirim email ke syahril@myblog.com dengan CV dan contoh tulisan Anda. Tim kami akan meninjau dan menghubungi Anda dalam 3-5 hari kerja.</p>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFAQ(this)">
                            <span>Berapa lama waktu respon untuk pesan?</span>
                            <span class="faq-toggle">+</span>
                        </div>
                        <div class="faq-answer">
                            <p>Kami biasanya merespon dalam 24-48 jam kerja. Untuk urusan mendesak, silakan hubungi nomor telepon yang tersedia.</p>
                        </div>
                    </div>
                    
                    <div class="faq-item">
                        <div class="faq-question" onclick="toggleFAQ(this)">
                            <span>Bisakah saya menggunakan artikel untuk keperluan komersial?</span>
                            <span class="faq-toggle">+</span>
                        </div>
                        <div class="faq-answer">
                            <p>Konten kami dilisensikan di bawah Creative Commons. Untuk penggunaan komersial, silakan hubungi kami untuk persetujuan.</p>
                        </div>
                    </div>
                </div>
                
                <div class="social-links">
                    <a href="#" class="social-link">f</a>
                    <a href="#" class="social-link">t</a>
                    <a href="#" class="social-link">in</a>
                    <a href="#" class="social-link">ig</a>
                    <a href="#" class="social-link">yt</a>
                </div>
                
                <div class="map-placeholder">
                    📍 Peta Lokasi
                </div>
            </div>
        </div>
    </div>

    <div class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>MyBlog</h3>
                    <p>Platform berbagi pengetahuan dan inspirasi melalui artikel-artikel berkualitas tentang teknologi dan perkembangan digital.</p>
                </div>
                <div class="footer-section">
                    <h3>Kontak</h3>
                    <p>Email: info@myblog.com<br>Telepon: +62 812 3456 7890<br>Alamat: Jl. Teknologi No. 123, Jakarta</p>
                </div>
                <div class="footer-section">
                    <h3>Link Cepat</h3>
                    <p>
                        <a href="index.php" style="color: white; text-decoration: none;">Beranda</a><br>
                        <a href="article.php" style="color: white; text-decoration: none;">Artikel</a><br>
                        <a href="about.php" style="color: white; text-decoration: none;">Tentang Kami</a><br>
                        <a href="contact.php" style="color: white; text-decoration: none;">Kontak</a>
                    </p>
                </div>
            </div>
            <div class="copyright">
                © <?php echo date('Y'); ?> MyBlog. Semua hak dilindungi.
            </div>
        </div>
    </div>

    <script>
    function toggleFAQ(element) {
        const answer = element.parentElement.querySelector('.faq-answer');
        const toggle = element.querySelector('.faq-toggle');
        
        if (answer.classList.contains('open')) {
            answer.classList.remove('open');
            toggle.textContent = '+';
        } else {
            // Tutup semua FAQ lainnya
            document.querySelectorAll('.faq-answer.open').forEach(openAnswer => {
                openAnswer.classList.remove('open');
                openAnswer.parentElement.querySelector('.faq-toggle').textContent = '+';
            });
            
            answer.classList.add('open');
            toggle.textContent = '−';
        }
    }
    
    // Auto close form success message after 5 seconds
    setTimeout(() => {
        const successMsg = document.querySelector('.success-message');
        if (successMsg) {
            successMsg.style.display = 'none';
        }
    }, 5000);
    </script>
</body>
</html>