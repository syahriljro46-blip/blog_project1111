<?php
session_start();
require_once '../config/database.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../user/login.php?redirect=" . urlencode($_SERVER['REQUEST_URI']));
    exit();
}

// Ambil data dari POST request
$article_id = isset($_POST['article_id']) ? intval($_POST['article_id']) : 0;
$parent_id = isset($_POST['parent_id']) ? intval($_POST['parent_id']) : 0;
$content = isset($_POST['content']) ? trim($_POST['content']) : '';
$user_id = $_SESSION['user_id'];

// Validasi input
$errors = [];

if ($article_id <= 0) {
    $errors[] = "Artikel tidak valid!";
}

if (empty($content)) {
    $errors[] = "Komentar tidak boleh kosong!";
} elseif (strlen($content) > 1000) {
    $errors[] = "Komentar maksimal 1000 karakter!";
}

// Cek apakah artikel ada
if ($article_id > 0) {
    $article_check = "SELECT id, title, slug FROM articles WHERE id = $article_id AND is_published = 1";
    $article_result = mysqli_query($konek, $article_check);
    
    if (mysqli_num_rows($article_result) == 0) {
        $errors[] = "Artikel tidak ditemukan atau belum dipublish!";
    } else {
        $article = mysqli_fetch_assoc($article_result);
    }
}

// Cek apakah parent comment ada (jika reply)
if ($parent_id > 0) {
    $parent_check = "SELECT id FROM comments WHERE id = $parent_id AND article_id = $article_id";
    $parent_result = mysqli_query($konek, $parent_check);
    
    if (mysqli_num_rows($parent_result) == 0) {
        $errors[] = "Komentar yang dibalas tidak ditemukan!";
    }
}

// Jika tidak ada error, simpan komentar
if (empty($errors)) {
    $content_escaped = mysqli_real_escape_string($konek, $content);
    
    // Insert komentar
    $query = "INSERT INTO comments (article_id, user_id, parent_id, content, is_approved) 
              VALUES ($article_id, $user_id, " . ($parent_id > 0 ? $parent_id : 'NULL') . ", '$content_escaped', 0)";
    
    if (mysqli_query($konek, $query)) {
        $comment_id = mysqli_insert_id($konek);
        
        // Update comment count di artikel (jika ada view count)
        $update_query = "UPDATE articles SET updated_at = NOW() WHERE id = $article_id";
        mysqli_query($konek, $update_query);
        
        // Prepare response
        $response = [
            'success' => true,
            'message' => 'Komentar berhasil dikirim! Menunggu persetujuan admin.',
            'comment_id' => $comment_id,
            'user_name' => $_SESSION['user_username'],
            'content' => htmlspecialchars($content),
            'timestamp' => date('Y-m-d H:i:s')
        ];
    } else {
        $response = [
            'success' => false,
            'message' => 'Gagal menyimpan komentar: ' . mysqli_error($konek)
        ];
    }
} else {
    $response = [
        'success' => false,
        'message' => implode('<br>', $errors)
    ];
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);

// Jika request bukan AJAX, redirect back
if (!isset($_SERVER['HTTP_X_REQUESTED_WITH']) || strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
    if (isset($article)) {
        header("Location: post.php?slug=" . $article['slug'] . "#comments");
    } else {
        header("Location: index.php");
    }
    exit();
}
?>