<?php
session_start();
require_once '../config/database.php';

// Ambil parameter dari URL
$article_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$article_slug = isset($_GET['slug']) ? $_GET['slug'] : '';

// Jika ada slug, cari artikel berdasarkan slug
if (!empty($article_slug)) {
    $query = "SELECT 
                a.*,
                c.name as category_name,
                c.slug as category_slug,
                ad.username as author_name,
                ad.full_name as author_full_name,
                GROUP_CONCAT(DISTINCT t.name) as tag_names
              FROM articles a
              LEFT JOIN categories c ON a.category_id = c.id
              LEFT JOIN admins ad ON a.author_id = ad.id
              LEFT JOIN article_tags at ON a.id = at.article_id
              LEFT JOIN tags t ON at.tag_id = t.id
              WHERE a.slug = '$article_slug' AND a.is_published = 1
              GROUP BY a.id";
} else if ($article_id > 0) {
    $query = "SELECT 
                a.*,
                c.name as category_name,
                c.slug as category_slug,
                ad.username as author_name,
                ad.full_name as author_full_name,
                GROUP_CONCAT(DISTINCT t.name) as tag_names
              FROM articles a
              LEFT JOIN categories c ON a.category_id = c.id
              LEFT JOIN admins ad ON a.author_id = ad.id
              LEFT JOIN article_tags at ON a.id = at.article_id
              LEFT JOIN tags t ON at.tag_id = t.id
              WHERE a.id = $article_id AND a.is_published = 1
              GROUP BY a.id";
} else {
    die("Artikel tidak ditemukan!");
}

$result = mysqli_query($konek, $query);

if (mysqli_num_rows($result) == 0) {
    die("Artikel tidak ditemukan!");
}

$article = mysqli_fetch_assoc($result);

// Update view count
$update_view = "UPDATE articles SET view_count = view_count + 1 WHERE id = {$article['id']}";
mysqli_query($konek, $update_view);

// Set social media share URLs
$current_url = urlencode("https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");
$article_title = urlencode($article['title']);
$article_excerpt = urlencode(substr(strip_tags($article['excerpt']), 0, 200));

$share_urls = [
    'facebook' => "https://www.facebook.com/sharer/sharer.php?u=$current_url",
    'twitter' => "https://twitter.com/intent/tweet?url=$current_url&text=$article_title",
    'linkedin' => "https://www.linkedin.com/shareArticle?mini=true&url=$current_url&title=$article_title&summary=$article_excerpt",
    'whatsapp' => "https://api.whatsapp.com/send?text=$article_title%20$current_url",
    'telegram' => "https://t.me/share/url?url=$current_url&text=$article_title",
    'email' => "mailto:?subject=$article_title&body=$article_title%0A%0A$current_url"
];

// Generate QR Code URL
$qr_code_url = "https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=" . urlencode("https://$_SERVER[HTTP_HOST]/post.php?slug={$article['slug']}");

// Jika request untuk download/share, handle action
if (isset($_GET['action'])) {
    $action = $_GET['action'];
    
    switch ($action) {
        case 'download_pdf':
            generatePDF($article);
            break;
        case 'download_image':
            generateShareImage($article);
            break;
        case 'print':
            generatePrintView($article);
            break;
        case 'embed':
            generateEmbedCode($article);
            break;
    }
    exit();
}

// Function untuk generate PDF (simplified version)
function generatePDF($article) {
    require_once('../vendor/autoload.php'); // Butuh library seperti TCPDF atau Dompdf
    
    // Ini contoh sederhana, dalam implementasi real butuh library PDF
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $article['slug'] . '.pdf"');
    
    $html = '<h1>' . htmlspecialchars($article['title']) . '</h1>';
    $html .= '<p>' . htmlspecialchars($article['excerpt']) . '</p>';
    $html .= '<p>Dibagikan dari: ' . $_SERVER['HTTP_HOST'] . '</p>';
    
    echo $html;
    exit();
}

// Function untuk generate share image
function generateShareImage($article) {
    // Ini contoh sederhana, dalam implementasi real butuh GD library atau ImageMagick
    header('Content-Type: image/jpeg');
    header('Content-Disposition: attachment; filename="share-' . $article['slug'] . '.jpg"');
    
    // Create a simple image with text
    $width = 800;
    $height = 400;
    $image = imagecreate($width, $height);
    
    // Colors
    $background = imagecolorallocate($image, 41, 128, 185);
    $text_color = imagecolorallocate($image, 255, 255, 255);
    
    // Add text
    imagestring($image, 5, 50, 150, htmlspecialchars($article['title']), $text_color);
    imagestring($image, 3, 50, 200, $_SERVER['HTTP_HOST'], $text_color);
    
    imagejpeg($image);
    imagedestroy($image);
    exit();
}

// Function untuk print view
function generatePrintView($article) {
    header('Content-Type: text/html; charset=utf-8');
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo htmlspecialchars($article['title']); ?> - Print</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            .print-only { display: block; }
            .no-print { display: none; }
            @media print {
                .no-print { display: none; }
                .print-only { display: block; }
            }
        </style>
    </head>
    <body>
        <div class="no-print" style="text-align: center; margin-bottom: 20px;">
            <button onclick="window.print()">Cetak</button>
            <button onclick="window.close()">Tutup</button>
        </div>
        
        <h1><?php echo htmlspecialchars($article['title']); ?></h1>
        <p><strong>Penulis:</strong> <?php echo htmlspecialchars($article['author_name']); ?></p>
        <p><strong>Tanggal:</strong> <?php echo date('d M Y', strtotime($article['created_at'])); ?></p>
        <hr>
        
        <div>
            <?php echo $article['content']; ?>
        </div>
        
        <hr>
        <p class="print-only">
            <small>Dicetak dari: <?php echo $_SERVER['HTTP_HOST']; ?><br>
            URL: https://<?php echo $_SERVER['HTTP_HOST']; ?>/post.php?slug=<?php echo $article['slug']; ?><br>
            Tanggal cetak: <?php echo date('d M Y H:i:s'); ?></small>
        </p>
        
        <script>
            window.onload = function() {
                window.print();
            }
        </script>
    </body>
    </html>
    <?php
    exit();
}

// Function untuk embed code
function generateEmbedCode($article) {
    $embed_code = htmlspecialchars('<iframe src="https://' . $_SERVER['HTTP_HOST'] . '/embed.php?slug=' . $article['slug'] . '" width="600" height="400" frameborder="0"></iframe>');
    
    echo '<pre>' . $embed_code . '</pre>';
    echo '<p>Salin kode di atas untuk menanamkan artikel di website Anda.</p>';
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bagikan: <?php echo htmlspecialchars($article['title']); ?> - Blog</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .share-container {
            background: white;
            border-radius: 20px;
            padding: 40px;
            max-width: 800px;
            width: 100%;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            animation: slideUp 0.5s ease-out;
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .article-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .article-header h1 {
            color: #2c3e50;
            font-size: 28px;
            margin-bottom: 15px;
            line-height: 1.4;
        }

        .article-meta {
            color: #7f8c8d;
            font-size: 14px;
            margin-bottom: 20px;
        }

        .article-meta i {
            margin-right: 5px;
        }

        .share-section {
            margin-bottom: 40px;
        }

        .share-section h2 {
            color: #2c3e50;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .share-section h2 i {
            color: #667eea;
        }

        /* Social Media Buttons */
        .social-buttons {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }

        .social-btn {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
            border-radius: 15px;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
            text-align: center;
        }

        .social-btn:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.2);
        }

        .social-btn i {
            font-size: 32px;
            margin-bottom: 10px;
        }

        .social-btn span {
            font-size: 14px;
            font-weight: 500;
        }

        .facebook { background: #3b5998; }
        .twitter { background: #1da1f2; }
        .linkedin { background: #0077b5; }
        .whatsapp { background: #25d366; }
        .telegram { background: #0088cc; }
        .email { background: #ea4335; }

        /* Copy Link Section */
        .copy-link {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
        }

        .copy-link input {
            flex: 1;
            padding: 12px 15px;
            border: 2px solid #ddd;
            border-radius: 10px;
            font-size: 14px;
        }

        .copy-link button {
            padding: 12px 24px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            font-weight: 500;
            transition: background 0.3s;
        }

        .copy-link button:hover {
            background: #5a6fd8;
        }

        /* QR Code */
        .qr-section {
            text-align: center;
            margin-bottom: 40px;
        }

        .qr-code {
            background: white;
            padding: 20px;
            border-radius: 15px;
            display: inline-block;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 15px;
        }

        .qr-code img {
            width: 200px;
            height: 200px;
        }

        /* Download Options */
        .download-options {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }

        .download-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            padding: 15px;
            background: #f8f9fa;
            border: 2px solid #e9ecef;
            border-radius: 10px;
            color: #495057;
            text-decoration: none;
            transition: all 0.3s;
        }

        .download-btn:hover {
            background: #e9ecef;
            border-color: #dee2e6;
            transform: translateY(-3px);
        }

        .download-btn i {
            font-size: 20px;
        }

        /* Article Preview */
        .article-preview {
            background: #f8f9fa;
            border-radius: 15px;
            padding: 25px;
            margin-top: 40px;
            border-left: 5px solid #667eea;
        }

        .article-preview h3 {
            color: #2c3e50;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .article-preview h3 i {
            color: #667eea;
        }

        .preview-content {
            color: #495057;
            line-height: 1.6;
            margin-bottom: 15px;
        }

        .preview-meta {
            display: flex;
            gap: 15px;
            font-size: 13px;
            color: #6c757d;
        }

        .preview-meta span {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        /* Actions */
        .actions {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 30px;
        }

        .action-btn {
            padding: 12px 24px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .action-btn.primary {
            background: #667eea;
            color: white;
        }

        .action-btn.primary:hover {
            background: #5a6fd8;
            transform: translateY(-2px);
        }

        .action-btn.secondary {
            background: #f8f9fa;
            color: #495057;
            border: 2px solid #dee2e6;
        }

        .action-btn.secondary:hover {
            background: #e9ecef;
        }

        /* Tags */
        .tags {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 20px;
        }

        .tag {
            background: #e3f2fd;
            color: #1976d2;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            text-decoration: none;
            transition: all 0.3s;
        }

        .tag:hover {
            background: #bbdefb;
            transform: scale(1.05);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .share-container {
                padding: 25px;
            }
            
            .article-header h1 {
                font-size: 22px;
            }
            
            .social-buttons {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .download-options {
                grid-template-columns: 1fr;
            }
            
            .copy-link {
                flex-direction: column;
            }
            
            .actions {
                flex-direction: column;
            }
            
            .preview-meta {
                flex-direction: column;
                gap: 8px;
            }
        }

        @media (max-width: 480px) {
            .social-buttons {
                grid-template-columns: 1fr;
            }
            
            .share-container {
                padding: 20px;
            }
        }

        /* Toast Notification */
        .toast {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #4caf50;
            color: white;
            padding: 15px 25px;
            border-radius: 10px;
            display: none;
            align-items: center;
            gap: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            z-index: 1000;
            animation: slideIn 0.3s ease-out;
        }

        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        /* Share Stats */
        .share-stats {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin: 30px 0;
            text-align: center;
        }

        .stat-item {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .stat-number {
            font-size: 24px;
            font-weight: bold;
            color: #667eea;
        }

        .stat-label {
            font-size: 12px;
            color: #7f8c8d;
            text-transform: uppercase;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="share-container">
        <!-- Article Header -->
        <div class="article-header">
            <h1><?php echo htmlspecialchars($article['title']); ?></h1>
            <div class="article-meta">
                <span><i class="fas fa-user"></i> <?php echo htmlspecialchars($article['author_name']); ?></span>
                <span style="margin: 0 10px;">•</span>
                <span><i class="fas fa-calendar"></i> <?php echo date('d M Y', strtotime($article['created_at'])); ?></span>
                <span style="margin: 0 10px;">•</span>
                <span><i class="fas fa-eye"></i> <?php echo number_format($article['view_count'] + 1); ?> dilihat</span>
            </div>
        </div>

        <!-- Share Statistics -->
        <div class="share-stats">
            <div class="stat-item">
                <div class="stat-number"><?php echo number_format($article['view_count'] + 1); ?></div>
                <div class="stat-label">Total Views</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">
                    <?php
                    $comment_count_query = "SELECT COUNT(*) as count FROM comments WHERE article_id = {$article['id']}";
                    $comment_count_result = mysqli_query($konek, $comment_count_query);
                    $comment_count = mysqli_fetch_assoc($comment_count_result);
                    echo number_format($comment_count['count']);
                    ?>
                </div>
                <div class="stat-label">Komentar</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">
                    <?php
                    $like_count_query = "SELECT COUNT(*) as count FROM article_likes WHERE article_id = {$article['id']}";
                    $like_count_result = mysqli_query($konek, $like_count_query);
                    $like_count = mysqli_fetch_assoc($like_count_result);
                    echo number_format($like_count['count']);
                    ?>
                </div>
                <div class="stat-label">Likes</div>
            </div>
        </div>

        <!-- Social Media Share -->
        <div class="share-section">
            <h2><i class="fas fa-share-alt"></i> Bagikan via Media Sosial</h2>
            <div class="social-buttons">
                <a href="<?php echo $share_urls['facebook']; ?>" target="_blank" class="social-btn facebook">
                    <i class="fab fa-facebook-f"></i>
                    <span>Facebook</span>
                </a>
                <a href="<?php echo $share_urls['twitter']; ?>" target="_blank" class="social-btn twitter">
                    <i class="fab fa-twitter"></i>
                    <span>Twitter</span>
                </a>
                <a href="<?php echo $share_urls['linkedin']; ?>" target="_blank" class="social-btn linkedin">
                    <i class="fab fa-linkedin-in"></i>
                    <span>LinkedIn</span>
                </a>
                <a href="<?php echo $share_urls['whatsapp']; ?>" target="_blank" class="social-btn whatsapp">
                    <i class="fab fa-whatsapp"></i>
                    <span>WhatsApp</span>
                </a>
                <a href="<?php echo $share_urls['telegram']; ?>" target="_blank" class="social-btn telegram">
                    <i class="fab fa-telegram-plane"></i>
                    <span>Telegram</span>
                </a>
                <a href="<?php echo $share_urls['email']; ?>" class="social-btn email">
                    <i class="fas fa-envelope"></i>
                    <span>Email</span>
                </a>
            </div>
        </div>

        <!-- Copy Link -->
        <div class="share-section">
            <h2><i class="fas fa-link"></i> Salin Link</h2>
            <div class="copy-link">
                <input type="text" id="shareUrl" value="https://<?php echo $_SERVER['HTTP_HOST']; ?>/post.php?slug=<?php echo $article['slug']; ?>" readonly>
                <button onclick="copyToClipboard()">
                    <i class="fas fa-copy"></i> Salin
                </button>
            </div>
        </div>

        <!-- QR Code -->
        <div class="share-section qr-section">
            <h2><i class="fas fa-qrcode"></i> QR Code</h2>
            <div class="qr-code">
                <img src="<?php echo $qr_code_url; ?>" alt="QR Code">
            </div>
            <p>Scan QR Code untuk mengakses artikel</p>
        </div>

        <!-- Download Options -->
        <div class="share-section">
            <h2><i class="fas fa-download"></i> Download & Cetak</h2>
            <div class="download-options">
                <a href="share.php?slug=<?php echo $article['slug']; ?>&action=download_pdf" class="download-btn">
                    <i class="fas fa-file-pdf"></i>
                    <span>Download PDF</span>
                </a>
                <a href="share.php?slug=<?php echo $article['slug']; ?>&action=download_image" class="download-btn">
                    <i class="fas fa-image"></i>
                    <span>Share Image</span>
                </a>
                <a href="share.php?slug=<?php echo $article['slug']; ?>&action=print" target="_blank" class="download-btn">
                    <i class="fas fa-print"></i>
                    <span>Cetak Artikel</span>
                </a>
                <a href="share.php?slug=<?php echo $article['slug']; ?>&action=embed" class="download-btn">
                    <i class="fas fa-code"></i>
                    <span>Embed Code</span>
                </a>
            </div>
        </div>

        <!-- Article Preview -->
        <div class="article-preview">
            <h3><i class="fas fa-newspaper"></i> Preview Artikel</h3>
            <div class="preview-content">
                <?php 
                $excerpt = !empty($article['excerpt']) ? $article['excerpt'] : substr(strip_tags($article['content']), 0, 200) . '...';
                echo htmlspecialchars($excerpt);
                ?>
            </div>
            <div class="preview-meta">
                <span><i class="fas fa-folder"></i> <?php echo htmlspecialchars($article['category_name']); ?></span>
                <span><i class="fas fa-clock"></i> <?php echo date('H:i', strtotime($article['created_at'])); ?></span>
                <?php if(!empty($article['tag_names'])): ?>
                    <span><i class="fas fa-tags"></i> <?php echo htmlspecialchars($article['tag_names']); ?></span>
                <?php endif; ?>
            </div>
            
            <!-- Tags -->
            <?php if(!empty($article['tag_names'])): ?>
                <div class="tags">
                    <?php 
                    $tags = explode(',', $article['tag_names']);
                    foreach($tags as $tag):
                        $tag = trim($tag);
                        if(!empty($tag)):
                    ?>
                        <a href="search.php?tag=<?php echo urlencode($tag); ?>" class="tag">
                            <?php echo htmlspecialchars($tag); ?>
                        </a>
                    <?php 
                        endif;
                    endforeach; 
                    ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Actions -->
        <div class="actions">
            <a href="post.php?slug=<?php echo $article['slug']; ?>" class="action-btn primary">
                <i class="fas fa-book-open"></i> Baca Artikel Lengkap
            </a>
            <a href="index.php" class="action-btn secondary">
                <i class="fas fa-home"></i> Kembali ke Beranda
            </a>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toast" class="toast">
        <i class="fas fa-check-circle"></i>
        <span id="toastMessage">Link berhasil disalin!</span>
    </div>

    <script>
        // Copy to clipboard function
        function copyToClipboard() {
            const urlInput = document.getElementById('shareUrl');
            urlInput.select();
            urlInput.setSelectionRange(0, 99999); // For mobile devices
            
            try {
                const successful = document.execCommand('copy');
                showToast(successful ? 'Link berhasil disalin!' : 'Gagal menyalin link');
            } catch (err) {
                // Fallback for older browsers
                navigator.clipboard.writeText(urlInput.value)
                    .then(() => showToast('Link berhasil disalin!'))
                    .catch(() => showToast('Gagal menyalin link'));
            }
        }

        // Show toast notification
        function showToast(message) {
            const toast = document.getElementById('toast');
            const toastMessage = document.getElementById('toastMessage');
            
            toastMessage.textContent = message;
            toast.style.display = 'flex';
            
            setTimeout(() => {
                toast.style.display = 'none';
            }, 3000);
        }

        // Auto-select URL on click
        document.getElementById('shareUrl').addEventListener('click', function() {
            this.select();
        });

        // Share via Web Share API if available
        if (navigator.share) {
            // Add native share button
            const actionsDiv = document.querySelector('.actions');
            const nativeShareBtn = document.createElement('a');
            nativeShareBtn.className = 'action-btn primary';
            nativeShareBtn.innerHTML = '<i class="fas fa-share"></i> Bagikan (Native)';
            nativeShareBtn.style.background = '#25d366';
            
            nativeShareBtn.addEventListener('click', async () => {
                try {
                    await navigator.share({
                        title: '<?php echo addslashes($article['title']); ?>',
                        text: '<?php echo addslashes(substr(strip_tags($article['excerpt']), 0, 100)); ?>',
                        url: window.location.href,
                    });
                    showToast('Berhasil dibagikan!');
                } catch (err) {
                    console.log('Error sharing:', err);
                }
            });
            
            actionsDiv.insertBefore(nativeShareBtn, actionsDiv.firstChild);
        }

        // Add view count animation
        window.addEventListener('load', () => {
            const viewCount = document.querySelector('.stat-number:first-child');
            const finalCount = parseInt(viewCount.textContent.replace(/,/g, ''));
            let currentCount = 0;
            
            const increment = Math.ceil(finalCount / 50);
            const timer = setInterval(() => {
                currentCount += increment;
                if (currentCount >= finalCount) {
                    currentCount = finalCount;
                    clearInterval(timer);
                }
                viewCount.textContent = currentCount.toLocaleString();
            }, 20);
        });

        // Social media share tracking (simplified)
        document.querySelectorAll('.social-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                const platform = this.querySelector('span').textContent.toLowerCase();
                console.log(`Shared via ${platform}`);
                
                // In real implementation, you would send this to analytics
                // fetch('track_share.php', {
                //     method: 'POST',
                //     body: JSON.stringify({
                //         article_id: <?php echo $article['id']; ?>,
                //         platform: platform
                //     })
                // });
            });
        });
    </script>
</body>
</html>