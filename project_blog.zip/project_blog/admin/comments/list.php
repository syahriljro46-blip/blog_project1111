<?php
session_start();
require_once '../../config/database.php';

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

// Query untuk mendapatkan semua komentar dengan join ke artikel dan user
$query = "SELECT 
            c.*,
            a.title as article_title,
            a.slug as article_slug,
            u.username as user_name,
            u.full_name as user_full_name,
            u.email as user_email,
            p.username as admin_username
          FROM comments c
          JOIN articles a ON c.article_id = a.id
          JOIN users u ON c.user_id = u.id
          LEFT JOIN admins p ON a.author_id = p.id
          ORDER BY c.created_at DESC";
$result = mysqli_query($konek, $query);

// Hitung total komentar
$total_query = "SELECT COUNT(*) as total FROM comments";
$total_result = mysqli_query($konek, $total_query);
$total_data = mysqli_fetch_assoc($total_result);
$total_comments = $total_data['total'];

// Hitung komentar yang belum disetujui
$pending_query = "SELECT COUNT(*) as pending FROM comments WHERE is_approved = 0";
$pending_result = mysqli_query($konek, $pending_query);
$pending_data = mysqli_fetch_assoc($pending_result);
$pending_comments = $pending_data['pending'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Komentar - Admin Blog</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #1a237e 0%, #283593 100%);
            color: white;
            padding: 20px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 3px 0 15px rgba(0,0,0,0.1);
        }

        .logo {
            text-align: center;
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 30px;
        }

        .logo h2 {
            font-size: 24px;
            color: white;
        }

        .logo span {
            color: #64b5f6;
        }

        .nav-menu {
            list-style: none;
            padding: 0 20px;
        }

        .nav-menu li {
            margin-bottom: 5px;
        }

        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            color: #b3c5e7;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .nav-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: white;
        }

        .nav-menu a.active {
            background: rgba(100, 181, 246, 0.2);
            color: #64b5f6;
            border-left: 4px solid #64b5f6;
        }

        .nav-menu i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .header h1 {
            color: #2c3e50;
            font-size: 28px;
        }

        .header h1 i {
            color: #64b5f6;
            margin-right: 10px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-info a {
            color: #7f8c8d;
            text-decoration: none;
            transition: color 0.3s;
        }

        .user-info a:hover {
            color: #3498db;
        }

        /* Stats Cards */
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 20px;
            font-size: 24px;
        }

        .stat-icon.total {
            background: #e3f2fd;
            color: #1976d2;
        }

        .stat-icon.pending {
            background: #fff3e0;
            color: #f57c00;
        }

        .stat-icon.approved {
            background: #e8f5e9;
            color: #388e3c;
        }

        .stat-info h3 {
            font-size: 14px;
            color: #7f8c8d;
            margin-bottom: 5px;
        }

        .stat-info .number {
            font-size: 28px;
            font-weight: bold;
            color: #2c3e50;
        }

        /* Comments Table */
        .comments-table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .table-header {
            padding: 20px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .table-header h2 {
            color: #2c3e50;
        }

        .actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
            transition: all 0.3s;
        }

        .btn-primary {
            background: #2196f3;
            color: white;
        }

        .btn-primary:hover {
            background: #1976d2;
        }

        .btn-success {
            background: #4caf50;
            color: white;
        }

        .btn-danger {
            background: #f44336;
            color: white;
        }

        .btn-danger:hover {
            background: #d32f2f;
        }

        .btn-warning {
            background: #ff9800;
            color: white;
        }

        .btn-warning:hover {
            background: #f57c00;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: #f8f9fa;
        }

        th {
            padding: 15px;
            text-align: left;
            color: #2c3e50;
            font-weight: 600;
            border-bottom: 2px solid #eee;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
        }

        tr:hover {
            background: #f9f9f9;
        }

        .comment-content {
            max-width: 300px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }

        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }

        .badge-pending {
            background: #fff3e0;
            color: #f57c00;
        }

        .badge-approved {
            background: #e8f5e9;
            color: #388e3c;
        }

        .actions-cell {
            display: flex;
            gap: 8px;
        }

        .btn-small {
            padding: 5px 10px;
            font-size: 12px;
        }

        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            padding: 20px;
        }

        .pagination a, .pagination span {
            padding: 8px 16px;
            border-radius: 8px;
            text-decoration: none;
            color: #555;
            background: white;
            border: 1px solid #ddd;
            transition: all 0.3s;
        }

        .pagination a:hover {
            background: #2196f3;
            color: white;
            border-color: #2196f3;
        }

        .pagination .active {
            background: #2196f3;
            color: white;
            border-color: #2196f3;
        }

        /* No Comments */
        .no-comments {
            text-align: center;
            padding: 50px;
            color: #7f8c8d;
        }

        .no-comments i {
            font-size: 48px;
            margin-bottom: 20px;
            color: #bdc3c7;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .sidebar {
                width: 70px;
            }
            
            .main-content {
                margin-left: 70px;
            }
            
            .logo h2 {
                font-size: 0;
            }
            
            .logo h2:after {
                content: "B";
                font-size: 24px;
            }
            
            .nav-menu a span {
                display: none;
            }
            
            .nav-menu a i {
                margin-right: 0;
                font-size: 20px;
            }
        }

        @media (max-width: 768px) {
            .stats-cards {
                grid-template-columns: 1fr;
            }
            
            table {
                display: block;
                overflow-x: auto;
            }
            
            .header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Blog<span>Admin</span></h2>
            </div>
            <ul class="nav-menu">
                <li><a href="../dashboard.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="../article/index.php"><i class="fas fa-newspaper"></i> <span>Artikel</span></a></li>
                <li><a href="../categories/list.php"><i class="fas fa-folder"></i> <span>Kategori</span></a></li>
                <li><a href="../media/list.php"><i class="fas fa-image"></i> <span>Media</span></a></li>
                <li><a href="list.php" class="active"><i class="fas fa-comments"></i> <span>Komentar</span></a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <h1><i class="fas fa-comments"></i> Manajemen Komentar</h1>
                <div class="user-info">
                    <span>Halo, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="stats-cards">
                <div class="stat-card">
                    <div class="stat-icon total">
                        <i class="fas fa-comment"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Total Komentar</h3>
                        <div class="number"><?php echo $total_comments; ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon pending">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Menunggu Persetujuan</h3>
                        <div class="number"><?php echo $pending_comments; ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon approved">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Komentar Disetujui</h3>
                        <div class="number"><?php echo $total_comments - $pending_comments; ?></div>
                    </div>
                </div>
            </div>

            <!-- Comments Table -->
            <div class="comments-table">
                <div class="table-header">
                    <h2>Daftar Komentar</h2>
                    <div class="actions">
                        <?php if($pending_comments > 0): ?>
                            <a href="?action=approve_all" class="btn btn-success" onclick="return confirm('Setujui semua komentar yang belum disetujui?')">
                                <i class="fas fa-check-double"></i> Setujui Semua
                            </a>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if(mysqli_num_rows($result) > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Komentar</th>
                                <th>Artikel</th>
                                <th>User</th>
                                <th>Tanggal</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($comment = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td>#<?php echo $comment['id']; ?></td>
                                    <td class="comment-content" title="<?php echo htmlspecialchars($comment['content']); ?>">
                                        <?php echo htmlspecialchars(substr($comment['content'], 0, 100)); ?>...
                                    </td>
                                    <td>
                                        <a href="../../post.php?slug=<?php echo $comment['article_slug']; ?>" target="_blank">
                                            <?php echo htmlspecialchars($comment['article_title']); ?>
                                        </a>
                                    </td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($comment['user_name']); ?></strong><br>
                                        <small><?php echo htmlspecialchars($comment['user_email']); ?></small>
                                    </td>
                                    <td>
                                        <?php echo date('d M Y H:i', strtotime($comment['created_at'])); ?>
                                    </td>
                                    <td>
                                        <?php if($comment['is_approved']): ?>
                                            <span class="badge badge-approved">
                                                <i class="fas fa-check-circle"></i> Disetujui
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-pending">
                                                <i class="fas fa-clock"></i> Menunggu
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="actions-cell">
                                        <?php if(!$comment['is_approved']): ?>
                                            <a href="?action=approve&id=<?php echo $comment['id']; ?>" 
                                               class="btn btn-success btn-small"
                                               title="Setujui Komentar">
                                                <i class="fas fa-check"></i>
                                            </a>
                                        <?php else: ?>
                                            <a href="?action=unapprove&id=<?php echo $comment['id']; ?>" 
                                               class="btn btn-warning btn-small"
                                               title="Batalkan Persetujuan">
                                                <i class="fas fa-times"></i>
                                            </a>
                                        <?php endif; ?>
                                        <a href="delete.php?id=<?php echo $comment['id']; ?>" 
                                           class="btn btn-danger btn-small"
                                           onclick="return confirm('Hapus komentar ini?')"
                                           title="Hapus Komentar">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                        <a href="javascript:void(0)" 
                                           class="btn btn-primary btn-small"
                                           onclick="viewComment(<?php echo $comment['id']; ?>)"
                                           title="Lihat Detail">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="no-comments">
                        <i class="fas fa-comment-slash"></i>
                        <h3>Belum ada komentar</h3>
                        <p>Tidak ada komentar yang ditemukan.</p>
                    </div>
                <?php endif; ?>

                <!-- Pagination -->
                <div class="pagination">
                    <a href="#">&laquo; Prev</a>
                    <a href="#" class="active">1</a>
                    <a href="#">2</a>
                    <a href="#">3</a>
                    <a href="#">Next &raquo;</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal untuk melihat detail komentar -->
    <div id="commentModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:1000; align-items:center; justify-content:center;">
        <div style="background:white; padding:30px; border-radius:15px; max-width:500px; width:90%;">
            <h3>Detail Komentar</h3>
            <div id="commentDetail" style="margin:20px 0;"></div>
            <button onclick="closeModal()" style="background:#2196f3; color:white; border:none; padding:10px 20px; border-radius:8px; cursor:pointer;">Tutup</button>
        </div>
    </div>

    <script>
        function viewComment(id) {
            // AJAX untuk mengambil detail komentar
            fetch(`get_comment.php?id=${id}`)
                .then(response => response.json())
                .then(data => {
                    document.getElementById('commentDetail').innerHTML = `
                        <p><strong>Komentar:</strong> ${data.content}</p>
                        <p><strong>User:</strong> ${data.user_name} (${data.user_email})</p>
                        <p><strong>Artikel:</strong> ${data.article_title}</p>
                        <p><strong>Tanggal:</strong> ${data.created_at}</p>
                        <p><strong>Status:</strong> ${data.is_approved ? 'Disetujui' : 'Menunggu'}</p>
                    `;
                    document.getElementById('commentModal').style.display = 'flex';
                })
                .catch(error => console.error('Error:', error));
        }

        function closeModal() {
            document.getElementById('commentModal').style.display = 'none';
        }

        // Tutup modal saat klik di luar
        document.getElementById('commentModal').addEventListener('click', function(e) {
            if(e.target === this) {
                closeModal();
            }
        });

        // Handle URL actions
        const urlParams = new URLSearchParams(window.location.search);
        const action = urlParams.get('action');
        const id = urlParams.get('id');

        if(action === 'approve' && id) {
            approveComment(id);
        } else if(action === 'unapprove' && id) {
            unapproveComment(id);
        } else if(action === 'approve_all') {
            approveAllComments();
        }

        function approveComment(id) {
            fetch(`update_comment.php?action=approve&id=${id}`)
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        location.reload();
                    }
                });
        }

        function unapproveComment(id) {
            fetch(`update_comment.php?action=unapprove&id=${id}`)
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        location.reload();
                    }
                });
        }

        function approveAllComments() {
            fetch(`update_comment.php?action=approve_all`)
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        location.reload();
                    }
                });
        }
    </script>
</body>
</html>

<?php
// Handle actions
if(isset($_GET['action'])) {
    $action = $_GET['action'];
    $comment_id = $_GET['id'] ?? 0;
    
    if($action == 'approve' && $comment_id) {
        $query = "UPDATE comments SET is_approved = 1 WHERE id = $comment_id";
        mysqli_query($konek, $query);
        header("Location: list.php?approved=true");
        exit();
    } 
    elseif($action == 'unapprove' && $comment_id) {
        $query = "UPDATE comments SET is_approved = 0 WHERE id = $comment_id";
        mysqli_query($konek, $query);
        header("Location: list.php?unapproved=true");
        exit();
    }
    elseif($action == 'approve_all') {
        $query = "UPDATE comments SET is_approved = 1 WHERE is_approved = 0";
        mysqli_query($konek, $query);
        header("Location: list.php?approved_all=true");
        exit();
    }
}

// Tampilkan pesan sukses jika ada
if(isset($_GET['approved'])) {
    echo "<script>alert('Komentar berhasil disetujui!');</script>";
}
if(isset($_GET['unapproved'])) {
    echo "<script>alert('Status komentar berhasil diubah!');</script>";
}
if(isset($_GET['approved_all'])) {
    echo "<script>alert('Semua komentar berhasil disetujui!');</script>";
}
?>