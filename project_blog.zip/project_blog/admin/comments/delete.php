<?php
session_start();
require_once '../../config/database.php';

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

// Ambil ID komentar dari URL
$comment_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($comment_id <= 0) {
    header("Location: list.php?error=invalid_id");
    exit();
}

// Cek apakah komentar ada
$check_query = "SELECT * FROM comments WHERE id = $comment_id";
$check_result = mysqli_query($konek, $check_query);

if (mysqli_num_rows($check_result) == 0) {
    header("Location: list.php?error=comment_not_found");
    exit();
}

// Ambil data komentar untuk log
$comment_data = mysqli_fetch_assoc($check_result);

// Hapus komentar
$delete_query = "DELETE FROM comments WHERE id = $comment_id";
$delete_result = mysqli_query($konek, $delete_query);

if ($delete_result) {
    // Log aktivitas (opsional)
    $admin_id = $_SESSION['admin_id'];
    $log_query = "INSERT INTO admin_logs (admin_id, action, details, created_at) 
                  VALUES ($admin_id, 'delete_comment', 'Menghapus komentar ID: $comment_id', NOW())";
    mysqli_query($konek, $log_query);
    
    header("Location: list.php?success=deleted");
    exit();
} else {
    header("Location: list.php?error=delete_failed");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menghapus Komentar...</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .loading-container {
            text-align: center;
            color: white;
            background: rgba(255, 255, 255, 0.1);
            padding: 50px;
            border-radius: 20px;
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .spinner {
            width: 60px;
            height: 60px;
            border: 5px solid rgba(255, 255, 255, 0.3);
            border-top: 5px solid white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto 20px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        h1 {
            margin-bottom: 20px;
            font-size: 24px;
        }

        p {
            opacity: 0.8;
            margin-bottom: 30px;
        }

        .back-link {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border: 2px solid white;
            border-radius: 50px;
            transition: all 0.3s;
            display: inline-block;
        }

        .back-link:hover {
            background: white;
            color: #764ba2;
        }
    </style>
</head>
<body>
    <div class="loading-container">
        <div class="spinner"></div>
        <h1>Menghapus Komentar...</h1>
        <p>Sedang memproses permintaan Anda. Harap tunggu sebentar.</p>
        <a href="list.php" class="back-link">Kembali ke Daftar Komentar</a>
    </div>
    
    <script>
        // Redirect otomatis setelah 2 detik
        setTimeout(function() {
            window.location.href = 'list.php';
        }, 2000);
    </script>
</body>
</html>