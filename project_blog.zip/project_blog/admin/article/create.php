<?php
session_start();
require_once '../../config/database.php';

// Cek jika belum login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];
$error = '';
$success = '';

// Ambil kategori untuk dropdown
$categories = mysqli_query($konek, "SELECT * FROM categories ORDER BY name");

// Generate slug dari judul
function createSlug($text) {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    $text = strtolower($text);
    
    if (empty($text)) {
        return 'n-a';
    }
    
    return $text;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = mysqli_real_escape_string($konek, $_POST['title']);
    $slug = mysqli_real_escape_string($konek, $_POST['slug']);
    $content = mysqli_real_escape_string($konek, $_POST['content']);
    $excerpt = mysqli_real_escape_string($konek, $_POST['excerpt']);
    $category_id = intval($_POST['category_id']);
    $is_published = isset($_POST['is_published']) ? 1 : 0;
    
    // Validasi
    if (empty($title) || empty($content)) {
        $error = "Judul dan konten harus diisi!";
    } else {
        // Generate slug jika kosong
        if (empty($slug)) {
            $slug = createSlug($title);
        }
        
        // Cek slug unik
        $slug_check = mysqli_query($konek, "SELECT id FROM articles WHERE slug = '$slug'");
        if (mysqli_num_rows($slug_check) > 0) {
            $slug = $slug . '-' . time();
        }
        
        // Handle featured image upload
        $featured_image = '';
        if (isset($_FILES['featured_image']) && $_FILES['featured_image']['error'] == 0) {
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $file_type = $_FILES['featured_image']['type'];
            
            if (in_array($file_type, $allowed_types)) {
                $upload_dir = '../../uploads/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                
                $file_extension = pathinfo($_FILES['featured_image']['name'], PATHINFO_EXTENSION);
                $filename = 'article_' . time() . '_' . uniqid() . '.' . $file_extension;
                $destination = $upload_dir . $filename;
                
                if (move_uploaded_file($_FILES['featured_image']['tmp_name'], $destination)) {
                    $featured_image = $filename;
                }
            }
        }
        
        // Set published_at jika dipublikasi
        $published_at = $is_published ? date('Y-m-d H:i:s') : NULL;
        
        // Insert ke database
        $query = "INSERT INTO articles (title, slug, content, excerpt, featured_image, 
                                        category_id, author_id, is_published, published_at) 
                  VALUES ('$title', '$slug', '$content', '$excerpt', '$featured_image', 
                          '$category_id', $admin_id, $is_published, " . 
                          ($published_at ? "'$published_at'" : "NULL") . ")";
        
        if (mysqli_query($konek, $query)) {
            $article_id = mysqli_insert_id($konek);
            $success = "Artikel berhasil dibuat!";
            
            // Reset form jika sukses
            $_POST = array();
        } else {
            $error = "Gagal membuat artikel: " . mysqli_error($konek);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buat Artikel Baru - Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            color: #333;
        }
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            height: 100vh;
        }
        .logo {
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }
        .logo h2 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        .logo p {
            font-size: 12px;
            opacity: 0.8;
        }
        .nav-menu {
            list-style: none;
        }
        .nav-item {
            margin-bottom: 5px;
        }
        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        .nav-link:hover, .nav-link.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }
        .nav-icon {
            font-size: 18px;
        }
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }
        .header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-title h1 {
            font-size: 28px;
            color: #333;
            margin-bottom: 5px;
        }
        .page-title p {
            color: #666;
            font-size: 14px;
        }
        .btn-back {
            padding: 10px 20px;
            background: #f8f9fa;
            color: #333;
            text-decoration: none;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .form-group {
            margin-bottom: 25px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 5px;
            font-size: 16px;
            font-family: inherit;
            transition: border 0.3s;
        }
        .form-control:focus {
            border-color: #667eea;
            outline: none;
        }
        textarea.form-control {
            min-height: 150px;
            resize: vertical;
        }
        #content {
            min-height: 300px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
        }
        .slug-preview {
            background: #f8f9fa;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 14px;
            color: #666;
            margin-top: 5px;
            border: 1px solid #e1e1e1;
        }
        .slug-preview strong {
            color: #333;
        }
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .checkbox-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
        }
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        .btn-submit {
            padding: 15px 30px;
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
        }
        .btn-draft {
            padding: 15px 30px;
            background: #6c757d;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #dc3545;
        }
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #28a745;
        }
        .image-preview {
            margin-top: 10px;
            max-width: 300px;
            display: none;
        }
        .image-preview img {
            max-width: 100%;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .char-count {
            font-size: 12px;
            color: #666;
            text-align: right;
            margin-top: 5px;
        }
        .user-info {
            padding: 20px;
            text-align: center;
            border-top: 1px solid rgba(255,255,255,0.1);
            margin-top: 20px;
        }
        .user-avatar {
            width: 50px;
            height: 50px;
            background: white;
            border-radius: 50%;
            margin: 0 auto 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            font-weight: bold;
            font-size: 20px;
        }
        .logout-link {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background: rgba(255,255,255,0.1);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
        }
        @media (max-width: 768px) {
            .admin-container {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Admin Panel</h2>
                <p>MyBlog Management</p>
            </div>
            
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="../dashboard.php" class="nav-link">
                        <span class="nav-icon">📊</span>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="index.php" class="nav-link">
                        <span class="nav-icon">📝</span>
                        <span>Kelola Artikel</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="create.php" class="nav-link active">
                        <span class="nav-icon">✏️</span>
                        <span>Buat Artikel</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <span class="nav-icon">📚</span>
                        <span>Kategori</span>
                    </a>
                </li>
            </ul>
            
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($_SESSION['admin_username'], 0, 1)); ?>
                </div>
                <div>
                    <strong><?php echo $_SESSION['admin_username']; ?></strong>
                    <p style="font-size: 12px; opacity: 0.8; margin-top: 5px;">Administrator</p>
                </div>
                <a href="../logout.php" class="logout-link">Logout</a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div class="page-title">
                    <h1>Buat Artikel Baru</h1>
                    <p>Tulis artikel baru untuk blog Anda</p>
                </div>
                <a href="index.php" class="btn-back">← Kembali</a>
            </div>

            <?php if($error): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if($success): ?>
                <div class="success-message"><?php echo $success; ?></div>
            <?php endif; ?>

            <div class="form-container">
                <form method="POST" action="" enctype="multipart/form-data" id="articleForm">
                    <div class="form-group">
                        <label for="title">Judul Artikel *</label>
                        <input type="text" id="title" name="title" class="form-control" 
                               value="<?php echo isset($_POST['title']) ? htmlspecialchars($_POST['title']) : ''; ?>" 
                               required oninput="updateSlug()">
                        <div class="char-count" id="titleCount">0/255 karakter</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="slug">Slug URL</label>
                        <input type="text" id="slug" name="slug" class="form-control" 
                               value="<?php echo isset($_POST['slug']) ? htmlspecialchars($_POST['slug']) : ''; ?>"
                               placeholder="otomatis-terbuat-dari-judul">
                        <div class="slug-preview">
                            Preview: <strong id="slugPreview"><?php 
                                echo isset($_POST['slug']) && !empty($_POST['slug']) 
                                    ? htmlspecialchars($_POST['slug']) 
                                    : 'slug-akan-terbuat-otomatis'; 
                            ?></strong>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="category_id">Kategori</label>
                        <select id="category_id" name="category_id" class="form-control">
                            <option value="0">Pilih Kategori</option>
                            <?php while($category = mysqli_fetch_assoc($categories)): ?>
                                <option value="<?php echo $category['id']; ?>" 
                                    <?php echo (isset($_POST['category_id']) && $_POST['category_id'] == $category['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($category['name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="featured_image">Gambar Utama</label>
                        <input type="file" id="featured_image" name="featured_image" class="form-control" 
                               accept="image/*" onchange="previewImage(this)">
                        <div class="image-preview" id="imagePreview">
                            <img src="" alt="Preview">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="excerpt">Ringkasan (Excerpt)</label>
                        <textarea id="excerpt" name="excerpt" class="form-control" 
                                  rows="3"><?php echo isset($_POST['excerpt']) ? htmlspecialchars($_POST['excerpt']) : ''; ?></textarea>
                        <div class="char-count" id="excerptCount">0/500 karakter</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="content">Konten Artikel *</label>
                        <textarea id="content" name="content" class="form-control" 
                                  rows="15" required><?php echo isset($_POST['content']) ? htmlspecialchars($_POST['content']) : ''; ?></textarea>
                        <div class="char-count" id="contentCount">0 karakter</div>
                    </div>
                    
                    <div class="form-group">
                        <label class="checkbox-group">
                            <input type="checkbox" name="is_published" value="1" 
                                <?php echo (isset($_POST['is_published']) && $_POST['is_published'] == 1) ? 'checked' : ''; ?>>
                            <span>Publikasikan artikel sekarang</span>
                        </label>
                        <small style="color: #666; display: block; margin-top: 5px;">
                            Jika tidak dicentang, artikel akan disimpan sebagai draft
                        </small>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="submit" class="btn-submit">
                            Simpan & <?php echo (isset($_POST['is_published']) && $_POST['is_published'] == 1) ? 'Publikasikan' : 'Simpan Draft'; ?>
                        </button>
                        <button type="button" class="btn-draft" onclick="saveAsDraft()">
                            Simpan sebagai Draft
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    function updateSlug() {
        const title = document.getElementById('title').value;
        const slugInput = document.getElementById('slug');
        const slugPreview = document.getElementById('slugPreview');
        
        if (!slugInput.value) {
            // Generate slug dari judul
            let slug = title.toLowerCase()
                .replace(/[^\w\s]/gi, '')
                .replace(/\s+/g, '-')
                .replace(/-+/g, '-')
                .trim();
            
            slugPreview.textContent = slug || 'slug-akan-terbuat-otomatis';
        }
        
        // Update character count
        const titleCount = document.getElementById('titleCount');
        titleCount.textContent = title.length + '/255 karakter';
    }
    
    function previewImage(input) {
        const preview = document.getElementById('imagePreview');
        const previewImg = preview.querySelector('img');
        
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                previewImg.src = e.target.result;
                preview.style.display = 'block';
            }
            
            reader.readAsDataURL(input.files[0]);
        } else {
            preview.style.display = 'none';
            previewImg.src = '';
        }
    }
    
    function saveAsDraft() {
        document.querySelector('input[name="is_published"]').checked = false;
        document.getElementById('articleForm').submit();
    }
    
    // Update character counts
    document.getElementById('excerpt').addEventListener('input', function() {
        const count = this.value.length;
        document.getElementById('excerptCount').textContent = count + '/500 karakter';
    });
    
    document.getElementById('content').addEventListener('input', function() {
        const count = this.value.length;
        document.getElementById('contentCount').textContent = count + ' karakter';
    });
    
    // Initialize counts
    document.addEventListener('DOMContentLoaded', function() {
        updateSlug();
        document.getElementById('excerpt').dispatchEvent(new Event('input'));
        document.getElementById('content').dispatchEvent(new Event('input'));
    });
    
    // Auto-save draft (simple version)
    let autoSaveTimer;
    document.getElementById('content').addEventListener('input', function() {
        clearTimeout(autoSaveTimer);
        autoSaveTimer = setTimeout(function() {
            console.log('Auto-save triggered...');
            // Implement auto-save logic here
        }, 5000); // Save every 5 seconds of inactivity
    });
    </script>
</body>
</html>