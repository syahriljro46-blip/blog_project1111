<?php
session_start();
require_once '../../config/database.php';

// Cek jika belum login, redirect ke login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];

// Ambil parameter filter
$status = isset($_GET['status']) ? $_GET['status'] : 'all';
$category = isset($_GET['category']) ? intval($_GET['category']) : 0;
$search = isset($_GET['search']) ? mysqli_real_escape_string($konek, $_GET['search']) : '';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Query dasar
$query = "SELECT a.*, c.name as category_name, 
                 (SELECT COUNT(*) FROM comments WHERE article_id = a.id) as comment_count,
                 (SELECT COUNT(*) FROM article_likes WHERE article_id = a.id) as like_count
          FROM articles a 
          LEFT JOIN categories c ON a.category_id = c.id 
          WHERE a.author_id = $admin_id";

// Filter status
if ($status == 'published') {
    $query .= " AND a.is_published = 1";
} elseif ($status == 'draft') {
    $query .= " AND a.is_published = 0";
}

// Filter kategori
if ($category > 0) {
    $query .= " AND a.category_id = $category";
}

// Filter pencarian
if (!empty($search)) {
    $query .= " AND (a.title LIKE '%$search%' OR a.content LIKE '%$search%')";
}

// Hitung total
$count_query = "SELECT COUNT(*) as total FROM ($query) as count_table";
$count_result = mysqli_query($konek, $count_query);
$total_rows = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_rows / $limit);

// Tambahkan sorting dan limit
$query .= " ORDER BY a.created_at DESC LIMIT $limit OFFSET $offset";
$articles = mysqli_query($konek, $query);

// Ambil kategori untuk filter
$categories = mysqli_query($konek, "SELECT * FROM categories ORDER BY name");

// Hitung statistik
$total_published = mysqli_fetch_assoc(mysqli_query($konek, 
    "SELECT COUNT(*) as total FROM articles WHERE author_id = $admin_id AND is_published = 1"))['total'];
$total_draft = mysqli_fetch_assoc(mysqli_query($konek, 
    "SELECT COUNT(*) as total FROM articles WHERE author_id = $admin_id AND is_published = 0"))['total'];
$total_articles = $total_published + $total_draft;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Artikel - Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            color: #333;
        }
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        .logo {
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }
        .logo h2 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        .logo p {
            font-size: 12px;
            opacity: 0.8;
        }
        .nav-menu {
            list-style: none;
        }
        .nav-item {
            margin-bottom: 5px;
        }
        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        .nav-link:hover, .nav-link.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }
        .nav-icon {
            font-size: 18px;
        }
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }
        .header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .page-title h1 {
            font-size: 28px;
            color: #333;
            margin-bottom: 5px;
        }
        .page-title p {
            color: #666;
            font-size: 14px;
        }
        .btn-create {
            padding: 12px 25px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: transform 0.2s;
        }
        .btn-create:hover {
            transform: translateY(-2px);
        }
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            text-align: center;
            transition: transform 0.3s;
            border-top: 4px solid #667eea;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            font-size: 40px;
            margin-bottom: 15px;
            color: #667eea;
        }
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #333;
            margin: 10px 0;
        }
        .stat-label {
            font-size: 14px;
            color: #666;
        }
        .filter-section {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        .filter-form {
            display: flex;
            gap: 15px;
            align-items: flex-end;
            flex-wrap: wrap;
        }
        .filter-group {
            flex: 1;
            min-width: 200px;
        }
        .filter-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }
        select, input[type="text"] {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 5px;
            font-size: 14px;
            transition: border 0.3s;
        }
        select:focus, input[type="text"]:focus {
            border-color: #667eea;
            outline: none;
        }
        .btn-filter {
            padding: 12px 25px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: background 0.3s;
        }
        .btn-filter:hover {
            background: #5a6fd8;
        }
        .btn-reset {
            padding: 12px 20px;
            background: #f8f9fa;
            color: #666;
            border: 1px solid #ddd;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
        }
        .articles-table {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            overflow: hidden;
        }
        .table-header {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr 150px;
            padding: 20px;
            background: #f8f9fa;
            font-weight: 500;
            color: #555;
            border-bottom: 1px solid #eee;
        }
        .table-row {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr 150px;
            padding: 20px;
            border-bottom: 1px solid #eee;
            align-items: center;
        }
        .table-row:hover {
            background: #f8f9fa;
        }
        .article-title {
            font-weight: 500;
            color: #333;
        }
        .article-meta {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
        }
        .status-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        .status-published {
            background: #d4edda;
            color: #155724;
        }
        .status-draft {
            background: #fff3cd;
            color: #856404;
        }
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        .btn-action {
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 12px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }
        .btn-edit {
            background: #28a745;
            color: white;
        }
        .btn-delete {
            background: #dc3545;
            color: white;
        }
        .btn-view {
            background: #17a2b8;
            color: white;
        }
        .btn-action:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }
        .empty-state h3 {
            font-size: 1.5em;
            margin-bottom: 10px;
            color: #333;
        }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin: 30px 0;
            flex-wrap: wrap;
        }
        .page-link {
            padding: 10px 15px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            color: #333;
            text-decoration: none;
            transition: all 0.3s;
        }
        .page-link:hover {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        .page-link.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        .user-info {
            padding: 20px;
            text-align: center;
            border-top: 1px solid rgba(255,255,255,0.1);
            margin-top: 20px;
        }
        .user-avatar {
            width: 50px;
            height: 50px;
            background: white;
            border-radius: 50%;
            margin: 0 auto 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            font-weight: bold;
            font-size: 20px;
        }
        .logout-link {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background: rgba(255,255,255,0.1);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
        }
        @media (max-width: 1024px) {
            .sidebar {
                width: 200px;
            }
            .main-content {
                margin-left: 200px;
            }
        }
        @media (max-width: 768px) {
            .admin-container {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
            }
            .main-content {
                margin-left: 0;
            }
            .table-header, .table-row {
                grid-template-columns: 1fr;
                gap: 10px;
            }
            .filter-form {
                flex-direction: column;
            }
            .filter-group {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Admin Panel</h2>
                <p>MyBlog Management</p>
            </div>
            
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="../dashboard.php" class="nav-link">
                        <span class="nav-icon">📊</span>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="index.php" class="nav-link active">
                        <span class="nav-icon">📝</span>
                        <span>Kelola Artikel</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="categories/list.php" class="nav-link">
                        <span class="nav-icon">📚</span>
                        <span>Kategori</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="comments/list.phpt" class="nav-link">
                        <span class="nav-icon">💬</span>
                        <span>Komentar</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="user/list_user.php" class="nav-link">
                        <span class="nav-icon">👥</span>
                        <span>pengguna</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="posts/list.php" class="nav-link">
                        <span class="nav-icon">⚙️</span>
                        <span>pengaturan</span>
                    </a>
                </li>
            </ul>
            
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($_SESSION['admin_username'], 0, 1)); ?>
                </div>
                <div>
                    <strong><?php echo $_SESSION['admin_username']; ?></strong>
                    <p style="font-size: 12px; opacity: 0.8; margin-top: 5px;">Administrator</p>
                </div>
                <a href="../logout.php" class="logout-link">Logout</a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div class="page-title">
                    <h1>Kelola Artikel</h1>
                    <p>Kelola semua artikel yang Anda buat</p>
                </div>
                <a href="create.php" class="btn-create">
                    <span>+</span> Buat Artikel Baru
                </a>
            </div>

            <div class="stats-cards">
                <div class="stat-card">
                    <div class="stat-icon">📝</div>
                    <div class="stat-number"><?php echo $total_articles; ?></div>
                    <div class="stat-label">Total Artikel</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">📤</div>
                    <div class="stat-number"><?php echo $total_published; ?></div>
                    <div class="stat-label">Dipublikasi</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">📄</div>
                    <div class="stat-number"><?php echo $total_draft; ?></div>
                    <div class="stat-label">Draft</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">👁️</div>
                    <div class="stat-number">
                        <?php 
                        $total_views = mysqli_fetch_assoc(mysqli_query($konek, 
                            "SELECT SUM(view_count) as total FROM articles WHERE author_id = $admin_id"))['total'];
                        echo number_format($total_views ?: 0);
                        ?>
                    </div>
                    <div class="stat-label">Total Views</div>
                </div>
            </div>

            <div class="filter-section">
                <form method="GET" action="" class="filter-form">
                    <div class="filter-group">
                        <label>Status Artikel</label>
                        <select name="status">
                            <option value="all" <?php echo $status == 'all' ? 'selected' : ''; ?>>Semua Status</option>
                            <option value="published" <?php echo $status == 'published' ? 'selected' : ''; ?>>Dipublikasi</option>
                            <option value="draft" <?php echo $status == 'draft' ? 'selected' : ''; ?>>Draft</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Kategori</label>
                        <select name="category">
                            <option value="0">Semua Kategori</option>
                            <?php while($cat = mysqli_fetch_assoc($categories)): ?>
                                <option value="<?php echo $cat['id']; ?>" 
                                    <?php echo ($category == $cat['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Cari Artikel</label>
                        <input type="text" name="search" placeholder="Judul atau konten..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    
                    <button type="submit" class="btn-filter">Terapkan Filter</button>
                    
                    <?php if($status != 'all' || $category > 0 || !empty($search)): ?>
                        <a href="index.php" class="btn-reset">Reset</a>
                    <?php endif; ?>
                </form>
            </div>

            <?php if(mysqli_num_rows($articles) > 0): ?>
                <div class="articles-table">
                    <div class="table-header">
                        <div>Judul Artikel</div>
                        <div>Kategori</div>
                        <div>Status</div>
                        <div>Statistik</div>
                        <div>Aksi</div>
                    </div>
                    
                    <?php while($article = mysqli_fetch_assoc($articles)): ?>
                        <div class="table-row">
                            <div>
                                <div class="article-title"><?php echo htmlspecialchars($article['title']); ?></div>
                                <div class="article-meta">
                                    Dibuat: <?php echo date('d M Y', strtotime($article['created_at'])); ?>
                                    <?php if($article['published_at']): ?>
                                        | Dipublikasi: <?php echo date('d M Y', strtotime($article['published_at'])); ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div>
                                <?php if($article['category_name']): ?>
                                    <span style="background: #f0f0f0; padding: 5px 10px; border-radius: 3px; font-size: 12px;">
                                        <?php echo $article['category_name']; ?>
                                    </span>
                                <?php else: ?>
                                    <span style="color: #999; font-size: 12px;">Tidak ada kategori</span>
                                <?php endif; ?>
                            </div>
                            
                            <div>
                                <?php if($article['is_published']): ?>
                                    <span class="status-badge status-published">📤 Dipublikasi</span>
                                <?php else: ?>
                                    <span class="status-badge status-draft">📄 Draft</span>
                                <?php endif; ?>
                            </div>
                            
                            <div style="font-size: 12px; color: #666;">
                                <div>👁️ <?php echo number_format($article['view_count']); ?> views</div>
                                <div>❤️ <?php echo $article['like_count']; ?> likes</div>
                                <div>💬 <?php echo $article['comment_count']; ?> komentar</div>
                            </div>
                            
                            <div class="action-buttons">
                                <a href="edit.php?id=<?php echo $article['id']; ?>" class="btn-action btn-edit">Edit</a>
                                <a href="delete.php?id=<?php echo $article['id']; ?>" 
                                   class="btn-action btn-delete"
                                   onclick="return confirm('Yakin ingin menghapus artikel ini?')">Hapus</a>
                                <a href="../../public/post.php?id=<?php echo $article['id']; ?>" 
                                   target="_blank" class="btn-action btn-view">Lihat</a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>

                <?php if($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if($page > 1): ?>
                            <a href="?status=<?php echo $status; ?>&category=<?php echo $category; ?>&search=<?php echo urlencode($search); ?>&page=<?php echo $page-1; ?>" 
                               class="page-link">← Prev</a>
                        <?php endif; ?>
                        
                        <?php for($i = 1; $i <= $total_pages; $i++): ?>
                            <?php if($i == $page): ?>
                                <span class="page-link active"><?php echo $i; ?></span>
                            <?php else: ?>
                                <a href="?status=<?php echo $status; ?>&category=<?php echo $category; ?>&search=<?php echo urlencode($search); ?>&page=<?php echo $i; ?>" 
                                   class="page-link"><?php echo $i; ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if($page < $total_pages): ?>
                            <a href="?status=<?php echo $status; ?>&category=<?php echo $category; ?>&search=<?php echo urlencode($search); ?>&page=<?php echo $page+1; ?>" 
                               class="page-link">Next →</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
            <?php else: ?>
                <div class="empty-state">
                    <h3>Tidak ada artikel ditemukan</h3>
                    <p><?php 
                        if(!empty($search)) {
                            echo "Tidak ada artikel dengan kata kunci '" . htmlspecialchars($search) . "'";
                        } elseif($status == 'published') {
                            echo "Belum ada artikel yang dipublikasi";
                        } elseif($status == 'draft') {
                            echo "Belum ada artikel dalam draft";
                        } elseif($category > 0) {
                            echo "Belum ada artikel dalam kategori ini";
                        } else {
                            echo "Belum ada artikel. Mulai buat artikel pertama Anda!";
                        }
                    ?></p>
                    <a href="create.php" class="btn-create" style="margin-top: 20px;">Buat Artikel Pertama</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>