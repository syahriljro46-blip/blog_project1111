<?php
session_start();
require_once '../../config/database.php';

// Cek jika belum login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];
$error = '';
$success = '';

// Ambil ID artikel dari URL
$article_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($article_id == 0) {
    header("Location: index.php");
    exit();
}

// Ambil data artikel
$article_query = "SELECT * FROM articles WHERE id = $article_id AND author_id = $admin_id";
$article_result = mysqli_query($konek, $article_query);

if (mysqli_num_rows($article_result) == 0) {
    header("Location: index.php");
    exit();
}

$article = mysqli_fetch_assoc($article_result);

// Ambil kategori
$categories = mysqli_query($konek, "SELECT * FROM categories ORDER BY name");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = mysqli_real_escape_string($konek, $_POST['title']);
    $slug = mysqli_real_escape_string($konek, $_POST['slug']);
    $content = mysqli_real_escape_string($konek, $_POST['content']);
    $excerpt = mysqli_real_escape_string($konek, $_POST['excerpt']);
    $category_id = intval($_POST['category_id']);
    $is_published = isset($_POST['is_published']) ? 1 : 0;
    
    // Validasi
    if (empty($title) || empty($content)) {
        $error = "Judul dan konten harus diisi!";
    } else {
        // Generate slug jika kosong
        if (empty($slug)) {
            $slug = preg_replace('/[^\w\s]/', '', $title);
            $slug = strtolower(str_replace(' ', '-', $slug));
            $slug = preg_replace('/-+/', '-', $slug);
        }
        
        // Cek slug unik (kecuali untuk artikel ini)
        $slug_check = mysqli_query($konek, "SELECT id FROM articles WHERE slug = '$slug' AND id != $article_id");
        if (mysqli_num_rows($slug_check) > 0) {
            $slug = $slug . '-' . time();
        }
        
        // Handle featured image upload
        $featured_image = $article['featured_image'];
        if (isset($_FILES['featured_image']) && $_FILES['featured_image']['error'] == 0) {
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            $file_type = $_FILES['featured_image']['type'];
            
            if (in_array($file_type, $allowed_types)) {
                $upload_dir = '../../uploads/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }
                
                // Hapus gambar lama jika ada
                if ($featured_image && file_exists($upload_dir . $featured_image)) {
                    unlink($upload_dir . $featured_image);
                }
                
                $file_extension = pathinfo($_FILES['featured_image']['name'], PATHINFO_EXTENSION);
                $filename = 'article_' . time() . '_' . uniqid() . '.' . $file_extension;
                $destination = $upload_dir . $filename;
                
                if (move_uploaded_file($_FILES['featured_image']['tmp_name'], $destination)) {
                    $featured_image = $filename;
                }
            }
        }
        
        // Hapus gambar jika dicentang
        if (isset($_POST['remove_image']) && $_POST['remove_image'] == 1) {
            if ($featured_image && file_exists('../../uploads/' . $featured_image)) {
                unlink('../../uploads/' . $featured_image);
            }
            $featured_image = '';
        }
        
        // Set published_at jika dipublikasi
        $published_at = $article['published_at'];
        if ($is_published == 1 && $article['is_published'] == 0) {
            $published_at = date('Y-m-d H:i:s');
        } elseif ($is_published == 0) {
            $published_at = NULL;
        }
        
        // Update database
        $query = "UPDATE articles SET 
                    title = '$title',
                    slug = '$slug',
                    content = '$content',
                    excerpt = '$excerpt',
                    featured_image = '$featured_image',
                    category_id = '$category_id',
                    is_published = $is_published,
                    published_at = " . ($published_at ? "'$published_at'" : "NULL") . ",
                    updated_at = NOW()
                  WHERE id = $article_id AND author_id = $admin_id";
        
        if (mysqli_query($konek, $query)) {
            $success = "Artikel berhasil diperbarui!";
            // Refresh data artikel
            $article_result = mysqli_query($konek, $article_query);
            $article = mysqli_fetch_assoc($article_result);
        } else {
            $error = "Gagal memperbarui artikel: " . mysqli_error($konek);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Artikel - Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            color: #333;
        }
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            height: 100vh;
        }
        .logo {
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }
        .logo h2 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        .logo p {
            font-size: 12px;
            opacity: 0.8;
        }
        .nav-menu {
            list-style: none;
        }
        .nav-item {
            margin-bottom: 5px;
        }
        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        .nav-link:hover, .nav-link.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }
        .nav-icon {
            font-size: 18px;
        }
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }
        .header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-title h1 {
            font-size: 28px;
            color: #333;
            margin-bottom: 5px;
        }
        .page-title p {
            color: #666;
            font-size: 14px;
        }
        .btn-back {
            padding: 10px 20px;
            background: #f8f9fa;
            color: #333;
            text-decoration: none;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .form-group {
            margin-bottom: 25px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 5px;
            font-size: 16px;
            font-family: inherit;
            transition: border 0.3s;
        }
        .form-control:focus {
            border-color: #667eea;
            outline: none;
        }
        textarea.form-control {
            min-height: 150px;
            resize: vertical;
        }
        #content {
            min-height: 300px;
            font-family: 'Courier New', monospace;
            font-size: 14px;
        }
        .current-image {
            margin-top: 10px;
        }
        .current-image img {
            max-width: 300px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 5px;
        }
        .checkbox-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
        }
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        .btn-update {
            padding: 15px 30px;
            background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .btn-update:hover {
            transform: translateY(-2px);
        }
        .btn-delete {
            padding: 15px 30px;
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #dc3545;
        }
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #28a745;
        }
        .image-preview {
            margin-top: 10px;
            max-width: 300px;
            display: none;
        }
        .image-preview img {
            max-width: 100%;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .char-count {
            font-size: 12px;
            color: #666;
            text-align: right;
            margin-top: 5px;
        }
        .article-info {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .article-info p {
            margin-bottom: 5px;
            color: #666;
        }
        .user-info {
            padding: 20px;
            text-align: center;
            border-top: 1px solid rgba(255,255,255,0.1);
            margin-top: 20px;
        }
        .user-avatar {
            width: 50px;
            height: 50px;
            background: white;
            border-radius: 50%;
            margin: 0 auto 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            font-weight: bold;
            font-size: 20px;
        }
        .logout-link {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background: rgba(255,255,255,0.1);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
        }
        @media (max-width: 768px) {
            .admin-container {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Admin Panel</h2>
                <p>MyBlog Management</p>
            </div>
            
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="../dashboard.php" class="nav-link">
                        <span class="nav-icon">📊</span>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="index.php" class="nav-link">
                        <span class="nav-icon">📝</span>
                        <span>Kelola Artikel</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="create.php" class="nav-link">
                        <span class="nav-icon">✏️</span>
                        <span>Buat Artikel</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <span class="nav-icon">📚</span>
                        <span>Kategori</span>
                    </a>
                </li>
            </ul>
            
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($_SESSION['admin_username'], 0, 1)); ?>
                </div>
                <div>
                    <strong><?php echo $_SESSION['admin_username']; ?></strong>
                    <p style="font-size: 12px; opacity: 0.8; margin-top: 5px;">Administrator</p>
                </div>
                <a href="../logout.php" class="logout-link">Logout</a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div class="page-title">
                    <h1>Edit Artikel</h1>
                    <p>Perbarui artikel yang sudah ada</p>
                </div>
                <a href="index.php" class="btn-back">← Kembali ke Daftar</a>
            </div>

            <?php if($error): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if($success): ?>
                <div class="success-message"><?php echo $success; ?></div>
            <?php endif; ?>

            <div class="article-info">
                <p><strong>ID Artikel:</strong> <?php echo $article['id']; ?></p>
                <p><strong>Dibuat:</strong> <?php echo date('d M Y H:i', strtotime($article['created_at'])); ?></p>
                <p><strong>Terakhir Diperbarui:</strong> <?php echo date('d M Y H:i', strtotime($article['updated_at'])); ?></p>
                <p><strong>Views:</strong> <?php echo number_format($article['view_count']); ?></p>
                <p><strong>Status:</strong> 
                    <?php if($article['is_published']): ?>
                        <span style="color: #28a745;">📤 Dipublikasi</span>
                        <?php if($article['published_at']): ?>
                            pada <?php echo date('d M Y H:i', strtotime($article['published_at'])); ?>
                        <?php endif; ?>
                    <?php else: ?>
                        <span style="color: #ffc107;">📄 Draft</span>
                    <?php endif; ?>
                </p>
            </div>

            <div class="form-container">
                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="title">Judul Artikel *</label>
                        <input type="text" id="title" name="title" class="form-control" 
                               value="<?php echo htmlspecialchars($article['title']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="slug">Slug URL</label>
                        <input type="text" id="slug" name="slug" class="form-control" 
                               value="<?php echo htmlspecialchars($article['slug']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="category_id">Kategori</label>
                        <select id="category_id" name="category_id" class="form-control">
                            <option value="0">Pilih Kategori</option>
                            <?php 
                            mysqli_data_seek($categories, 0);
                            while($category = mysqli_fetch_assoc($categories)): 
                            ?>
                                <option value="<?php echo $category['id']; ?>" 
                                    <?php echo ($article['category_id'] == $category['id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($category['name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="featured_image">Gambar Utama</label>
                        <?php if($article['featured_image']): ?>
                            <div class="current-image">
                                <img src="../../uploads/<?php echo $article['featured_image']; ?>" 
                                     alt="Current Image" style="max-width: 300px;">
                                <div class="checkbox-group" style="margin-top: 10px;">
                                    <input type="checkbox" id="remove_image" name="remove_image" value="1">
                                    <label for="remove_image">Hapus gambar ini</label>
                                </div>
                            </div>
                        <?php endif; ?>
                        <input type="file" id="featured_image" name="featured_image" class="form-control" 
                               accept="image/*" style="margin-top: <?php echo $article['featured_image'] ? '10px' : '0'; ?>;">
                        <div class="image-preview" id="imagePreview">
                            <img src="" alt="Preview">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="excerpt">Ringkasan (Excerpt)</label>
                        <textarea id="excerpt" name="excerpt" class="form-control" rows="3"><?php echo htmlspecialchars($article['excerpt']); ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="content">Konten Artikel *</label>
                        <textarea id="content" name="content" class="form-control" rows="15" required><?php echo htmlspecialchars($article['content']); ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label class="checkbox-group">
                            <input type="checkbox" name="is_published" value="1" 
                                <?php echo $article['is_published'] ? 'checked' : ''; ?>>
                            <span>Publikasikan artikel</span>
                        </label>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn-update">Perbarui Artikel</button>
                        <a href="delete.php?id=<?php echo $article['id']; ?>" 
                           class="btn-delete"
                           onclick="return confirm('Yakin ingin menghapus artikel ini? Tindakan ini tidak dapat dibatalkan!')">
                            Hapus Artikel
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    function previewImage(input) {
        const preview = document.getElementById('imagePreview');
        const previewImg = preview.querySelector('img');
        
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            
            reader.onload = function(e) {
                previewImg.src = e.target.result;
                preview.style.display = 'block';
            }
            
            reader.readAsDataURL(input.files[0]);
        } else {
            preview.style.display = 'none';
            previewImg.src = '';
        }
    }
    
    document.getElementById('featured_image').addEventListener('change', function() {
        previewImage(this);
    });
    
    // Auto-save reminder
    let saveTimer;
    const contentTextarea = document.getElementById('content');
    
    contentTextarea.addEventListener('input', function() {
        clearTimeout(saveTimer);
        saveTimer = setTimeout(function() {
            console.log('Remember to save your changes!');
        }, 30000); // Remind every 30 seconds
    });
    </script>
</body>
</html>