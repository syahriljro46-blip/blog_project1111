<?php
session_start();
require_once '../../config/database.php';

// Cek jika belum login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];

// Ambil ID artikel dari URL
$article_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($article_id == 0) {
    header("Location: index.php");
    exit();
}

// Ambil data artikel untuk konfirmasi
$article_query = "SELECT * FROM articles WHERE id = $article_id AND author_id = $admin_id";
$article_result = mysqli_query($konek, $article_query);

if (mysqli_num_rows($article_result) == 0) {
    header("Location: index.php");
    exit();
}

$article = mysqli_fetch_assoc($article_result);

// Handle deletion
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['confirm_delete']) && $_POST['confirm_delete'] == 'yes') {
        // Hapus gambar jika ada
        if ($article['featured_image'] && file_exists('../../uploads/' . $article['featured_image'])) {
            unlink('../../uploads/' . $article['featured_image']);
        }
        
        // Hapus dari database
        $delete_query = "DELETE FROM articles WHERE id = $article_id AND author_id = $admin_id";
        
        if (mysqli_query($konek, $delete_query)) {
            // Redirect ke halaman artikel dengan pesan sukses
            header("Location: index.php?deleted=1");
            exit();
        } else {
            $error = "Gagal menghapus artikel: " . mysqli_error($konek);
        }
    } else {
        // Jika batal, redirect ke halaman artikel
        header("Location: index.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hapus Artikel - Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        .delete-container {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            max-width: 500px;
            width: 100%;
            text-align: center;
        }
        .warning-icon {
            font-size: 60px;
            color: #dc3545;
            margin-bottom: 20px;
        }
        .delete-title {
            font-size: 24px;
            color: #333;
            margin-bottom: 15px;
        }
        .delete-message {
            color: #666;
            line-height: 1.6;
            margin-bottom: 25px;
        }
        .article-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            text-align: left;
        }
        .article-info h4 {
            color: #333;
            margin-bottom: 10px;
            font-size: 18px;
        }
        .article-details {
            color: #666;
            font-size: 14px;
        }
        .article-details p {
            margin-bottom: 8px;
        }
        .delete-actions {
            display: flex;
            gap: 15px;
            justify-content: center;
        }
        .btn {
            padding: 15px 30px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }
        .btn-delete {
            background: #dc3545;
            color: white;
        }
        .btn-delete:hover {
            background: #c82333;
            transform: translateY(-2px);
        }
        .btn-cancel {
            background: #6c757d;
            color: white;
        }
        .btn-cancel:hover {
            background: #5a6268;
            transform: translateY(-2px);
        }
        .confirmation-text {
            background: #fff3cd;
            color: #856404;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #ffc107;
            font-size: 14px;
        }
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #dc3545;
        }
        .stats {
            display: flex;
            justify-content: space-around;
            margin-top: 15px;
            font-size: 12px;
            color: #666;
        }
        .stat-item {
            text-align: center;
        }
        .stat-number {
            font-size: 16px;
            font-weight: bold;
            color: #333;
            display: block;
        }
        @media (max-width: 480px) {
            .delete-container {
                padding: 25px;
            }
            .delete-actions {
                flex-direction: column;
            }
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="delete-container">
        <div class="warning-icon">⚠️</div>
        <h1 class="delete-title">Hapus Artikel</h1>
        
        <?php if(isset($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="confirmation-text">
            <strong>Peringatan!</strong> Tindakan ini tidak dapat dibatalkan. Semua data artikel termasuk gambar, komentar, dan likes akan dihapus permanen.
        </div>
        
        <div class="article-info">
            <h4>Artikel yang akan dihapus:</h4>
            <div class="article-details">
                <p><strong>Judul:</strong> <?php echo htmlspecialchars($article['title']); ?></p>
                <p><strong>ID:</strong> <?php echo $article['id']; ?></p>
                <p><strong>Dibuat:</strong> <?php echo date('d M Y', strtotime($article['created_at'])); ?></p>
                <p><strong>Status:</strong> 
                    <?php if($article['is_published']): ?>
                        <span style="color: #28a745;">Dipublikasi</span>
                    <?php else: ?>
                        <span style="color: #ffc107;">Draft</span>
                    <?php endif; ?>
                </p>
                
                <div class="stats">
                    <div class="stat-item">
                        <span class="stat-number"><?php echo number_format($article['view_count']); ?></span>
                        <span>Views</span>
                    </div>
                    <?php 
                    // Hitung jumlah komentar
                    $comment_count = mysqli_fetch_assoc(mysqli_query($konek, 
                        "SELECT COUNT(*) as count FROM comments WHERE article_id = $article_id"))['count'];
                    ?>
                    <div class="stat-item">
                        <span class="stat-number"><?php echo $comment_count; ?></span>
                        <span>Komentar</span>
                    </div>
                    <?php 
                    // Hitung jumlah likes
                    $like_count = mysqli_fetch_assoc(mysqli_query($konek, 
                        "SELECT COUNT(*) as count FROM article_likes WHERE article_id = $article_id"))['count'];
                    ?>
                    <div class="stat-item">
                        <span class="stat-number"><?php echo $like_count; ?></span>
                        <span>Likes</span>
                    </div>
                </div>
            </div>
        </div>
        
        <form method="POST" action="">
            <input type="hidden" name="confirm_delete" value="yes">
            
            <div class="delete-actions">
                <button type="submit" class="btn btn-delete" 
                        onclick="return confirm('Yakin 100% ingin menghapus artikel ini?')">
                    Ya, Hapus Permanen
                </button>
                <a href="index.php" class="btn btn-cancel">Batal</a>
            </div>
        </form>
        
        <p style="margin-top: 20px; font-size: 12px; color: #999;">
            Tip: Pertimbangkan untuk mengubah status menjadi draft daripada menghapus permanen.
        </p>
    </div>
</body>
</html>