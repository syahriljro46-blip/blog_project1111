<?php
session_start();
require_once '../../config/database.php';

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

// Ambil ID post dari URL
$post_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($post_id <= 0) {
    header("Location: list.php?error=invalid_id");
    exit();
}

// Ambil data post
$query = "SELECT * FROM articles WHERE id = $post_id";
$result = mysqli_query($konek, $query);

if (mysqli_num_rows($result) == 0) {
    header("Location: list.php?error=not_found");
    exit();
}

$post = mysqli_fetch_assoc($result);

// Ambil data kategori untuk dropdown
$categories_query = "SELECT * FROM categories ORDER BY name";
$categories_result = mysqli_query($konek, $categories_query);

// Proses form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari form
    $title = mysqli_real_escape_string($konek, $_POST['title']);
    $content = mysqli_real_escape_string($konek, $_POST['content']);
    $excerpt = mysqli_real_escape_string($konek, $_POST['excerpt']);
    $category_id = intval($_POST['category_id']);
    $is_published = isset($_POST['is_published']) ? 1 : 0;
    
    // Generate slug dari title jika berubah
    $new_slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
    
    if ($new_slug != $post['slug']) {
        // Cek jika slug sudah ada
        $slug_check_query = "SELECT COUNT(*) as count FROM articles WHERE slug = '$new_slug' AND id != $post_id";
        $slug_check_result = mysqli_query($konek, $slug_check_query);
        $slug_check = mysqli_fetch_assoc($slug_check_result);
        
        if ($slug_check['count'] > 0) {
            $new_slug = $new_slug . '-' . time();
        }
        $slug = $new_slug;
    } else {
        $slug = $post['slug'];
    }
    
    // Handle featured image upload
    $featured_image = $post['featured_image'];
    if (isset($_FILES['featured_image']) && $_FILES['featured_image']['error'] == 0) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $file_type = $_FILES['featured_image']['type'];
        
        if (in_array($file_type, $allowed_types)) {
            $upload_dir = '../../uploads/';
            $file_name = time() . '_' . basename($_FILES['featured_image']['name']);
            $file_path = $upload_dir . $file_name;
            
            if (move_uploaded_file($_FILES['featured_image']['tmp_name'], $file_path)) {
                // Hapus gambar lama jika ada
                if ($featured_image && file_exists($upload_dir . $featured_image)) {
                    unlink($upload_dir . $featured_image);
                }
                $featured_image = $file_name;
            }
        }
    }
    
    // Update post
    $query = "UPDATE articles SET 
                title = '$title',
                slug = '$slug',
                content = '$content',
                excerpt = '$excerpt',
                featured_image = '$featured_image',
                category_id = $category_id,
                is_published = $is_published,
                published_at = " . ($is_published && !$post['is_published'] ? "NOW()" : ($is_published ? "published_at" : "NULL")) . ",
                updated_at = NOW()
              WHERE id = $post_id";
    
    if (mysqli_query($konek, $query)) {
        // Log aktivitas
        $log_query = "INSERT INTO admin_logs (admin_id, action, details, created_at) 
                      VALUES ({$_SESSION['admin_id']}, 'update_post', 'Update post: $title', NOW())";
        mysqli_query($konek, $log_query);
        
        header("Location: list.php?success=updated");
        exit();
    } else {
        $error = "Gagal mengupdate post: " . mysqli_error($konek);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Post - Admin Blog</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Include CKEditor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <style>
        /* Copy semua style dari create.php */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #1a237e 0%, #283593 100%);
            color: white;
            padding: 20px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 3px 0 15px rgba(0,0,0,0.1);
        }

        .logo {
            text-align: center;
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 30px;
        }

        .logo h2 {
            font-size: 24px;
            color: white;
        }

        .logo span {
            color: #64b5f6;
        }

        .nav-menu {
            list-style: none;
            padding: 0 20px;
        }

        .nav-menu li {
            margin-bottom: 5px;
        }

        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            color: #b3c5e7;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .nav-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: white;
        }

        .nav-menu a.active {
            background: rgba(100, 181, 246, 0.2);
            color: #64b5f6;
            border-left: 4px solid #64b5f6;
        }

        .nav-menu i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .header h1 {
            color: #2c3e50;
            font-size: 28px;
        }

        .header h1 i {
            color: #64b5f6;
            margin-right: 10px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-info a {
            color: #7f8c8d;
            text-decoration: none;
            transition: color 0.3s;
        }

        .user-info a:hover {
            color: #3498db;
        }

        .form-container {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
        }

        .form-label.required:after {
            content: " *";
            color: #f44336;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: #2196f3;
            box-shadow: 0 0 0 3px rgba(33, 150, 243, 0.1);
        }

        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }

        .file-upload {
            border: 2px dashed #ddd;
            border-radius: 8px;
            padding: 30px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
        }

        .file-upload:hover {
            border-color: #2196f3;
            background: #f8f9fa;
        }

        .file-upload i {
            font-size: 48px;
            color: #7f8c8d;
            margin-bottom: 15px;
        }

        .file-upload input {
            display: none;
        }

        .file-preview {
            margin-top: 15px;
        }

        .file-preview img {
            max-width: 200px;
            max-height: 150px;
            border-radius: 8px;
            object-fit: cover;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .checkbox-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .form-actions {
            display: flex;
            gap: 15px;
            justify-content: flex-end;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
            transition: all 0.3s;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-primary {
            background: #2196f3;
            color: white;
        }

        .btn-primary:hover {
            background: #1976d2;
            transform: translateY(-2px);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #545b62;
        }

        .btn-danger {
            background: #f44336;
            color: white;
        }

        .btn-danger:hover {
            background: #d32f2f;
        }

        .char-counter {
            text-align: right;
            font-size: 12px;
            color: #7f8c8d;
            margin-top: 5px;
        }

        .slug-preview {
            background: #f8f9fa;
            padding: 10px 15px;
            border-radius: 6px;
            margin-top: 10px;
            font-size: 14px;
            color: #495057;
            border: 1px solid #ddd;
        }

        .slug-preview span {
            color: #2196f3;
            font-weight: 500;
        }

        @media (max-width: 1024px) {
            .sidebar {
                width: 70px;
            }
            
            .main-content {
                margin-left: 70px;
            }
            
            .logo h2 {
                font-size: 0;
            }
            
            .logo h2:after {
                content: "B";
                font-size: 24px;
            }
            
            .nav-menu a span {
                display: none;
            }
            
            .nav-menu a i {
                margin-right: 0;
                font-size: 20px;
            }
        }

        @media (max-width: 768px) {
            .form-actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
            
            .header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
        }

        .ck-editor__editable {
            min-height: 300px;
            max-height: 500px;
            overflow-y: auto;
        }

        .error-message {
            background: #ffebee;
            color: #c62828;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #f44336;
        }

        .success-message {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #4caf50;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Blog<span>Admin</span></h2>
            </div>
            <ul class="nav-menu">
                <li><a href="../dashboard.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="../posts/list.php"><i class="fas fa-newspaper"></i> <span>Posts</span></a></li>
                <li><a href="edit.php?id=<?php echo $post_id; ?>" class="active"><i class="fas fa-edit"></i> <span>Edit Post</span></a></li>
                <li><a href="../categories/list.php"><i class="fas fa-folder"></i> <span>Kategori</span></a></li>
                <li><a href="../media/list.php"><i class="fas fa-image"></i> <span>Media</span></a></li>
                <li><a href="../comments/list.php"><i class="fas fa-comments"></i> <span>Komentar</span></a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <h1><i class="fas fa-edit"></i> Edit Post</h1>
                <div class="user-info">
                    <span>Halo, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>

            <!-- Error Message -->
            <?php if(isset($error)): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <!-- Form Container -->
            <div class="form-container">
                <form action="" method="POST" enctype="multipart/form-data" id="postForm">
                    <!-- Judul -->
                    <div class="form-group">
                        <label for="title" class="form-label required">Judul Post</label>
                        <input type="text" 
                               id="title" 
                               name="title" 
                               class="form-control" 
                               required 
                               value="<?php echo htmlspecialchars($post['title']); ?>"
                               maxlength="255"
                               oninput="generateSlug()">
                        <div class="char-counter">
                            <span id="titleCounter"><?php echo strlen($post['title']); ?></span>/255 karakter
                        </div>
                    </div>

                    <!-- Slug Preview -->
                    <div class="form-group">
                        <label class="form-label">Slug (URL)</label>
                        <div class="slug-preview" id="slugPreview">
                            https://blog.com/post/<span id="slugValue"><?php echo htmlspecialchars($post['slug']); ?></span>
                        </div>
                    </div>

                    <!-- Konten -->
                    <div class="form-group">
                        <label for="content" class="form-label required">Konten</label>
                        <textarea id="content" name="content" class="form-control" required><?php echo htmlspecialchars($post['content']); ?></textarea>
                    </div>

                    <!-- Excerpt -->
                    <div class="form-group">
                        <label for="excerpt" class="form-label">Ringkasan (Excerpt)</label>
                        <textarea id="excerpt" 
                                  name="excerpt" 
                                  class="form-control" 
                                  placeholder="Ringkasan singkat tentang post ini..."
                                  maxlength="500"
                                  oninput="updateExcerptCounter()"><?php echo htmlspecialchars($post['excerpt']); ?></textarea>
                        <div class="char-counter">
                            <span id="excerptCounter"><?php echo strlen($post['excerpt']); ?></span>/500 karakter
                        </div>
                    </div>

                    <!-- Kategori -->
                    <div class="form-group">
                        <label for="category_id" class="form-label">Kategori</label>
                        <select id="category_id" name="category_id" class="form-control">
                            <option value="">Pilih Kategori</option>
                            <?php 
                            mysqli_data_seek($categories_result, 0); // Reset pointer
                            while($category = mysqli_fetch_assoc($categories_result)): 
                            ?>
                                <option value="<?php echo $category['id']; ?>" <?php echo $category['id'] == $post['category_id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($category['name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <!-- Featured Image -->
                    <div class="form-group">
                        <label class="form-label">Featured Image</label>
                        <div class="file-upload" onclick="document.getElementById('featuredImage').click()">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <p>Klik untuk upload gambar baru (Max: 2MB)</p>
                            <p><small>Format: JPG, PNG, GIF, WebP</small></p>
                            <input type="file" 
                                   id="featuredImage" 
                                   name="featured_image" 
                                   accept="image/*"
                                   onchange="previewImage(event)">
                        </div>
                        <div class="file-preview" id="imagePreview" <?php echo $post['featured_image'] ? '' : 'style="display:none;"'; ?>>
                            <?php if($post['featured_image']): ?>
                                <img id="previewImage" src="../../uploads/<?php echo htmlspecialchars($post['featured_image']); ?>" alt="Preview">
                            <?php else: ?>
                                <img id="previewImage" src="" alt="Preview">
                            <?php endif; ?>
                            <button type="button" class="btn btn-danger btn-small" onclick="removeImage()">
                                <i class="fas fa-trash"></i> Hapus
                            </button>
                            <input type="hidden" id="currentImage" name="current_image" value="<?php echo htmlspecialchars($post['featured_image']); ?>">
                        </div>
                        <?php if($post['featured_image']): ?>
                            <p class="char-counter">Gambar saat ini: <?php echo htmlspecialchars($post['featured_image']); ?></p>
                        <?php endif; ?>
                    </div>

                    <!-- Status -->
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <div class="checkbox-group">
                            <input type="checkbox" 
                                   id="is_published" 
                                   name="is_published" 
                                   value="1"
                                   <?php echo $post['is_published'] ? 'checked' : ''; ?>>
                            <label for="is_published">Publish</label>
                        </div>
                        <p class="char-counter">
                            Status saat ini: <strong><?php echo $post['is_published'] ? 'Published' : 'Draft'; ?></strong>
                            <?php if($post['published_at']): ?>
                                <br>Dipublikasikan pada: <?php echo date('d M Y H:i', strtotime($post['published_at'])); ?>
                            <?php endif; ?>
                        </p>
                    </div>

                    <!-- Informasi Post -->
                    <div class="form-group">
                        <label class="form-label">Informasi Post</label>
                        <div class="slug-preview">
                            <p><strong>ID:</strong> #<?php echo $post['id']; ?></p>
                            <p><strong>Dibuat:</strong> <?php echo date('d M Y H:i', strtotime($post['created_at'])); ?></p>
                            <p><strong>Diupdate:</strong> <?php echo date('d M Y H:i', strtotime($post['updated_at'])); ?></p>
                            <p><strong>Views:</strong> <?php echo number_format($post['view_count']); ?></p>
                        </div>
                    </div>

                    <!-- Form Actions -->
                    <div class="form-actions">
                        <a href="list.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Batal
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Update Post
                        </button>
                        <a href="delete.php?id=<?php echo $post_id; ?>" 
                           class="btn btn-danger"
                           onclick="return confirmDelete()">
                            <i class="fas fa-trash"></i> Hapus Post
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Initialize CKEditor
        CKEDITOR.replace('content', {
            toolbar: [
                { name: 'document', items: ['Source', '-', 'Save', 'NewPage', 'Preview', 'Print', '-', 'Templates'] },
                { name: 'clipboard', items: ['Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo'] },
                { name: 'editing', items: ['Find', 'Replace', '-', 'SelectAll', '-', 'Scayt'] },
                { name: 'forms', items: ['Form', 'Checkbox', 'Radio', 'TextField', 'Textarea', 'Select', 'Button', 'ImageButton', 'HiddenField'] },
                '/',
                { name: 'basicstyles', items: ['Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'CopyFormatting', 'RemoveFormat'] },
                { name: 'paragraph', items: ['NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote', 'CreateDiv', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', '-', 'BidiLtr', 'BidiRtl', 'Language'] },
                { name: 'links', items: ['Link', 'Unlink', 'Anchor'] },
                { name: 'insert', items: ['Image', 'Flash', 'Table', 'HorizontalRule', 'Smiley', 'SpecialChar', 'PageBreak', 'Iframe'] },
                '/',
                { name: 'styles', items: ['Styles', 'Format', 'Font', 'FontSize'] },
                { name: 'colors', items: ['TextColor', 'BGColor'] },
                { name: 'tools', items: ['Maximize', 'ShowBlocks'] },
                { name: 'about', items: ['About'] }
            ],
            height: 300,
            filebrowserUploadUrl: '../../admin/media/upload.php',
            filebrowserUploadMethod: 'form'
        });

        // Title character counter
        const titleInput = document.getElementById('title');
        const titleCounter = document.getElementById('titleCounter');
        
        titleInput.addEventListener('input', function() {
            titleCounter.textContent = this.value.length;
        });

        // Excerpt character counter
        const excerptInput = document.getElementById('excerpt');
        const excerptCounter = document.getElementById('excerptCounter');
        
        function updateExcerptCounter() {
            excerptCounter.textContent = excerptInput.value.length;
        }
        excerptInput.addEventListener('input', updateExcerptCounter);

        // Generate slug from title
        function generateSlug() {
            const title = document.getElementById('title').value;
            let slug = title
                .toLowerCase()
                .replace(/[^a-z0-9\s-]/g, '')
                .replace(/\s+/g, '-')
                .replace(/-+/g, '-')
                .trim();
            
            if (!slug) {
                slug = 'post-' + Date.now();
            }
            
            document.getElementById('slugValue').textContent = slug;
        }

        // Image preview
        function previewImage(event) {
            const input = event.target;
            const preview = document.getElementById('previewImage');
            const previewContainer = document.getElementById('imagePreview');
            
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    previewContainer.style.display = 'block';
                }
                
                reader.readAsDataURL(input.files[0]);
            }
        }

        // Remove image
        function removeImage() {
            document.getElementById('featuredImage').value = '';
            document.getElementById('previewImage').src = '';
            document.getElementById('imagePreview').style.display = 'none';
            document.getElementById('currentImage').value = '';
        }

        // Confirm delete
        function confirmDelete() {
            Swal.fire({
                title: 'Hapus Post?',
                html: `Post <strong>"<?php echo addslashes($post['title']); ?>"</strong> akan dihapus secara permanen.`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `delete.php?id=<?php echo $post_id; ?>`;
                }
            });
            return false;
        }

        // Form submission handling
        document.getElementById('postForm').addEventListener('submit', function(e) {
            const title = document.getElementById('title').value.trim();
            const content = CKEDITOR.instances.content.getData().trim();
            
            if (!title) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Judul Kosong',
                    text: 'Silakan masukkan judul post!'
                });
                return false;
            }
            
            if (!content) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Konten Kosong',
                    text: 'Silakan masukkan konten post!'
                });
                return false;
            }
            
            // Show loading
            Swal.fire({
                title: 'Mengupdate Post...',
                allowOutsideClick: false,
                showConfirmButton: false,
                willOpen: () => {
                    Swal.showLoading();
                }
            });
        });

        // Warn before leaving page
        let hasChanges = false;
        
        titleInput.addEventListener('input', () => hasChanges = true);
        excerptInput.addEventListener('input', () => hasChanges = true);
        
        window.addEventListener('beforeunload', function (e) {
            if (hasChanges) {
                e.preventDefault();
                e.returnValue = 'Anda memiliki perubahan yang belum disimpan. Apakah Anda yakin ingin meninggalkan halaman?';
            }
        });
    </script>
</body>
</html>