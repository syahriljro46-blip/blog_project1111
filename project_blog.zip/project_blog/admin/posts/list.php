<?php
session_start();
require_once '../../config/database.php';

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

// Query untuk mendapatkan semua post dengan join ke kategori dan admin
$query = "SELECT 
            a.*,
            c.name as category_name,
            c.slug as category_slug,
            ad.username as author_name,
            ad.full_name as author_full_name,
            COUNT(DISTINCT co.id) as comment_count,
            COUNT(DISTINCT al.id) as like_count
          FROM articles a
          LEFT JOIN categories c ON a.category_id = c.id
          LEFT JOIN admins ad ON a.author_id = ad.id
          LEFT JOIN comments co ON a.id = co.article_id
          LEFT JOIN article_likes al ON a.id = al.article_id
          GROUP BY a.id
          ORDER BY a.created_at DESC";
$result = mysqli_query($konek, $query);

// Hitung total post
$total_query = "SELECT COUNT(*) as total FROM articles";
$total_result = mysqli_query($konek, $total_query);
$total_data = mysqli_fetch_assoc($total_result);
$total_posts = $total_data['total'];

// Hitung post yang published
$published_query = "SELECT COUNT(*) as published FROM articles WHERE is_published = 1";
$published_result = mysqli_query($konek, $published_query);
$published_data = mysqli_fetch_assoc($published_result);
$published_posts = $published_data['published'];

// Hitung post draft
$draft_query = "SELECT COUNT(*) as draft FROM articles WHERE is_published = 0";
$draft_result = mysqli_query($konek, $draft_query);
$draft_data = mysqli_fetch_assoc($draft_result);
$draft_posts = $draft_data['draft'];

// Pesan sukses dan error
$success_message = '';
$error_message = '';

if(isset($_GET['success'])) {
    if($_GET['success'] == 'created') {
        $success_message = "Post berhasil dibuat!";
    } elseif($_GET['success'] == 'updated') {
        $success_message = "Post berhasil diupdate!";
    } elseif($_GET['success'] == 'deleted') {
        $success_message = "Post berhasil dihapus!";
    } elseif($_GET['success'] == 'published') {
        $success_message = "Post berhasil dipublish!";
    } elseif($_GET['success'] == 'unpublished') {
        $success_message = "Post berhasil diubah ke draft!";
    }
}

if(isset($_GET['error'])) {
    if($_GET['error'] == 'delete_failed') {
        $error_message = "Gagal menghapus post!";
    } elseif($_GET['error'] == 'not_found') {
        $error_message = "Post tidak ditemukan!";
    } elseif($_GET['error'] == 'invalid_id') {
        $error_message = "ID post tidak valid!";
    } else {
        $error_message = "Terjadi kesalahan!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Post - Admin Blog</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #1a237e 0%, #283593 100%);
            color: white;
            padding: 20px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 3px 0 15px rgba(0,0,0,0.1);
        }

        .logo {
            text-align: center;
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 30px;
        }

        .logo h2 {
            font-size: 24px;
            color: white;
        }

        .logo span {
            color: #64b5f6;
        }

        .nav-menu {
            list-style: none;
            padding: 0 20px;
        }

        .nav-menu li {
            margin-bottom: 5px;
        }

        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            color: #b3c5e7;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .nav-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: white;
        }

        .nav-menu a.active {
            background: rgba(100, 181, 246, 0.2);
            color: #64b5f6;
            border-left: 4px solid #64b5f6;
        }

        .nav-menu i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .header h1 {
            color: #2c3e50;
            font-size: 28px;
        }

        .header h1 i {
            color: #64b5f6;
            margin-right: 10px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-info a {
            color: #7f8c8d;
            text-decoration: none;
            transition: color 0.3s;
        }

        .user-info a:hover {
            color: #3498db;
        }

        /* Stats Cards */
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 20px;
            font-size: 24px;
        }

        .stat-icon.total {
            background: #e3f2fd;
            color: #1976d2;
        }

        .stat-icon.published {
            background: #e8f5e9;
            color: #388e3c;
        }

        .stat-icon.draft {
            background: #fff3e0;
            color: #f57c00;
        }

        .stat-info h3 {
            font-size: 14px;
            color: #7f8c8d;
            margin-bottom: 5px;
        }

        .stat-info .number {
            font-size: 28px;
            font-weight: bold;
            color: #2c3e50;
        }

        /* Posts Table */
        .posts-table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .table-header {
            padding: 20px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .table-header h2 {
            color: #2c3e50;
        }

        .actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
            transition: all 0.3s;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-primary {
            background: #2196f3;
            color: white;
        }

        .btn-primary:hover {
            background: #1976d2;
            transform: translateY(-2px);
        }

        .btn-success {
            background: #4caf50;
            color: white;
        }

        .btn-success:hover {
            background: #388e3c;
        }

        .btn-danger {
            background: #f44336;
            color: white;
        }

        .btn-danger:hover {
            background: #d32f2f;
        }

        .btn-warning {
            background: #ff9800;
            color: white;
        }

        .btn-warning:hover {
            background: #f57c00;
        }

        .btn-info {
            background: #17a2b8;
            color: white;
        }

        .btn-info:hover {
            background: #138496;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: #f8f9fa;
        }

        th {
            padding: 15px;
            text-align: left;
            color: #2c3e50;
            font-weight: 600;
            border-bottom: 2px solid #eee;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
            vertical-align: middle;
        }

        tr:hover {
            background: #f9f9f9;
        }

        .post-title {
            font-weight: 500;
            color: #2c3e50;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
        }

        .post-title:hover {
            color: #2196f3;
        }

        .post-meta {
            font-size: 12px;
            color: #7f8c8d;
        }

        .post-meta i {
            margin-right: 5px;
        }

        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }

        .badge-published {
            background: #e8f5e9;
            color: #388e3c;
        }

        .badge-draft {
            background: #fff3e0;
            color: #f57c00;
        }

        .badge-category {
            background: #e3f2fd;
            color: #1976d2;
        }

        .actions-cell {
            display: flex;
            gap: 8px;
        }

        .btn-small {
            padding: 6px 12px;
            font-size: 12px;
            border-radius: 6px;
        }

        .btn-icon {
            width: 32px;
            height: 32px;
            padding: 0;
            justify-content: center;
            border-radius: 50%;
        }

        .stats-cell {
            text-align: center;
        }

        .stat-number {
            font-size: 18px;
            font-weight: bold;
            color: #2c3e50;
            display: block;
        }

        .stat-label {
            font-size: 11px;
            color: #7f8c8d;
            text-transform: uppercase;
        }

        .featured-image {
            width: 80px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
        }

        /* Search and Filter */
        .search-filter {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            align-items: center;
        }

        .search-box {
            flex: 1;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 12px 20px 12px 45px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }

        .search-box input:focus {
            outline: none;
            border-color: #2196f3;
            box-shadow: 0 0 0 3px rgba(33, 150, 243, 0.1);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #7f8c8d;
        }

        .filter-select {
            padding: 12px 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background: white;
            font-size: 14px;
            color: #333;
            min-width: 150px;
        }

        /* No Posts */
        .no-posts {
            text-align: center;
            padding: 50px;
            color: #7f8c8d;
        }

        .no-posts i {
            font-size: 48px;
            margin-bottom: 20px;
            color: #bdc3c7;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .sidebar {
                width: 70px;
            }
            
            .main-content {
                margin-left: 70px;
            }
            
            .logo h2 {
                font-size: 0;
            }
            
            .logo h2:after {
                content: "B";
                font-size: 24px;
            }
            
            .nav-menu a span {
                display: none;
            }
            
            .nav-menu a i {
                margin-right: 0;
                font-size: 20px;
            }
        }

        @media (max-width: 768px) {
            .stats-cards {
                grid-template-columns: 1fr;
            }
            
            table {
                display: block;
                overflow-x: auto;
            }
            
            .header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .search-filter {
                flex-direction: column;
            }
            
            .actions-cell {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .btn-small {
                padding: 4px 8px;
                font-size: 11px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Blog<span>Admin</span></h2>
            </div>
            <ul class="nav-menu">
                <li><a href="../dashboard.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="../posts/list.php" class="active"><i class="fas fa-newspaper"></i> <span>Posts</span></a></li>
                <li><a href="../categories/list.php"><i class="fas fa-folder"></i> <span>Kategori</span></a></li>
                <li><a href="../media/list.php"><i class="fas fa-image"></i> <span>Media</span></a></li>
                <li><a href="../comments/list.php"><i class="fas fa-comments"></i> <span>Komentar</span></a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <h1><i class="fas fa-newspaper"></i> Manajemen Posts</h1>
                <div class="user-info">
                    <span>Halo, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="stats-cards">
                <div class="stat-card">
                    <div class="stat-icon total">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Total Posts</h3>
                        <div class="number"><?php echo $total_posts; ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon published">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Published</h3>
                        <div class="number"><?php echo $published_posts; ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon draft">
                        <i class="fas fa-edit"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Draft</h3>
                        <div class="number"><?php echo $draft_posts; ?></div>
                    </div>
                </div>
            </div>

            <!-- Search and Filter -->
            <div class="search-filter">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Cari posts...">
                </div>
                <select class="filter-select" id="categoryFilter">
                    <option value="">Semua Kategori</option>
                    <?php
                    $cat_query = "SELECT * FROM categories ORDER BY name";
                    $cat_result = mysqli_query($konek, $cat_query);
                    while($cat = mysqli_fetch_assoc($cat_result)) {
                        echo "<option value='{$cat['id']}'>{$cat['name']}</option>";
                    }
                    ?>
                </select>
                <select class="filter-select" id="statusFilter">
                    <option value="">Semua Status</option>
                    <option value="published">Published</option>
                    <option value="draft">Draft</option>
                </select>
                <a href="create.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Post Baru
                </a>
            </div>

            <!-- Posts Table -->
            <div class="posts-table">
                <div class="table-header">
                    <h2>Daftar Posts</h2>
                    <div class="actions">
                        <button class="btn btn-info" onclick="exportPosts()">
                            <i class="fas fa-download"></i> Export
                        </button>
                    </div>
                </div>

                <?php if(mysqli_num_rows($result) > 0): ?>
                    <table id="postsTable">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Post</th>
                                <th>Kategori</th>
                                <th>Status</th>
                                <th>Statistik</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($post = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td>#<?php echo $post['id']; ?></td>
                                    <td>
                                        <a href="../../post.php?slug=<?php echo $post['slug']; ?>" 
                                           target="_blank" 
                                           class="post-title">
                                            <?php echo htmlspecialchars($post['title']); ?>
                                        </a>
                                        <div class="post-meta">
                                            <i class="fas fa-user"></i> <?php echo htmlspecialchars($post['author_name']); ?>
                                            <?php if($post['featured_image']): ?>
                                                <br>
                                                <img src="../../uploads/<?php echo htmlspecialchars($post['featured_image']); ?>" 
                                                     alt="Featured" 
                                                     class="featured-image">
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if($post['category_name']): ?>
                                            <span class="badge badge-category">
                                                <?php echo htmlspecialchars($post['category_name']); ?>
                                            </span>
                                        <?php else: ?>
                                            <span style="color:#7f8c8d; font-size:12px;">Tidak ada kategori</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($post['is_published']): ?>
                                            <span class="badge badge-published">
                                                <i class="fas fa-check-circle"></i> Published
                                            </span>
                                            <?php if($post['published_at']): ?>
                                                <br>
                                                <small><?php echo date('d M Y', strtotime($post['published_at'])); ?></small>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="badge badge-draft">
                                                <i class="fas fa-edit"></i> Draft
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="stats-cell">
                                        <span class="stat-number"><?php echo $post['view_count']; ?></span>
                                        <span class="stat-label">Views</span>
                                        <br>
                                        <span class="stat-number"><?php echo $post['comment_count']; ?></span>
                                        <span class="stat-label">Comments</span>
                                        <br>
                                        <span class="stat-number"><?php echo $post['like_count']; ?></span>
                                        <span class="stat-label">Likes</span>
                                    </td>
                                    <td>
                                        <?php echo date('d M Y', strtotime($post['created_at'])); ?><br>
                                        <small><?php echo date('H:i', strtotime($post['created_at'])); ?></small>
                                    </td>
                                    <td class="actions-cell">
                                        <a href="edit.php?id=<?php echo $post['id']; ?>" 
                                           class="btn btn-warning btn-small"
                                           title="Edit Post">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="delete.php?id=<?php echo $post['id']; ?>" 
                                           class="btn btn-danger btn-small"
                                           onclick="return confirmDelete(<?php echo $post['id']; ?>, '<?php echo addslashes($post['title']); ?>')"
                                           title="Hapus Post">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                        <?php if($post['is_published']): ?>
                                            <a href="?action=unpublish&id=<?php echo $post['id']; ?>" 
                                               class="btn btn-info btn-small"
                                               title="Set ke Draft">
                                                <i class="fas fa-eye-slash"></i>
                                            </a>
                                        <?php else: ?>
                                            <a href="?action=publish&id=<?php echo $post['id']; ?>" 
                                               class="btn btn-success btn-small"
                                               title="Publish Now">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        <?php endif; ?>
                                        <a href="../../post.php?slug=<?php echo $post['slug']; ?>" 
                                           target="_blank" 
                                           class="btn btn-primary btn-small"
                                           title="View Post">
                                            <i class="fas fa-external-link-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="no-posts">
                        <i class="fas fa-file-alt"></i>
                        <h3>Belum ada posts</h3>
                        <p>Tidak ada posts yang ditemukan. <a href="create.php">Buat post pertama</a></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            const filter = this.value.toLowerCase();
            const rows = document.querySelectorAll('#postsTable tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });

        // Filter by category
        document.getElementById('categoryFilter').addEventListener('change', function() {
            const filterValue = this.value;
            const rows = document.querySelectorAll('#postsTable tbody tr');
            
            rows.forEach(row => {
                if (!filterValue) {
                    row.style.display = '';
                    return;
                }
                
                const categoryCell = row.cells[2].textContent.toLowerCase();
                row.style.display = categoryCell.includes(filterValue) ? '' : 'none';
            });
        });

        // Filter by status
        document.getElementById('statusFilter').addEventListener('change', function() {
            const filterValue = this.value;
            const rows = document.querySelectorAll('#postsTable tbody tr');
            
            rows.forEach(row => {
                if (!filterValue) {
                    row.style.display = '';
                    return;
                }
                
                const statusCell = row.cells[3].textContent.toLowerCase();
                row.style.display = statusCell.includes(filterValue) ? '' : 'none';
            });
        });

        // Delete confirmation
        function confirmDelete(id, title) {
            Swal.fire({
                title: 'Hapus Post?',
                html: `Post <strong>"${title}"</strong> akan dihapus secara permanen.`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `delete.php?id=${id}`;
                }
            });
            return false;
        }

        // Export function
        function exportPosts() {
            Swal.fire({
                title: 'Export Posts',
                text: 'Pilih format export:',
                icon: 'info',
                showCancelButton: true,
                confirmButtonText: 'CSV',
                cancelButtonText: 'JSON',
                showDenyButton: true,
                denyButtonText: 'PDF'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'export.php?format=csv';
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    window.location.href = 'export.php?format=json';
                } else if (result.isDenied) {
                    window.location.href = 'export.php?format=pdf';
                }
            });
        }

        // Handle URL actions
        const urlParams = new URLSearchParams(window.location.search);
        const action = urlParams.get('action');
        const id = urlParams.get('id');

        if(action === 'publish' && id) {
            publishPost(id);
        } else if(action === 'unpublish' && id) {
            unpublishPost(id);
        }

        function publishPost(id) {
            fetch(`update_post.php?action=publish&id=${id}`)
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil!',
                            text: 'Post telah dipublish',
                            timer: 1500,
                            showConfirmButton: false
                        }).then(() => location.reload());
                    }
                });
        }

        function unpublishPost(id) {
            fetch(`update_post.php?action=unpublish&id=${id}`)
                .then(response => response.json())
                .then(data => {
                    if(data.success) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil!',
                            text: 'Post diubah ke draft',
                            timer: 1500,
                            showConfirmButton: false
                        }).then(() => location.reload());
                    }
                });
        }

        // Show success messages
        <?php if(!empty($success_message)): ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: '<?php echo addslashes($success_message); ?>',
                timer: 3000,
                showConfirmButton: false
            });
        <?php endif; ?>

        <?php if(!empty($error_message)): ?>
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: '<?php echo addslashes($error_message); ?>'
            });
        <?php endif; ?>
    </script>
</body>
</html>

<?php
// Handle actions
if(isset($_GET['action'])) {
    $action = $_GET['action'];
    $post_id = $_GET['id'] ?? 0;
    
    if($action == 'publish' && $post_id) {
        $query = "UPDATE articles SET is_published = 1, published_at = NOW() WHERE id = $post_id";
        mysqli_query($konek, $query);
        header("Location: list.php?success=published");
        exit();
    } 
    elseif($action == 'unpublish' && $post_id) {
        $query = "UPDATE articles SET is_published = 0, published_at = NULL WHERE id = $post_id";
        mysqli_query($konek, $query);
        header("Location: list.php?success=unpublished");
        exit();
    }
}
?>