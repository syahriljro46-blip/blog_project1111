<?php
session_start();
require_once '../../config/database.php';

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

// Ambil data kategori untuk dropdown
$categories_query = "SELECT * FROM categories ORDER BY name";
$categories_result = mysqli_query($konek, $categories_query);

// Proses form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari form
    $title = mysqli_real_escape_string($konek, $_POST['title']);
    $content = mysqli_real_escape_string($konek, $_POST['content']);
    $excerpt = mysqli_real_escape_string($konek, $_POST['excerpt']);
    $category_id = intval($_POST['category_id']);
    $is_published = isset($_POST['is_published']) ? 1 : 0;
    $author_id = $_SESSION['admin_id'];
    
    // Generate slug dari title
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
    
    // Cek jika slug sudah ada
    $slug_check_query = "SELECT COUNT(*) as count FROM articles WHERE slug LIKE '$slug%'";
    $slug_check_result = mysqli_query($konek, $slug_check_query);
    $slug_check = mysqli_fetch_assoc($slug_check_result);
    
    if ($slug_check['count'] > 0) {
        $slug = $slug . '-' . time();
    }
    
    // Handle featured image upload
    $featured_image = '';
    if (isset($_FILES['featured_image']) && $_FILES['featured_image']['error'] == 0) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $file_type = $_FILES['featured_image']['type'];
        
        if (in_array($file_type, $allowed_types)) {
            $upload_dir = '../../uploads/';
            $file_name = time() . '_' . basename($_FILES['featured_image']['name']);
            $file_path = $upload_dir . $file_name;
            
            if (move_uploaded_file($_FILES['featured_image']['tmp_name'], $file_path)) {
                $featured_image = $file_name;
            }
        }
    }
    
    // Insert ke database
    $query = "INSERT INTO articles (title, slug, content, excerpt, featured_image, category_id, author_id, is_published, published_at) 
              VALUES ('$title', '$slug', '$content', '$excerpt', '$featured_image', $category_id, $author_id, $is_published, " . ($is_published ? "NOW()" : "NULL") . ")";
    
    if (mysqli_query($konek, $query)) {
        $post_id = mysqli_insert_id($konek);
        
        // Log aktivitas
        $log_query = "INSERT INTO admin_logs (admin_id, action, details, created_at) 
                      VALUES ($author_id, 'create_post', 'Membuat post: $title', NOW())";
        mysqli_query($konek, $log_query);
        
        header("Location: list.php?success=created");
        exit();
    } else {
        $error = "Gagal menyimpan post: " . mysqli_error($konek);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buat Post Baru - Admin Blog</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <!-- Include CKEditor -->
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #1a237e 0%, #283593 100%);
            color: white;
            padding: 20px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 3px 0 15px rgba(0,0,0,0.1);
        }

        .logo {
            text-align: center;
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 30px;
        }

        .logo h2 {
            font-size: 24px;
            color: white;
        }

        .logo span {
            color: #64b5f6;
        }

        .nav-menu {
            list-style: none;
            padding: 0 20px;
        }

        .nav-menu li {
            margin-bottom: 5px;
        }

        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            color: #b3c5e7;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .nav-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: white;
        }

        .nav-menu a.active {
            background: rgba(100, 181, 246, 0.2);
            color: #64b5f6;
            border-left: 4px solid #64b5f6;
        }

        .nav-menu i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .header h1 {
            color: #2c3e50;
            font-size: 28px;
        }

        .header h1 i {
            color: #64b5f6;
            margin-right: 10px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-info a {
            color: #7f8c8d;
            text-decoration: none;
            transition: color 0.3s;
        }

        .user-info a:hover {
            color: #3498db;
        }

        /* Form Container */
        .form-container {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
        }

        .form-label.required:after {
            content: " *";
            color: #f44336;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: #2196f3;
            box-shadow: 0 0 0 3px rgba(33, 150, 243, 0.1);
        }

        .form-control[readonly] {
            background-color: #f5f7fa;
            cursor: not-allowed;
        }

        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }

        /* File Upload */
        .file-upload {
            border: 2px dashed #ddd;
            border-radius: 8px;
            padding: 30px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
        }

        .file-upload:hover {
            border-color: #2196f3;
            background: #f8f9fa;
        }

        .file-upload i {
            font-size: 48px;
            color: #7f8c8d;
            margin-bottom: 15px;
        }

        .file-upload input {
            display: none;
        }

        .file-preview {
            margin-top: 15px;
            display: none;
        }

        .file-preview img {
            max-width: 200px;
            max-height: 150px;
            border-radius: 8px;
            object-fit: cover;
        }

        /* Checkbox */
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .checkbox-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        /* Buttons */
        .form-actions {
            display: flex;
            gap: 15px;
            justify-content: flex-end;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
            transition: all 0.3s;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-primary {
            background: #2196f3;
            color: white;
        }

        .btn-primary:hover {
            background: #1976d2;
            transform: translateY(-2px);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #545b62;
        }

        .btn-danger {
            background: #f44336;
            color: white;
        }

        .btn-danger:hover {
            background: #d32f2f;
        }

        /* Character Counter */
        .char-counter {
            text-align: right;
            font-size: 12px;
            color: #7f8c8d;
            margin-top: 5px;
        }

        /* Slug Preview */
        .slug-preview {
            background: #f8f9fa;
            padding: 10px 15px;
            border-radius: 6px;
            margin-top: 10px;
            font-size: 14px;
            color: #495057;
            border: 1px solid #ddd;
        }

        .slug-preview span {
            color: #2196f3;
            font-weight: 500;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .sidebar {
                width: 70px;
            }
            
            .main-content {
                margin-left: 70px;
            }
            
            .logo h2 {
                font-size: 0;
            }
            
            .logo h2:after {
                content: "B";
                font-size: 24px;
            }
            
            .nav-menu a span {
                display: none;
            }
            
            .nav-menu a i {
                margin-right: 0;
                font-size: 20px;
            }
        }

        @media (max-width: 768px) {
            .form-actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
            
            .header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
        }

        /* Editor Styles */
        .ck-editor__editable {
            min-height: 300px;
            max-height: 500px;
            overflow-y: auto;
        }

        /* Error Message */
        .error-message {
            background: #ffebee;
            color: #c62828;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #f44336;
        }

        /* Success Message */
        .success-message {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #4caf50;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Blog<span>Admin</span></h2>
            </div>
            <ul class="nav-menu">
                <li><a href="../dashboard.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="../posts/list.php"><i class="fas fa-newspaper"></i> <span>Posts</span></a></li>
                <li><a href="create.php" class="active"><i class="fas fa-plus-circle"></i> <span>Buat Post</span></a></li>
                <li><a href="../categories/list.php"><i class="fas fa-folder"></i> <span>Kategori</span></a></li>
                <li><a href="../media/list.php"><i class="fas fa-image"></i> <span>Media</span></a></li>
                <li><a href="../comments/list.php"><i class="fas fa-comments"></i> <span>Komentar</span></a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <h1><i class="fas fa-plus-circle"></i> Buat Post Baru</h1>
                <div class="user-info">
                    <span>Halo, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>

            <!-- Error Message -->
            <?php if(isset($error)): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <!-- Form Container -->
            <div class="form-container">
                <form action="" method="POST" enctype="multipart/form-data" id="postForm">
                    <!-- Judul -->
                    <div class="form-group">
                        <label for="title" class="form-label required">Judul Post</label>
                        <input type="text" 
                               id="title" 
                               name="title" 
                               class="form-control" 
                               required 
                               placeholder="Masukkan judul post..."
                               maxlength="255"
                               oninput="generateSlug()">
                        <div class="char-counter">
                            <span id="titleCounter">0</span>/255 karakter
                        </div>
                    </div>

                    <!-- Slug Preview -->
                    <div class="form-group">
                        <label class="form-label">Slug (URL)</label>
                        <div class="slug-preview" id="slugPreview">
                            https://blog.com/post/<span id="slugValue">judul-post</span>
                        </div>
                    </div>

                    <!-- Konten -->
                    <div class="form-group">
                        <label for="content" class="form-label required">Konten</label>
                        <textarea id="content" name="content" class="form-control" required></textarea>
                    </div>

                    <!-- Excerpt -->
                    <div class="form-group">
                        <label for="excerpt" class="form-label">Ringkasan (Excerpt)</label>
                        <textarea id="excerpt" 
                                  name="excerpt" 
                                  class="form-control" 
                                  placeholder="Ringkasan singkat tentang post ini..."
                                  maxlength="500"
                                  oninput="updateExcerptCounter()"></textarea>
                        <div class="char-counter">
                            <span id="excerptCounter">0</span>/500 karakter
                        </div>
                    </div>

                    <!-- Kategori -->
                    <div class="form-group">
                        <label for="category_id" class="form-label">Kategori</label>
                        <select id="category_id" name="category_id" class="form-control">
                            <option value="">Pilih Kategori</option>
                            <?php while($category = mysqli_fetch_assoc($categories_result)): ?>
                                <option value="<?php echo $category['id']; ?>">
                                    <?php echo htmlspecialchars($category['name']); ?>
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>

                    <!-- Featured Image -->
                    <div class="form-group">
                        <label class="form-label">Featured Image</label>
                        <div class="file-upload" onclick="document.getElementById('featuredImage').click()">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <p>Klik untuk upload gambar (Max: 2MB)</p>
                            <p><small>Format: JPG, PNG, GIF, WebP</small></p>
                            <input type="file" 
                                   id="featuredImage" 
                                   name="featured_image" 
                                   accept="image/*"
                                   onchange="previewImage(event)">
                        </div>
                        <div class="file-preview" id="imagePreview">
                            <img id="previewImage" src="" alt="Preview">
                            <button type="button" class="btn btn-danger btn-small" onclick="removeImage()">
                                <i class="fas fa-trash"></i> Hapus
                            </button>
                        </div>
                    </div>

                    <!-- Status -->
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <div class="checkbox-group">
                            <input type="checkbox" 
                                   id="is_published" 
                                   name="is_published" 
                                   value="1"
                                   checked>
                            <label for="is_published">Publish sekarang</label>
                        </div>
                        <p class="char-counter">Jika tidak dicentang, post akan disimpan sebagai draft</p>
                    </div>

                    <!-- Form Actions -->
                    <div class="form-actions">
                        <a href="list.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Batal
                        </a>
                        <button type="submit" name="save_draft" class="btn btn-warning">
                            <i class="fas fa-save"></i> Simpan Draft
                        </button>
                        <button type="submit" name="publish" class="btn btn-primary">
                            <i class="fas fa-paper-plane"></i> Publish Post
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Initialize CKEditor
        CKEDITOR.replace('content', {
            toolbar: [
                { name: 'document', items: ['Source', '-', 'Save', 'NewPage', 'Preview', 'Print', '-', 'Templates'] },
                { name: 'clipboard', items: ['Cut', 'Copy', 'Paste', 'PasteText', 'PasteFromWord', '-', 'Undo', 'Redo'] },
                { name: 'editing', items: ['Find', 'Replace', '-', 'SelectAll', '-', 'Scayt'] },
                { name: 'forms', items: ['Form', 'Checkbox', 'Radio', 'TextField', 'Textarea', 'Select', 'Button', 'ImageButton', 'HiddenField'] },
                '/',
                { name: 'basicstyles', items: ['Bold', 'Italic', 'Underline', 'Strike', 'Subscript', 'Superscript', '-', 'CopyFormatting', 'RemoveFormat'] },
                { name: 'paragraph', items: ['NumberedList', 'BulletedList', '-', 'Outdent', 'Indent', '-', 'Blockquote', 'CreateDiv', '-', 'JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock', '-', 'BidiLtr', 'BidiRtl', 'Language'] },
                { name: 'links', items: ['Link', 'Unlink', 'Anchor'] },
                { name: 'insert', items: ['Image', 'Flash', 'Table', 'HorizontalRule', 'Smiley', 'SpecialChar', 'PageBreak', 'Iframe'] },
                '/',
                { name: 'styles', items: ['Styles', 'Format', 'Font', 'FontSize'] },
                { name: 'colors', items: ['TextColor', 'BGColor'] },
                { name: 'tools', items: ['Maximize', 'ShowBlocks'] },
                { name: 'about', items: ['About'] }
            ],
            height: 300,
            filebrowserUploadUrl: '../../admin/media/upload.php',
            filebrowserUploadMethod: 'form'
        });

        // Title character counter
        const titleInput = document.getElementById('title');
        const titleCounter = document.getElementById('titleCounter');
        
        titleInput.addEventListener('input', function() {
            titleCounter.textContent = this.value.length;
        });

        // Excerpt character counter
        const excerptInput = document.getElementById('excerpt');
        const excerptCounter = document.getElementById('excerptCounter');
        
        function updateExcerptCounter() {
            excerptCounter.textContent = excerptInput.value.length;
        }
        excerptInput.addEventListener('input', updateExcerptCounter);

        // Generate slug from title
        function generateSlug() {
            const title = document.getElementById('title').value;
            let slug = title
                .toLowerCase()
                .replace(/[^a-z0-9\s-]/g, '')
                .replace(/\s+/g, '-')
                .replace(/-+/g, '-')
                .trim();
            
            // Add timestamp if empty
            if (!slug) {
                slug = 'post-' + Date.now();
            }
            
            document.getElementById('slugValue').textContent = slug;
        }

        // Image preview
        function previewImage(event) {
            const input = event.target;
            const preview = document.getElementById('previewImage');
            const previewContainer = document.getElementById('imagePreview');
            
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    previewContainer.style.display = 'block';
                }
                
                reader.readAsDataURL(input.files[0]);
            }
        }

        // Remove image
        function removeImage() {
            document.getElementById('featuredImage').value = '';
            document.getElementById('previewImage').src = '';
            document.getElementById('imagePreview').style.display = 'none';
        }

        // Form submission handling
        document.getElementById('postForm').addEventListener('submit', function(e) {
            const title = document.getElementById('title').value.trim();
            const content = CKEDITOR.instances.content.getData().trim();
            
            if (!title) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Judul Kosong',
                    text: 'Silakan masukkan judul post!'
                });
                return false;
            }
            
            if (!content) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Konten Kosong',
                    text: 'Silakan masukkan konten post!'
                });
                return false;
            }
            
            // Show loading
            Swal.fire({
                title: 'Menyimpan Post...',
                allowOutsideClick: false,
                showConfirmButton: false,
                willOpen: () => {
                    Swal.showLoading();
                }
            });
        });

        // Auto-save draft (optional feature)
        let autoSaveInterval;
        function startAutoSave() {
            autoSaveInterval = setInterval(() => {
                saveDraft();
            }, 30000); // Save every 30 seconds
        }

        function saveDraft() {
            const formData = new FormData(document.getElementById('postForm'));
            formData.append('auto_save', 'true');
            
            fetch('auto_save.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if(data.success) {
                    console.log('Auto-save successful');
                }
            });
        }

        // Start auto-save when page loads
        window.addEventListener('load', () => {
            startAutoSave();
        });

        // Warn before leaving page
        window.addEventListener('beforeunload', function (e) {
            const title = document.getElementById('title').value.trim();
            const content = CKEDITOR.instances.content.getData().trim();
            
            if (title || content) {
                e.preventDefault();
                e.returnValue = 'Anda memiliki perubahan yang belum disimpan. Apakah Anda yakin ingin meninggalkan halaman?';
            }
        });
    </script>
</body>
</html>