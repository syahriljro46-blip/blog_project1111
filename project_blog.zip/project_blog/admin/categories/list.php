<?php
session_start();
require_once '../../config/database.php';

// Cek jika belum login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];

// Ambil semua kategori dengan jumlah artikel
$query = "SELECT c.*, 
                 COUNT(a.id) as article_count,
                 SUM(a.view_count) as total_views
          FROM categories c 
          LEFT JOIN articles a ON c.id = a.category_id AND a.is_published = 1
          GROUP BY c.id 
          ORDER BY c.created_at DESC";
$categories = mysqli_query($konek, $query);

// Hitung total kategori
$total_categories = mysqli_num_rows($categories);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Kategori - Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            color: #333;
        }
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            height: 100vh;
        }
        .logo {
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }
        .logo h2 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        .logo p {
            font-size: 12px;
            opacity: 0.8;
        }
        .nav-menu {
            list-style: none;
        }
        .nav-item {
            margin-bottom: 5px;
        }
        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        .nav-link:hover, .nav-link.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }
        .nav-icon {
            font-size: 18px;
        }
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }
        .header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-title h1 {
            font-size: 28px;
            color: #333;
            margin-bottom: 5px;
        }
        .page-title p {
            color: #666;
            font-size: 14px;
        }
        .btn-create {
            padding: 12px 25px;
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: transform 0.2s;
        }
        .btn-create:hover {
            transform: translateY(-2px);
        }
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            text-align: center;
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            font-size: 40px;
            margin-bottom: 15px;
            color: #667eea;
        }
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #333;
            margin: 10px 0;
        }
        .stat-label {
            font-size: 14px;
            color: #666;
        }
        .categories-table {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            overflow: hidden;
        }
        .table-header {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 150px;
            padding: 20px;
            background: #f8f9fa;
            font-weight: 500;
            color: #555;
            border-bottom: 1px solid #eee;
        }
        .table-row {
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 150px;
            padding: 20px;
            border-bottom: 1px solid #eee;
            align-items: center;
        }
        .table-row:hover {
            background: #f8f9fa;
        }
        .category-name {
            font-weight: 500;
            color: #333;
            font-size: 16px;
        }
        .category-slug {
            font-size: 13px;
            color: #666;
            margin-top: 5px;
            background: #f0f0f0;
            padding: 3px 8px;
            border-radius: 3px;
            display: inline-block;
        }
        .category-description {
            color: #666;
            font-size: 14px;
            line-height: 1.4;
            margin-top: 8px;
        }
        .article-count {
            text-align: center;
        }
        .count-number {
            font-size: 24px;
            font-weight: bold;
            color: #667eea;
            display: block;
        }
        .count-label {
            font-size: 12px;
            color: #666;
        }
        .total-views {
            text-align: center;
            color: #666;
            font-size: 14px;
        }
        .total-views strong {
            color: #333;
            display: block;
            font-size: 18px;
        }
        .action-buttons {
            display: flex;
            gap: 8px;
            justify-content: center;
        }
        .btn-action {
            padding: 8px 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 12px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s;
        }
        .btn-edit {
            background: #ffc107;
            color: #333;
        }
        .btn-delete {
            background: #dc3545;
            color: white;
        }
        .btn-action:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }
        .empty-state h3 {
            font-size: 1.5em;
            margin-bottom: 10px;
            color: #333;
        }
        .user-info {
            padding: 20px;
            text-align: center;
            border-top: 1px solid rgba(255,255,255,0.1);
            margin-top: 20px;
        }
        .user-avatar {
            width: 50px;
            height: 50px;
            background: white;
            border-radius: 50%;
            margin: 0 auto 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            font-weight: bold;
            font-size: 20px;
        }
        .logout-link {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background: rgba(255,255,255,0.1);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
        }
        @media (max-width: 768px) {
            .admin-container {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
            }
            .main-content {
                margin-left: 0;
            }
            .table-header, .table-row {
                grid-template-columns: 1fr;
                gap: 15px;
            }
            .action-buttons {
                justify-content: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Admin Panel</h2>
                <p>MyBlog Management</p>
            </div>
            
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="../dashboard.php" class="nav-link">
                        <span class="nav-icon">📊</span>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../article/index.php" class="nav-link">
                        <span class="nav-icon">📝</span>
                        <span>Kelola Artikel</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="list.php" class="nav-link active">
                        <span class="nav-icon">📚</span>
                        <span>Kelola Kategori</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <span class="nav-icon">💬</span>
                        <span>Komentar</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <span class="nav-icon">👥</span>
                        <span>Pengguna</span>
                    </a>
                </li>
            </ul>
            
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($_SESSION['admin_username'], 0, 1)); ?>
                </div>
                <div>
                    <strong><?php echo $_SESSION['admin_username']; ?></strong>
                    <p style="font-size: 12px; opacity: 0.8; margin-top: 5px;">Administrator</p>
                </div>
                <a href="../logout.php" class="logout-link">Logout</a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div class="page-title">
                    <h1>Kelola Kategori</h1>
                    <p>Kelola kategori artikel blog Anda</p>
                </div>
                <a href="create.php" class="btn-create">
                    <span>+</span> Tambah Kategori
                </a>
            </div>

            <div class="stats-cards">
                <div class="stat-card">
                    <div class="stat-icon">📚</div>
                    <div class="stat-number"><?php echo $total_categories; ?></div>
                    <div class="stat-label">Total Kategori</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">📝</div>
                    <div class="stat-number">
                        <?php 
                        $total_articles = mysqli_fetch_assoc(mysqli_query($konek, 
                            "SELECT COUNT(*) as total FROM articles WHERE is_published = 1"))['total'];
                        echo $total_articles;
                        ?>
                    </div>
                    <div class="stat-label">Artikel Terpublikasi</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">👁️</div>
                    <div class="stat-number">
                        <?php 
                        $total_views = mysqli_fetch_assoc(mysqli_query($konek, 
                            "SELECT SUM(view_count) as total FROM articles WHERE is_published = 1"))['total'];
                        echo number_format($total_views ?: 0);
                        ?>
                    </div>
                    <div class="stat-label">Total Views</div>
                </div>
            </div>

            <?php if(mysqli_num_rows($categories) > 0): ?>
                <div class="categories-table">
                    <div class="table-header">
                        <div>Kategori</div>
                        <div>Jumlah Artikel</div>
                        <div>Total Views</div>
                        <div>Aksi</div>
                    </div>
                    
                    <?php while($category = mysqli_fetch_assoc($categories)): ?>
                        <div class="table-row">
                            <div>
                                <div class="category-name"><?php echo htmlspecialchars($category['name']); ?></div>
                                <div class="category-slug">/<?php echo $category['slug']; ?></div>
                                <?php if($category['description']): ?>
                                    <div class="category-description">
                                        <?php echo htmlspecialchars($category['description']); ?>
                                    </div>
                                <?php endif; ?>
                                <div style="font-size: 12px; color: #999; margin-top: 5px;">
                                    Dibuat: <?php echo date('d M Y', strtotime($category['created_at'])); ?>
                                </div>
                            </div>
                            
                            <div class="article-count">
                                <span class="count-number"><?php echo $category['article_count']; ?></span>
                                <span class="count-label">artikel</span>
                            </div>
                            
                            <div class="total-views">
                                <strong><?php echo number_format($category['total_views'] ?: 0); ?></strong>
                                <span>views</span>
                            </div>
                            
                            <div class="action-buttons">
                                <a href="edit.php?id=<?php echo $category['id']; ?>" class="btn-action btn-edit">Edit</a>
                                <a href="delete.php?id=<?php echo $category['id']; ?>" 
                                   class="btn-action btn-delete"
                                   onclick="return confirm('Hapus kategori ini? Artikel dalam kategori ini akan kehilangan kategori.')">Hapus</a>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
                
            <?php else: ?>
                <div class="empty-state">
                    <h3>Belum ada kategori</h3>
                    <p>Mulai dengan menambahkan kategori pertama Anda</p>
                    <a href="create.php" class="btn-create" style="margin-top: 20px;">Tambah Kategori Pertama</a>
                </div>
            <?php endif; ?>
            
            <div style="margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                <h3 style="margin-bottom: 10px; color: #333;">Tips:</h3>
                <ul style="color: #666; line-height: 1.6;">
                    <li>Gunakan kategori untuk mengorganisir artikel Anda</li>
                    <li>Buat kategori yang spesifik dan relevan</li>
                    <li>Hindari membuat terlalu banyak kategori</li>
                    <li>Gunakan deskripsi untuk menjelaskan tujuan kategori</li>
                </ul>
            </div>
        </div>
    </div>
</body>
</html>