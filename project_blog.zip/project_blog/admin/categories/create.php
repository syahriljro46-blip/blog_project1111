<?php
session_start();
require_once '../../config/database.php';

// Cek jika belum login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];
$error = '';
$success = '';

// Generate slug dari nama
function createSlug($text) {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    $text = strtolower($text);
    
    if (empty($text)) {
        return 'n-a';
    }
    
    return $text;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($konek, $_POST['name']);
    $slug = mysqli_real_escape_string($konek, $_POST['slug']);
    $description = mysqli_real_escape_string($konek, $_POST['description']);
    
    // Validasi
    if (empty($name)) {
        $error = "Nama kategori harus diisi!";
    } else {
        // Generate slug jika kosong
        if (empty($slug)) {
            $slug = createSlug($name);
        }
        
        // Cek slug unik
        $slug_check = mysqli_query($konek, "SELECT id FROM categories WHERE slug = '$slug'");
        if (mysqli_num_rows($slug_check) > 0) {
            $slug = $slug . '-' . time();
        }
        
        // Insert ke database
        $query = "INSERT INTO categories (name, slug, description) 
                  VALUES ('$name', '$slug', '$description')";
        
        if (mysqli_query($konek, $query)) {
            $success = "Kategori berhasil dibuat!";
            // Reset form
            $_POST = array();
        } else {
            $error = "Gagal membuat kategori: " . mysqli_error($konek);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Kategori - Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            color: #333;
        }
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            height: 100vh;
        }
        .logo {
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }
        .logo h2 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        .logo p {
            font-size: 12px;
            opacity: 0.8;
        }
        .nav-menu {
            list-style: none;
        }
        .nav-item {
            margin-bottom: 5px;
        }
        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        .nav-link:hover, .nav-link.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }
        .nav-icon {
            font-size: 18px;
        }
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }
        .header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-title h1 {
            font-size: 28px;
            color: #333;
            margin-bottom: 5px;
        }
        .page-title p {
            color: #666;
            font-size: 14px;
        }
        .btn-back {
            padding: 10px 20px;
            background: #f8f9fa;
            color: #333;
            text-decoration: none;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            max-width: 600px;
            margin: 0 auto;
        }
        .form-group {
            margin-bottom: 25px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 5px;
            font-size: 16px;
            font-family: inherit;
            transition: border 0.3s;
        }
        .form-control:focus {
            border-color: #28a745;
            outline: none;
        }
        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }
        .slug-preview {
            background: #f8f9fa;
            padding: 10px 15px;
            border-radius: 5px;
            font-size: 14px;
            color: #666;
            margin-top: 5px;
            border: 1px solid #e1e1e1;
        }
        .slug-preview strong {
            color: #333;
        }
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        .btn-submit {
            padding: 15px 30px;
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
        }
        .btn-cancel {
            padding: 15px 30px;
            background: #6c757d;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
        }
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #dc3545;
        }
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #28a745;
        }
        .char-count {
            font-size: 12px;
            color: #666;
            text-align: right;
            margin-top: 5px;
        }
        .user-info {
            padding: 20px;
            text-align: center;
            border-top: 1px solid rgba(255,255,255,0.1);
            margin-top: 20px;
        }
        .user-avatar {
            width: 50px;
            height: 50px;
            background: white;
            border-radius: 50%;
            margin: 0 auto 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            font-weight: bold;
            font-size: 20px;
        }
        .logout-link {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background: rgba(255,255,255,0.1);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
        }
        @media (max-width: 768px) {
            .admin-container {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
            }
            .main-content {
                margin-left: 0;
            }
            .form-container {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Admin Panel</h2>
                <p>MyBlog Management</p>
            </div>
            
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="../dashboard.php" class="nav-link">
                        <span class="nav-icon">📊</span>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../article/index.php" class="nav-link">
                        <span class="nav-icon">📝</span>
                        <span>Kelola Artikel</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="list.php" class="nav-link">
                        <span class="nav-icon">📚</span>
                        <span>Kelola Kategori</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="create.php" class="nav-link active">
                        <span class="nav-icon">✏️</span>
                        <span>Tambah Kategori</span>
                    </a>
                </li>
            </ul>
            
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($_SESSION['admin_username'], 0, 1)); ?>
                </div>
                <div>
                    <strong><?php echo $_SESSION['admin_username']; ?></strong>
                    <p style="font-size: 12px; opacity: 0.8; margin-top: 5px;">Administrator</p>
                </div>
                <a href="../logout.php" class="logout-link">Logout</a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div class="page-title">
                    <h1>Tambah Kategori Baru</h1>
                    <p>Buat kategori baru untuk mengorganisir artikel</p>
                </div>
                <a href="list.php" class="btn-back">← Kembali</a>
            </div>

            <?php if($error): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if($success): ?>
                <div class="success-message"><?php echo $success; ?></div>
            <?php endif; ?>

            <div class="form-container">
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="name">Nama Kategori *</label>
                        <input type="text" id="name" name="name" class="form-control" 
                               value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" 
                               required oninput="updateSlug()" maxlength="100">
                        <div class="char-count" id="nameCount">0/100 karakter</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="slug">Slug URL</label>
                        <input type="text" id="slug" name="slug" class="form-control" 
                               value="<?php echo isset($_POST['slug']) ? htmlspecialchars($_POST['slug']) : ''; ?>"
                               placeholder="otomatis-terbuat-dari-nama">
                        <div class="slug-preview">
                            Preview: <strong id="slugPreview"><?php 
                                echo isset($_POST['slug']) && !empty($_POST['slug']) 
                                    ? htmlspecialchars($_POST['slug']) 
                                    : 'slug-akan-terbuat-otomatis'; 
                            ?></strong>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Deskripsi (Opsional)</label>
                        <textarea id="description" name="description" class="form-control" 
                                  rows="4"><?php echo isset($_POST['description']) ? htmlspecialchars($_POST['description']) : ''; ?></textarea>
                        <div class="char-count" id="descriptionCount">0 karakter</div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn-submit">Simpan Kategori</button>
                        <a href="list.php" class="btn-cancel">Batal</a>
                    </div>
                </form>
            </div>
            
            <div style="margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 10px;">
                <h3 style="margin-bottom: 10px; color: #333;">Contoh Kategori yang Baik:</h3>
                <ul style="color: #666; line-height: 1.6;">
                    <li><strong>Teknologi</strong> - Artikel tentang perkembangan teknologi terbaru</li>
                    <li><strong>Pemrograman</strong> - Tutorial dan tips coding</li>
                    <li><strong>Desain UI/UX</strong> - Prinsip dan praktik desain terbaik</li>
                    <li><strong>Bisnis Digital</strong> - Strategi dan tips bisnis online</li>
                </ul>
            </div>
        </div>
    </div>

    <script>
    function updateSlug() {
        const name = document.getElementById('name').value;
        const slugInput = document.getElementById('slug');
        const slugPreview = document.getElementById('slugPreview');
        
        if (!slugInput.value) {
            // Generate slug dari nama
            let slug = name.toLowerCase()
                .replace(/[^\w\s]/gi, '')
                .replace(/\s+/g, '-')
                .replace(/-+/g, '-')
                .trim();
            
            slugPreview.textContent = slug || 'slug-akan-terbuat-otomatis';
        }
        
        // Update character count
        const nameCount = document.getElementById('nameCount');
        nameCount.textContent = name.length + '/100 karakter';
    }
    
    // Update character counts
    document.getElementById('description').addEventListener('input', function() {
        const count = this.value.length;
        document.getElementById('descriptionCount').textContent = count + ' karakter';
    });
    
    // Initialize counts
    document.addEventListener('DOMContentLoaded', function() {
        updateSlug();
        document.getElementById('description').dispatchEvent(new Event('input'));
    });
    </script>
</body>
</html>