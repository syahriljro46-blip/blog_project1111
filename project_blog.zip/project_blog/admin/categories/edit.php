<?php
session_start();
require_once '../../config/database.php';

// Cek jika belum login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];
$error = '';
$success = '';

// Ambil ID kategori dari URL
$category_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($category_id == 0) {
    header("Location: list.php");
    exit();
}

// Ambil data kategori
$category_query = "SELECT * FROM categories WHERE id = $category_id";
$category_result = mysqli_query($konek, $category_query);

if (mysqli_num_rows($category_result) == 0) {
    header("Location: list.php");
    exit();
}

$category = mysqli_fetch_assoc($category_result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($konek, $_POST['name']);
    $slug = mysqli_real_escape_string($konek, $_POST['slug']);
    $description = mysqli_real_escape_string($konek, $_POST['description']);
    
    // Validasi
    if (empty($name)) {
        $error = "Nama kategori harus diisi!";
    } else {
        // Generate slug jika kosong
        if (empty($slug)) {
            $slug = preg_replace('/[^\w\s]/', '', $name);
            $slug = strtolower(str_replace(' ', '-', $slug));
            $slug = preg_replace('/-+/', '-', $slug);
        }
        
        // Cek slug unik (kecuali untuk kategori ini)
        $slug_check = mysqli_query($konek, "SELECT id FROM categories WHERE slug = '$slug' AND id != $category_id");
        if (mysqli_num_rows($slug_check) > 0) {
            $slug = $slug . '-' . time();
        }
        
        // Update database
        $query = "UPDATE categories SET 
                    name = '$name',
                    slug = '$slug',
                    description = '$description'
                  WHERE id = $category_id";
        
        if (mysqli_query($konek, $query)) {
            $success = "Kategori berhasil diperbarui!";
            // Refresh data kategori
            $category_result = mysqli_query($konek, $category_query);
            $category = mysqli_fetch_assoc($category_result);
        } else {
            $error = "Gagal memperbarui kategori: " . mysqli_error($konek);
        }
    }
}

// Ambil statistik kategori
$stats_query = "SELECT 
                COUNT(a.id) as article_count,
                SUM(a.view_count) as total_views,
                MIN(a.created_at) as first_article,
                MAX(a.created_at) as last_article
                FROM articles a 
                WHERE a.category_id = $category_id AND a.is_published = 1";
$stats_result = mysqli_query($konek, $stats_query);
$stats = mysqli_fetch_assoc($stats_result);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kategori - Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            color: #333;
        }
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            height: 100vh;
        }
        .logo {
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }
        .logo h2 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        .logo p {
            font-size: 12px;
            opacity: 0.8;
        }
        .nav-menu {
            list-style: none;
        }
        .nav-item {
            margin-bottom: 5px;
        }
        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        .nav-link:hover, .nav-link.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }
        .nav-icon {
            font-size: 18px;
        }
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }
        .header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-title h1 {
            font-size: 28px;
            color: #333;
            margin-bottom: 5px;
        }
        .page-title p {
            color: #666;
            font-size: 14px;
        }
        .btn-back {
            padding: 10px 20px;
            background: #f8f9fa;
            color: #333;
            text-decoration: none;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .category-stats {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }
        .stat-item {
            text-align: center;
        }
        .stat-icon {
            font-size: 30px;
            margin-bottom: 10px;
            color: #667eea;
        }
        .stat-number {
            font-size: 24px;
            font-weight: bold;
            color: #333;
            display: block;
        }
        .stat-label {
            font-size: 12px;
            color: #666;
        }
        .form-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            max-width: 600px;
            margin: 0 auto;
        }
        .form-group {
            margin-bottom: 25px;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 5px;
            font-size: 16px;
            font-family: inherit;
            transition: border 0.3s;
        }
        .form-control:focus {
            border-color: #ffc107;
            outline: none;
        }
        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        .btn-update {
            padding: 15px 30px;
            background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%);
            color: #333;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .btn-update:hover {
            transform: translateY(-2px);
        }
        .btn-delete {
            padding: 15px 30px;
            background: #dc3545;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
        }
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #dc3545;
        }
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #28a745;
        }
        .char-count {
            font-size: 12px;
            color: #666;
            text-align: right;
            margin-top: 5px;
        }
        .user-info {
            padding: 20px;
            text-align: center;
            border-top: 1px solid rgba(255,255,255,0.1);
            margin-top: 20px;
        }
        .user-avatar {
            width: 50px;
            height: 50px;
            background: white;
            border-radius: 50%;
            margin: 0 auto 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            font-weight: bold;
            font-size: 20px;
        }
        .logout-link {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background: rgba(255,255,255,0.1);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
        }
        @media (max-width: 768px) {
            .admin-container {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
            }
            .main-content {
                margin-left: 0;
            }
            .form-container {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Admin Panel</h2>
                <p>MyBlog Management</p>
            </div>
            
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="../dashboard.php" class="nav-link">
                        <span class="nav-icon">📊</span>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../article/index.php" class="nav-link">
                        <span class="nav-icon">📝</span>
                        <span>Kelola Artikel</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="list.php" class="nav-link">
                        <span class="nav-icon">📚</span>
                        <span>Kelola Kategori</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="create.php" class="nav-link">
                        <span class="nav-icon">✏️</span>
                        <span>Tambah Kategori</span>
                    </a>
                </li>
            </ul>
            
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($_SESSION['admin_username'], 0, 1)); ?>
                </div>
                <div>
                    <strong><?php echo $_SESSION['admin_username']; ?></strong>
                    <p style="font-size: 12px; opacity: 0.8; margin-top: 5px;">Administrator</p>
                </div>
                <a href="../logout.php" class="logout-link">Logout</a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div class="page-title">
                    <h1>Edit Kategori</h1>
                    <p>Perbarui informasi kategori</p>
                </div>
                <a href="list.php" class="btn-back">← Kembali ke Daftar</a>
            </div>

            <div class="category-stats">
                <div class="stat-item">
                    <div class="stat-icon">📝</div>
                    <div class="stat-number"><?php echo $stats['article_count'] ?: 0; ?></div>
                    <div class="stat-label">Artikel</div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon">👁️</div>
                    <div class="stat-number"><?php echo number_format($stats['total_views'] ?: 0); ?></div>
                    <div class="stat-label">Total Views</div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon">📅</div>
                    <div class="stat-number">
                        <?php 
                        if ($stats['first_article']) {
                            echo date('M Y', strtotime($stats['first_article']));
                        } else {
                            echo '-';
                        }
                        ?>
                    </div>
                    <div class="stat-label">Artikel Pertama</div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon">🔄</div>
                    <div class="stat-number">
                        <?php 
                        if ($stats['last_article']) {
                            echo date('M Y', strtotime($stats['last_article']));
                        } else {
                            echo '-';
                        }
                        ?>
                    </div>
                    <div class="stat-label">Artikel Terakhir</div>
                </div>
            </div>

            <?php if($error): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if($success): ?>
                <div class="success-message"><?php echo $success; ?></div>
            <?php endif; ?>

            <div class="form-container">
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="name">Nama Kategori *</label>
                        <input type="text" id="name" name="name" class="form-control" 
                               value="<?php echo htmlspecialchars($category['name']); ?>" required maxlength="100">
                        <div class="char-count" id="nameCount"><?php echo strlen($category['name']); ?>/100 karakter</div>
                    </div>
                    
                    <div class="form-group">
                        <label for="slug">Slug URL</label>
                        <input type="text" id="slug" name="slug" class="form-control" 
                               value="<?php echo htmlspecialchars($category['slug']); ?>">
                        <div style="font-size: 12px; color: #666; margin-top: 5px;">
                            URL: <strong>/category/<?php echo $category['slug']; ?></strong>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Deskripsi</label>
                        <textarea id="description" name="description" class="form-control" 
                                  rows="4"><?php echo htmlspecialchars($category['description']); ?></textarea>
                        <div class="char-count" id="descriptionCount"><?php echo strlen($category['description']); ?> karakter</div>
                    </div>
                    
                    <div class="form-group">
                        <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; font-size: 14px;">
                            <strong>Info:</strong> 
                            <ul style="margin-top: 5px; color: #666;">
                                <li>ID Kategori: <?php echo $category['id']; ?></li>
                                <li>Dibuat: <?php echo date('d M Y H:i', strtotime($category['created_at'])); ?></li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn-update">Perbarui Kategori</button>
                        <a href="delete.php?id=<?php echo $category['id']; ?>" 
                           class="btn-delete"
                           onclick="return confirm('Hapus kategori ini? Artikel dalam kategori ini akan kehilangan kategori.')">
                            Hapus Kategori
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    // Update character counts
    document.getElementById('name').addEventListener('input', function() {
        const count = this.value.length;
        document.getElementById('nameCount').textContent = count + '/100 karakter';
    });
    
    document.getElementById('description').addEventListener('input', function() {
        const count = this.value.length;
        document.getElementById('descriptionCount').textContent = count + ' karakter';
    });
    </script>
</body>
</html>