<?php
session_start();
require_once '../../config/database.php';

// Cek jika belum login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];

// Ambil ID kategori dari URL
$category_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($category_id == 0) {
    header("Location: list.php");
    exit();
}

// Ambil data kategori
$category_query = "SELECT * FROM categories WHERE id = $category_id";
$category_result = mysqli_query($konek, $category_query);

if (mysqli_num_rows($category_result) == 0) {
    header("Location: list.php");
    exit();
}

$category = mysqli_fetch_assoc($category_result);

// Hitung artikel dalam kategori ini
$article_count = mysqli_fetch_assoc(mysqli_query($konek, 
    "SELECT COUNT(*) as count FROM articles WHERE category_id = $category_id"))['count'];

// Handle deletion
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['confirm_delete']) && $_POST['confirm_delete'] == 'yes') {
        // Hapus kategori (foreign key constraint akan set NULL untuk artikel)
        $delete_query = "DELETE FROM categories WHERE id = $category_id";
        
        if (mysqli_query($konek, $delete_query)) {
            // Redirect ke halaman kategori dengan pesan sukses
            header("Location: list.php?deleted=1");
            exit();
        } else {
            $error = "Gagal menghapus kategori: " . mysqli_error($konek);
        }
    } else {
        // Jika batal, redirect ke halaman kategori
        header("Location: list.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hapus Kategori - Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        .delete-container {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            max-width: 500px;
            width: 100%;
            text-align: center;
        }
        .warning-icon {
            font-size: 60px;
            color: #dc3545;
            margin-bottom: 20px;
        }
        .delete-title {
            font-size: 24px;
            color: #333;
            margin-bottom: 15px;
        }
        .delete-message {
            color: #666;
            line-height: 1.6;
            margin-bottom: 25px;
        }
        .category-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            text-align: left;
        }
        .category-info h4 {
            color: #333;
            margin-bottom: 10px;
            font-size: 18px;
        }
        .category-details {
            color: #666;
            font-size: 14px;
        }
        .category-details p {
            margin-bottom: 8px;
        }
        .warning-box {
            background: #fff3cd;
            color: #856404;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #ffc107;
            font-size: 14px;
            text-align: left;
        }
        .warning-box strong {
            display: block;
            margin-bottom: 5px;
        }
        .delete-actions {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 30px;
        }
        .btn {
            padding: 15px 30px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
        }
        .btn-delete {
            background: #dc3545;
            color: white;
        }
        .btn-delete:hover {
            background: #c82333;
            transform: translateY(-2px);
        }
        .btn-cancel {
            background: #6c757d;
            color: white;
        }
        .btn-cancel:hover {
            background: #5a6268;
            transform: translateY(-2px);
        }
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #dc3545;
        }
        .article-list {
            background: #fff;
            border: 1px solid #eee;
            border-radius: 5px;
            padding: 15px;
            margin-top: 15px;
            max-height: 200px;
            overflow-y: auto;
        }
        .article-item {
            padding: 8px 0;
            border-bottom: 1px solid #f0f0f0;
            font-size: 13px;
            display: flex;
            justify-content: space-between;
        }
        .article-item:last-child {
            border-bottom: none;
        }
        @media (max-width: 480px) {
            .delete-container {
                padding: 25px;
            }
            .delete-actions {
                flex-direction: column;
            }
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="delete-container">
        <div class="warning-icon">⚠️</div>
        <h1 class="delete-title">Hapus Kategori</h1>
        
        <?php if(isset($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="warning-box">
            <strong>Penting!</strong>
            Jika Anda menghapus kategori ini:
            <ul style="margin-top: 10px; padding-left: 20px;">
                <li>Kategori akan dihapus permanen</li>
                <li><strong><?php echo $article_count; ?> artikel</strong> dalam kategori ini akan kehilangan kategori</li>
                <li>Artikel tetap ada, tapi kategori mereka akan menjadi "Tidak ada kategori"</li>
                <li>Tindakan ini tidak dapat dibatalkan</li>
            </ul>
        </div>
        
        <div class="category-info">
            <h4>Kategori yang akan dihapus:</h4>
            <div class="category-details">
                <p><strong>Nama:</strong> <?php echo htmlspecialchars($category['name']); ?></p>
                <p><strong>Slug:</strong> <?php echo $category['slug']; ?></p>
                <p><strong>ID:</strong> <?php echo $category['id']; ?></p>
                <p><strong>Dibuat:</strong> <?php echo date('d M Y', strtotime($category['created_at'])); ?></p>
                <p><strong>Jumlah Artikel:</strong> <?php echo $article_count; ?> artikel</p>
                
                <?php if($article_count > 0): ?>
                    <div style="margin-top: 10px;">
                        <strong>Artikel dalam kategori ini:</strong>
                        <div class="article-list">
                            <?php 
                            $articles = mysqli_query($konek, 
                                "SELECT id, title FROM articles WHERE category_id = $category_id LIMIT 10");
                            while($article = mysqli_fetch_assoc($articles)): 
                            ?>
                                <div class="article-item">
                                    <span><?php echo htmlspecialchars($article['title']); ?></span>
                                    <span style="color: #999;">ID: <?php echo $article['id']; ?></span>
                                </div>
                            <?php endwhile; 
                            if($article_count > 10): ?>
                                <div style="text-align: center; padding: 10px; color: #999; font-style: italic;">
                                    ... dan <?php echo $article_count - 10; ?> artikel lainnya
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="delete-message">
            <strong>Alternatif:</strong> Pertimbangkan untuk mengganti nama kategori daripada menghapusnya.
        </div>
        
        <form method="POST" action="">
            <input type="hidden" name="confirm_delete" value="yes">
            
            <div class="delete-actions">
                <button type="submit" class="btn btn-delete" 
                        onclick="return confirm('Yakin 100% ingin menghapus kategori ini? <?php echo $article_count; ?> artikel akan kehilangan kategori.')">
                    Ya, Hapus Kategori
                </button>
                <a href="list.php" class="btn btn-cancel">Batal</a>
                <a href="edit.php?id=<?php echo $category['id']; ?>" class="btn" style="background: #17a2b8; color: white;">
                    Edit Kategori
                </a>
            </div>
        </form>
    </div>
</body>
</html>