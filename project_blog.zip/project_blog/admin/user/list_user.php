<?php
session_start();
require_once '../../config/database.php';

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

// Query untuk mendapatkan semua user dengan statistik
$query = "SELECT 
            u.*,
            COUNT(DISTINCT c.id) as comment_count,
            COUNT(DISTINCT al.id) as like_count,
            (SELECT COUNT(*) FROM comments WHERE user_id = u.id AND is_approved = 0) as pending_comments
          FROM users u
          LEFT JOIN comments c ON u.id = c.user_id
          LEFT JOIN article_likes al ON u.id = al.user_id
          GROUP BY u.id
          ORDER BY u.created_at DESC";
$result = mysqli_query($konek, $query);

// Hitung total users
$total_query = "SELECT COUNT(*) as total FROM users";
$total_result = mysqli_query($konek, $total_query);
$total_data = mysqli_fetch_assoc($total_result);
$total_users = $total_data['total'];

// Hitung users aktif (yang punya aktivitas)
$active_query = "SELECT COUNT(DISTINCT user_id) as active FROM (
                    SELECT user_id FROM comments 
                    UNION 
                    SELECT user_id FROM article_likes
                ) as activity";
$active_result = mysqli_query($konek, $active_query);
$active_data = mysqli_fetch_assoc($active_result);
$active_users = $active_data['active'];

// Pesan sukses dan error
$success_message = '';
$error_message = '';

if(isset($_GET['success'])) {
    if($_GET['success'] == 'updated') {
        $success_message = "User berhasil diupdate!";
    } elseif($_GET['success'] == 'deleted') {
        $success_message = "User berhasil dihapus!";
    }
}

if(isset($_GET['error'])) {
    if($_GET['error'] == 'delete_failed') {
        $error_message = "Gagal menghapus user!";
    } elseif($_GET['error'] == 'not_found') {
        $error_message = "User tidak ditemukan!";
    } elseif($_GET['error'] == 'invalid_id') {
        $error_message = "ID user tidak valid!";
    } else {
        $error_message = "Terjadi kesalahan!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen User - Admin Blog</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #1a237e 0%, #283593 100%);
            color: white;
            padding: 20px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 3px 0 15px rgba(0,0,0,0.1);
        }

        .logo {
            text-align: center;
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 30px;
        }

        .logo h2 {
            font-size: 24px;
            color: white;
        }

        .logo span {
            color: #64b5f6;
        }

        .nav-menu {
            list-style: none;
            padding: 0 20px;
        }

        .nav-menu li {
            margin-bottom: 5px;
        }

        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            color: #b3c5e7;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .nav-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: white;
        }

        .nav-menu a.active {
            background: rgba(100, 181, 246, 0.2);
            color: #64b5f6;
            border-left: 4px solid #64b5f6;
        }

        .nav-menu i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .header h1 {
            color: #2c3e50;
            font-size: 28px;
        }

        .header h1 i {
            color: #64b5f6;
            margin-right: 10px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-info a {
            color: #7f8c8d;
            text-decoration: none;
            transition: color 0.3s;
        }

        .user-info a:hover {
            color: #3498db;
        }

        /* Stats Cards */
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 20px;
            font-size: 24px;
        }

        .stat-icon.total {
            background: #e3f2fd;
            color: #1976d2;
        }

        .stat-icon.active {
            background: #e8f5e9;
            color: #388e3c;
        }

        .stat-icon.new {
            background: #fff3e0;
            color: #f57c00;
        }

        .stat-info h3 {
            font-size: 14px;
            color: #7f8c8d;
            margin-bottom: 5px;
        }

        .stat-info .number {
            font-size: 28px;
            font-weight: bold;
            color: #2c3e50;
        }

        /* Users Table */
        .users-table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .table-header {
            padding: 20px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .table-header h2 {
            color: #2c3e50;
        }

        .actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
            transition: all 0.3s;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-primary {
            background: #2196f3;
            color: white;
        }

        .btn-primary:hover {
            background: #1976d2;
            transform: translateY(-2px);
        }

        .btn-success {
            background: #4caf50;
            color: white;
        }

        .btn-success:hover {
            background: #388e3c;
        }

        .btn-danger {
            background: #f44336;
            color: white;
        }

        .btn-danger:hover {
            background: #d32f2f;
        }

        .btn-warning {
            background: #ff9800;
            color: white;
        }

        .btn-warning:hover {
            background: #f57c00;
        }

        .btn-info {
            background: #17a2b8;
            color: white;
        }

        .btn-info:hover {
            background: #138496;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: #f8f9fa;
        }

        th {
            padding: 15px;
            text-align: left;
            color: #2c3e50;
            font-weight: 600;
            border-bottom: 2px solid #eee;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
            vertical-align: middle;
        }

        tr:hover {
            background: #f9f9f9;
        }

        .user-info-cell {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #e3f2fd;
        }

        .user-details {
            flex: 1;
        }

        .user-name {
            font-weight: 500;
            color: #2c3e50;
            display: block;
            margin-bottom: 3px;
        }

        .user-username {
            font-size: 12px;
            color: #7f8c8d;
            display: block;
        }

        .user-email {
            font-size: 12px;
            color: #2196f3;
            display: block;
            margin-top: 3px;
        }

        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            display: inline-block;
        }

        .badge-active {
            background: #e8f5e9;
            color: #388e3c;
        }

        .badge-inactive {
            background: #ffebee;
            color: #c62828;
        }

        .badge-pending {
            background: #fff3e0;
            color: #f57c00;
        }

        .actions-cell {
            display: flex;
            gap: 8px;
        }

        .btn-small {
            padding: 6px 12px;
            font-size: 12px;
            border-radius: 6px;
        }

        .btn-icon {
            width: 32px;
            height: 32px;
            padding: 0;
            justify-content: center;
            border-radius: 50%;
        }

        .stats-cell {
            text-align: center;
        }

        .stat-number {
            font-size: 18px;
            font-weight: bold;
            color: #2c3e50;
            display: block;
        }

        .stat-label {
            font-size: 11px;
            color: #7f8c8d;
            text-transform: uppercase;
        }

        /* Search and Filter */
        .search-filter {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            align-items: center;
        }

        .search-box {
            flex: 1;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 12px 20px 12px 45px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }

        .search-box input:focus {
            outline: none;
            border-color: #2196f3;
            box-shadow: 0 0 0 3px rgba(33, 150, 243, 0.1);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #7f8c8d;
        }

        .filter-select {
            padding: 12px 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background: white;
            font-size: 14px;
            color: #333;
            min-width: 150px;
        }

        /* No Users */
        .no-users {
            text-align: center;
            padding: 50px;
            color: #7f8c8d;
        }

        .no-users i {
            font-size: 48px;
            margin-bottom: 20px;
            color: #bdc3c7;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .sidebar {
                width: 70px;
            }
            
            .main-content {
                margin-left: 70px;
            }
            
            .logo h2 {
                font-size: 0;
            }
            
            .logo h2:after {
                content: "B";
                font-size: 24px;
            }
            
            .nav-menu a span {
                display: none;
            }
            
            .nav-menu a i {
                margin-right: 0;
                font-size: 20px;
            }
        }

        @media (max-width: 768px) {
            .stats-cards {
                grid-template-columns: 1fr;
            }
            
            table {
                display: block;
                overflow-x: auto;
            }
            
            .header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .search-filter {
                flex-direction: column;
            }
            
            .actions-cell {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .btn-small {
                padding: 4px 8px;
                font-size: 11px;
            }
            
            .user-info-cell {
                flex-direction: column;
                text-align: center;
            }
        }

        /* Messages */
        .message {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .message-success {
            background: #e8f5e9;
            color: #2e7d32;
            border-left: 4px solid #4caf50;
        }

        .message-error {
            background: #ffebee;
            color: #c62828;
            border-left: 4px solid #f44336;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Blog<span>Admin</span></h2>
            </div>
            <ul class="nav-menu">
                <li><a href="../dashboard.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="../posts/list.php"><i class="fas fa-newspaper"></i> <span>Posts</span></a></li>
                <li><a href="../categories/list.php"><i class="fas fa-folder"></i> <span>Kategori</span></a></li>
                <li><a href="../tags/list.php"><i class="fas fa-tags"></i> <span>Tags</span></a></li>
                <li><a href="list_user.php" class="active"><i class="fas fa-users"></i> <span>Users</span></a></li>
                <li><a href="../media/list.php"><i class="fas fa-image"></i> <span>Media</span></a></li>
                <li><a href="../comments/list.php"><i class="fas fa-comments"></i> <span>Komentar</span></a></li>
                <li><a href="../profile.php"><i class="fas fa-user"></i> <span>Profil</span></a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <h1><i class="fas fa-users"></i> Manajemen User</h1>
                <div class="user-info">
                    <span>Halo, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>

            <!-- Success Message -->
            <?php if(!empty($success_message)): ?>
                <div class="message message-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
                </div>
            <?php endif; ?>

            <!-- Error Message -->
            <?php if(!empty($error_message)): ?>
                <div class="message message-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <!-- Stats Cards -->
            <div class="stats-cards">
                <div class="stat-card">
                    <div class="stat-icon total">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Total Users</h3>
                        <div class="number"><?php echo $total_users; ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon active">
                        <i class="fas fa-user-check"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Users Aktif</h3>
                        <div class="number"><?php echo $active_users; ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon new">
                        <i class="fas fa-user-plus"></i>
                    </div>
                    <div class="stat-info">
                        <h3>User Baru (30 hari)</h3>
                        <div class="number">
                            <?php
                            $new_users_query = "SELECT COUNT(*) as new FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
                            $new_users_result = mysqli_query($konek, $new_users_query);
                            $new_users_data = mysqli_fetch_assoc($new_users_result);
                            echo $new_users_data['new'];
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Search and Filter -->
            <div class="search-filter">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Cari users...">
                </div>
                <select class="filter-select" id="sortFilter">
                    <option value="recent">Terbaru</option>
                    <option value="oldest">Terlama</option>
                    <option value="name">Nama A-Z</option>
                    <option value="active">Paling Aktif</option>
                </select>
                <select class="filter-select" id="activityFilter">
                    <option value="">Semua User</option>
                    <option value="active">Aktif</option>
                    <option value="inactive">Tidak Aktif</option>
                </select>
            </div>

            <!-- Users Table -->
            <div class="users-table">
                <div class="table-header">
                    <h2>Daftar Users</h2>
                    <div class="actions">
                        <button class="btn btn-info" onclick="exportUsers()">
                            <i class="fas fa-download"></i> Export
                        </button>
                    </div>
                </div>

                <?php if(mysqli_num_rows($result) > 0): ?>
                    <table id="usersTable">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>User</th>
                                <th>Status</th>
                                <th>Statistik</th>
                                <th>Tanggal Bergabung</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($user = mysqli_fetch_assoc($result)): 
                                $is_active = ($user['comment_count'] > 0 || $user['like_count'] > 0);
                            ?>
                                <tr>
                                    <td>#<?php echo $user['id']; ?></td>
                                    <td>
                                        <div class="user-info-cell">
                                            <?php if(!empty($user['profile_image'])): ?>
                                                <img src="../../uploads/users/<?php echo htmlspecialchars($user['profile_image']); ?>" 
                                                     alt="Avatar" 
                                                     class="user-avatar"
                                                     onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($user['username']); ?>&background=2196f3&color=fff&size=50'">
                                            <?php else: ?>
                                                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user['username']); ?>&background=2196f3&color=fff&size=50" 
                                                     alt="Avatar" 
                                                     class="user-avatar">
                                            <?php endif; ?>
                                            <div class="user-details">
                                                <span class="user-name"><?php echo htmlspecialchars($user['full_name']); ?></span>
                                                <span class="user-username">@<?php echo htmlspecialchars($user['username']); ?></span>
                                                <span class="user-email"><?php echo htmlspecialchars($user['email']); ?></span>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <?php if($is_active): ?>
                                            <span class="badge badge-active">
                                                <i class="fas fa-check-circle"></i> Aktif
                                            </span>
                                        <?php else: ?>
                                            <span class="badge badge-inactive">
                                                <i class="fas fa-clock"></i> Tidak Aktif
                                            </span>
                                        <?php endif; ?>
                                        <?php if($user['pending_comments'] > 0): ?>
                                            <br>
                                            <span class="badge badge-pending" style="margin-top: 5px;">
                                                <i class="fas fa-comment"></i> <?php echo $user['pending_comments']; ?> komentar menunggu
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="stats-cell">
                                        <span class="stat-number"><?php echo $user['comment_count']; ?></span>
                                        <span class="stat-label">Komentar</span>
                                        <br>
                                        <span class="stat-number"><?php echo $user['like_count']; ?></span>
                                        <span class="stat-label">Likes</span>
                                    </td>
                                    <td>
                                        <?php echo date('d M Y', strtotime($user['created_at'])); ?><br>
                                        <small><?php echo date('H:i', strtotime($user['created_at'])); ?></small>
                                    </td>
                                    <td class="actions-cell">
                                        <a href="detail_user.php?id=<?php echo $user['id']; ?>" 
                                           class="btn btn-info btn-small"
                                           title="Detail User">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="edit_user.php?id=<?php echo $user['id']; ?>" 
                                           class="btn btn-warning btn-small"
                                           title="Edit User">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="delete_user.php?id=<?php echo $user['id']; ?>" 
                                           class="btn btn-danger btn-small"
                                           onclick="return confirmDelete(<?php echo $user['id']; ?>, '<?php echo addslashes($user['username']); ?>')"
                                           title="Hapus User">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="no-users">
                        <i class="fas fa-users"></i>
                        <h3>Belum ada users</h3>
                        <p>Tidak ada users yang ditemukan.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            const filter = this.value.toLowerCase();
            const rows = document.querySelectorAll('#usersTable tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });

        // Sort functionality
        document.getElementById('sortFilter').addEventListener('change', function() {
            const sortBy = this.value;
            const rows = Array.from(document.querySelectorAll('#usersTable tbody tr'));
            
            rows.sort((a, b) => {
                if (sortBy === 'recent') {
                    const dateA = new Date(a.cells[4].textContent);
                    const dateB = new Date(b.cells[4].textContent);
                    return dateB - dateA;
                } else if (sortBy === 'oldest') {
                    const dateA = new Date(a.cells[4].textContent);
                    const dateB = new Date(b.cells[4].textContent);
                    return dateA - dateB;
                } else if (sortBy === 'name') {
                    const nameA = a.cells[1].querySelector('.user-name').textContent.toLowerCase();
                    const nameB = b.cells[1].querySelector('.user-name').textContent.toLowerCase();
                    return nameA.localeCompare(nameB);
                } else if (sortBy === 'active') {
                    const commentA = parseInt(a.cells[3].querySelectorAll('.stat-number')[0].textContent);
                    const commentB = parseInt(b.cells[3].querySelectorAll('.stat-number')[0].textContent);
                    return commentB - commentA;
                }
                return 0;
            });
            
            const tbody = document.querySelector('#usersTable tbody');
            tbody.innerHTML = '';
            rows.forEach(row => tbody.appendChild(row));
        });

        // Activity filter
        document.getElementById('activityFilter').addEventListener('change', function() {
            const filterValue = this.value;
            const rows = document.querySelectorAll('#usersTable tbody tr');
            
            rows.forEach(row => {
                if (!filterValue) {
                    row.style.display = '';
                    return;
                }
                
                const statusCell = row.cells[2].textContent.toLowerCase();
                if (filterValue === 'active' && statusCell.includes('aktif')) {
                    row.style.display = '';
                } else if (filterValue === 'inactive' && statusCell.includes('tidak aktif')) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });

        // Delete confirmation
        function confirmDelete(id, username) {
            Swal.fire({
                title: 'Hapus User?',
                html: `User <strong>"${username}"</strong> akan dihapus secara permanen.<br><br>
                      <small style="color: #f44336;">
                        <i class="fas fa-exclamation-triangle"></i> 
                        Semua data user termasuk komentar dan likes akan ikut terhapus!
                      </small>`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `delete_user.php?id=${id}`;
                }
            });
            return false;
        }

        // Export function
        function exportUsers() {
            Swal.fire({
                title: 'Export Users',
                text: 'Pilih format export:',
                icon: 'info',
                showCancelButton: true,
                confirmButtonText: 'CSV',
                cancelButtonText: 'JSON',
                showDenyButton: true,
                denyButtonText: 'PDF'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'export_users.php?format=csv';
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    window.location.href = 'export_users.php?format=json';
                } else if (result.isDenied) {
                    window.location.href = 'export_users.php?format=pdf';
                }
            });
        }

        // Show success messages
        <?php if(!empty($success_message)): ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: '<?php echo addslashes($success_message); ?>',
                timer: 3000,
                showConfirmButton: false
            });
        <?php endif; ?>

        <?php if(!empty($error_message)): ?>
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: '<?php echo addslashes($error_message); ?>'
            });
        <?php endif; ?>
    </script>
</body>
</html>