<?php
session_start();
require_once '../../config/database.php';

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

// Ambil ID user dari URL
$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($user_id <= 0) {
    header("Location: list_user.php?error=invalid_id");
    exit();
}

// Ambil data user dengan statistik lengkap
$query = "SELECT 
            u.*,
            COUNT(DISTINCT c.id) as total_comments,
            COUNT(DISTINCT CASE WHEN c.is_approved = 1 THEN c.id END) as approved_comments,
            COUNT(DISTINCT CASE WHEN c.is_approved = 0 THEN c.id END) as pending_comments,
            COUNT(DISTINCT al.id) as total_likes,
            (SELECT COUNT(DISTINCT article_id) FROM comments WHERE user_id = u.id) as articles_commented,
            (SELECT COUNT(DISTINCT article_id) FROM article_likes WHERE user_id = u.id) as articles_liked,
            (SELECT MAX(created_at) FROM comments WHERE user_id = u.id) as last_comment_date,
            (SELECT MAX(created_at) FROM article_likes WHERE user_id = u.id) as last_like_date
          FROM users u
          LEFT JOIN comments c ON u.id = c.user_id
          LEFT JOIN article_likes al ON u.id = al.user_id
          WHERE u.id = $user_id
          GROUP BY u.id";
$result = mysqli_query($konek, $query);

if (mysqli_num_rows($result) == 0) {
    header("Location: list_user.php?error=not_found");
    exit();
}

$user = mysqli_fetch_assoc($result);

// Ambil komentar terbaru user
$comments_query = "SELECT 
                    c.*,
                    a.title as article_title,
                    a.slug as article_slug
                   FROM comments c
                   JOIN articles a ON c.article_id = a.id
                   WHERE c.user_id = $user_id
                   ORDER BY c.created_at DESC
                   LIMIT 5";
$comments_result = mysqli_query($konek, $comments_query);

// Ambil artikel yang disukai user
$likes_query = "SELECT 
                 al.*,
                 a.title as article_title,
                 a.slug as article_slug
                FROM article_likes al
                JOIN articles a ON al.article_id = a.id
                WHERE al.user_id = $user_id
                ORDER BY al.created_at DESC
                LIMIT 5";
$likes_result = mysqli_query($konek, $likes_query);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail User - Admin Blog</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #1a237e 0%, #283593 100%);
            color: white;
            padding: 20px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 3px 0 15px rgba(0,0,0,0.1);
        }

        .logo {
            text-align: center;
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 30px;
        }

        .logo h2 {
            font-size: 24px;
            color: white;
        }

        .logo span {
            color: #64b5f6;
        }

        .nav-menu {
            list-style: none;
            padding: 0 20px;
        }

        .nav-menu li {
            margin-bottom: 5px;
        }

        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            color: #b3c5e7;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .nav-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: white;
        }

        .nav-menu a.active {
            background: rgba(100, 181, 246, 0.2);
            color: #64b5f6;
            border-left: 4px solid #64b5f6;
        }

        .nav-menu i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .header h1 {
            color: #2c3e50;
            font-size: 28px;
        }

        .header h1 i {
            color: #64b5f6;
            margin-right: 10px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-info a {
            color: #7f8c8d;
            text-decoration: none;
            transition: color 0.3s;
        }

        .user-info a:hover {
            color: #3498db;
        }

        /* Profile Container */
        .profile-container {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 30px;
        }

        @media (max-width: 1024px) {
            .profile-container {
                grid-template-columns: 1fr;
            }
        }

        /* Profile Sidebar */
        .profile-sidebar {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            text-align: center;
        }

        .profile-image {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            overflow: hidden;
            margin: 0 auto 20px;
            border: 5px solid #e3f2fd;
        }

        .profile-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .profile-name {
            font-size: 24px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 5px;
        }

        .profile-username {
            color: #7f8c8d;
            margin-bottom: 15px;
        }

        .profile-email {
            color: #2196f3;
            margin-bottom: 30px;
            word-break: break-all;
        }

        .profile-stats {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin: 30px 0;
        }

        .profile-stat {
            text-align: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
        }

        .stat-number {
            font-size: 24px;
            font-weight: 600;
            color: #2c3e50;
            display: block;
        }

        .stat-label {
            font-size: 12px;
            color: #7f8c8d;
            text-transform: uppercase;
        }

        /* Profile Content */
        .profile-content {
            display: flex;
            flex-direction: column;
            gap: 30px;
        }

        /* Info Card */
        .info-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }

        .info-card h2 {
            color: #2c3e50;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .info-card h2 i {
            color: #64b5f6;
        }

        /* User Info Grid */
        .user-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .info-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 10px;
            border-left: 4px solid #2196f3;
        }

        .info-label {
            font-size: 12px;
            color: #7f8c8d;
            text-transform: uppercase;
            margin-bottom: 5px;
        }

        .info-value {
            font-size: 16px;
            font-weight: 500;
            color: #2c3e50;
        }

        /* Activity List */
        .activity-list {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .activity-item {
            display: flex;
            align-items: center;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 10px;
            transition: all 0.3s;
        }

        .activity-item:hover {
            background: #e3f2fd;
            transform: translateX(5px);
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e3f2fd;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            color: #2196f3;
        }

        .activity-content {
            flex: 1;
        }

        .activity-title {
            font-weight: 500;
            color: #2c3e50;
            margin-bottom: 5px;
        }

        .activity-meta {
            font-size: 12px;
            color: #7f8c8d;
        }

        .activity-date {
            font-size: 12px;
            color: #7f8c8d;
            white-space: nowrap;
        }

        /* Buttons */
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
            transition: all 0.3s;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-primary {
            background: #2196f3;
            color: white;
        }

        .btn-primary:hover {
            background: #1976d2;
            transform: translateY(-2px);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #545b62;
        }

        .btn-danger {
            background: #f44336;
            color: white;
        }

        .btn-danger:hover {
            background: #d32f2f;
        }

        .btn-warning {
            background: #ff9800;
            color: white;
        }

        .btn-warning:hover {
            background: #f57c00;
        }

        .btn-success {
            background: #4caf50;
            color: white;
        }

        .btn-success:hover {
            background: #388e3c;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
            margin-top: 30px;
            justify-content: center;
        }

        /* No Activity */
        .no-activity {
            text-align: center;
            padding: 30px;
            color: #7f8c8d;
        }

        .no-activity i {
            font-size: 48px;
            margin-bottom: 15px;
            color: #bdc3c7;
        }

        /* Badge */
        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            display: inline-block;
        }

        .badge-active {
            background: #e8f5e9;
            color: #388e3c;
        }

        .badge-inactive {
            background: #ffebee;
            color: #c62828;
        }

        .badge-pending {
            background: #fff3e0;
            color: #f57c00;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .sidebar {
                width: 70px;
            }
            
            .main-content {
                margin-left: 70px;
            }
            
            .logo h2 {
                font-size: 0;
            }
            
            .logo h2:after {
                content: "B";
                font-size: 24px;
            }
            
            .nav-menu a span {
                display: none;
            }
            
            .nav-menu a i {
                margin-right: 0;
                font-size: 20px;
            }
        }

        @media (max-width: 768px) {
            .profile-stats {
                grid-template-columns: 1fr;
            }
            
            .user-info-grid {
                grid-template-columns: 1fr;
            }
            
            .header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .action-buttons {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Blog<span>Admin</span></h2>
            </div>
            <ul class="nav-menu">
                <li><a href="../dashboard.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="../posts/list.php"><i class="fas fa-newspaper"></i> <span>Posts</span></a></li>
                <li><a href="../categories/list.php"><i class="fas fa-folder"></i> <span>Kategori</span></a></li>
                <li><a href="../tags/list.php"><i class="fas fa-tags"></i> <span>Tags</span></a></li>
                <li><a href="list_user.php"><i class="fas fa-users"></i> <span>Users</span></a></li>
                <li><a href="../media/list.php"><i class="fas fa-image"></i> <span>Media</span></a></li>
                <li><a href="../comments/list.php"><i class="fas fa-comments"></i> <span>Komentar</span></a></li>
                <li><a href="../profile.php"><i class="fas fa-user"></i> <span>Profil</span></a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <h1><i class="fas fa-user"></i> Detail User</h1>
                <div class="user-info">
                    <span>Halo, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>

            <!-- Profile Container -->
            <div class="profile-container">
                <!-- Profile Sidebar -->
                <div class="profile-sidebar">
                    <div class="profile-image">
                        <?php if(!empty($user['profile_image'])): ?>
                            <img src="../../uploads/users/<?php echo htmlspecialchars($user['profile_image']); ?>" 
                                 alt="Profile Image"
                                 onerror="this.src='https://ui-avatars.com/api/?name=<?php echo urlencode($user['username']); ?>&background=2196f3&color=fff&size=150'">
                        <?php else: ?>
                            <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($user['username']); ?>&background=2196f3&color=fff&size=150" 
                                 alt="Profile Image">
                        <?php endif; ?>
                    </div>
                    
                    <div class="profile-name"><?php echo htmlspecialchars($user['full_name']); ?></div>
                    <div class="profile-username">@<?php echo htmlspecialchars($user['username']); ?></div>
                    <div class="profile-email"><?php echo htmlspecialchars($user['email']); ?></div>
                    
                    <?php 
                    $is_active = ($user['total_comments'] > 0 || $user['total_likes'] > 0);
                    ?>
                    <span class="badge <?php echo $is_active ? 'badge-active' : 'badge-inactive'; ?>">
                        <i class="fas fa-<?php echo $is_active ? 'check-circle' : 'clock'; ?>"></i> 
                        <?php echo $is_active ? 'Aktif' : 'Tidak Aktif'; ?>
                    </span>
                    
                    <div class="profile-stats">
                        <div class="profile-stat">
                            <span class="stat-number"><?php echo $user['total_comments']; ?></span>
                            <span class="stat-label">Komentar</span>
                        </div>
                        <div class="profile-stat">
                            <span class="stat-number"><?php echo $user['total_likes']; ?></span>
                            <span class="stat-label">Likes</span>
                        </div>
                        <div class="profile-stat">
                            <span class="stat-number"><?php echo $user['articles_commented']; ?></span>
                            <span class="stat-label">Artikel Dikomentari</span>
                        </div>
                        <div class="profile-stat">
                            <span class="stat-number"><?php echo $user['articles_liked']; ?></span>
                            <span class="stat-label">Artikel Disukai</span>
                        </div>
                    </div>
                    
                    <div class="action-buttons">
                        <a href="edit_user.php?id=<?php echo $user_id; ?>" class="btn btn-warning">
                            <i class="fas fa-edit"></i> Edit User
                        </a>
                        <a href="list_user.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Kembali
                        </a>
                    </div>
                </div>

                <!-- Profile Content -->
                <div class="profile-content">
                    <!-- User Information -->
                    <div class="info-card">
                        <h2><i class="fas fa-info-circle"></i> Informasi User</h2>
                        
                        <div class="user-info-grid">
                            <div class="info-item">
                                <div class="info-label">ID User</div>
                                <div class="info-value">#<?php echo $user['id']; ?></div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Nama Lengkap</div>
                                <div class="info-value"><?php echo htmlspecialchars($user['full_name']); ?></div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Username</div>
                                <div class="info-value">@<?php echo htmlspecialchars($user['username']); ?></div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Email</div>
                                <div class="info-value"><?php echo htmlspecialchars($user['email']); ?></div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Tanggal Bergabung</div>
                                <div class="info-value"><?php echo date('d M Y H:i', strtotime($user['created_at'])); ?></div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Terakhir Update</div>
                                <div class="info-value"><?php echo date('d M Y H:i', strtotime($user['updated_at'])); ?></div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Komentar Disetujui</div>
                                <div class="info-value"><?php echo $user['approved_comments']; ?> dari <?php echo $user['total_comments']; ?></div>
                            </div>
                            <div class="info-item">
                                <div class="info-label">Komentar Menunggu</div>
                                <div class="info-value">
                                    <?php if($user['pending_comments'] > 0): ?>
                                        <span class="badge badge-pending"><?php echo $user['pending_comments']; ?> komentar</span>
                                    <?php else: ?>
                                        <span style="color: #388e3c;">Tidak ada</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Comments -->
                    <div class="info-card">
                        <h2><i class="fas fa-comments"></i> Komentar Terbaru</h2>
                        
                        <?php if(mysqli_num_rows($comments_result) > 0): ?>
                            <div class="activity-list">
                                <?php while($comment = mysqli_fetch_assoc($comments_result)): ?>
                                    <div class="activity-item">
                                        <div class="activity-icon">
                                            <i class="fas fa-comment"></i>
                                        </div>
                                        <div class="activity-content">
                                            <div class="activity-title">
                                                <a href="../../post.php?slug=<?php echo $comment['article_slug']; ?>" target="_blank">
                                                    <?php echo htmlspecialchars($comment['article_title']); ?>
                                                </a>
                                            </div>
                                            <div class="activity-meta">
                                                <?php echo htmlspecialchars(substr($comment['content'], 0, 100)); ?>...
                                            </div>
                                        </div>
                                        <div class="activity-date">
                                            <?php echo date('d M', strtotime($comment['created_at'])); ?><br>
                                            <small><?php echo date('H:i', strtotime($comment['created_at'])); ?></small>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <div class="no-activity">
                                <i class="fas fa-comment-slash"></i>
                                <h3>Belum ada komentar</h3>
                                <p>User ini belum membuat komentar apapun.</p>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Recent Likes -->
                    <div class="info-card">
                        <h2><i class="fas fa-heart"></i> Likes Terbaru</h2>
                        
                        <?php if(mysqli_num_rows($likes_result) > 0): ?>
                            <div class="activity-list">
                                <?php while($like = mysqli_fetch_assoc($likes_result)): ?>
                                    <div class="activity-item">
                                        <div class="activity-icon">
                                            <i class="fas fa-heart"></i>
                                        </div>
                                        <div class="activity-content">
                                            <div class="activity-title">
                                                <a href="../../post.php?slug=<?php echo $like['article_slug']; ?>" target="_blank">
                                                    <?php echo htmlspecialchars($like['article_title']); ?>
                                                </a>
                                            </div>
                                            <div class="activity-meta">
                                                Menyukai artikel ini
                                            </div>
                                        </div>
                                        <div class="activity-date">
                                            <?php echo date('d M', strtotime($like['created_at'])); ?><br>
                                            <small><?php echo date('H:i', strtotime($like['created_at'])); ?></small>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <div class="no-activity">
                                <i class="fas fa-heart-broken"></i>
                                <h3>Belum ada likes</h3>
                                <p>User ini belum menyukai artikel apapun.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Delete confirmation
        function confirmDelete() {
            Swal.fire({
                title: 'Hapus User?',
                html: `User <strong>"<?php echo addslashes($user['username']); ?>"</strong> akan dihapus secara permanen.<br><br>
                      <small style="color: #f44336;">
                        <i class="fas fa-exclamation-triangle"></i> 
                        Semua data user termasuk komentar dan likes akan ikut terhapus!
                      </small>`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `delete_user.php?id=<?php echo $user_id; ?>`;
                }
            });
            return false;
        }
    </script>
</body>
</html>