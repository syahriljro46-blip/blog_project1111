<?php
session_start();
require_once '../config/database.php';

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Ambil data admin saat ini
$admin_id = $_SESSION['admin_id'];
$query = "SELECT * FROM admins WHERE id = $admin_id";
$result = mysqli_query($konek, $query);
$admin = mysqli_fetch_assoc($result);

// Variabel untuk pesan
$success_message = '';
$error_message = '';

// Proses form update profile
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $full_name = mysqli_real_escape_string($konek, $_POST['full_name']);
    $username = mysqli_real_escape_string($konek, $_POST['username']);
    $email = mysqli_real_escape_string($konek, $_POST['email']);
    
    // Cek jika username sudah digunakan oleh admin lain
    $username_check = "SELECT id FROM admins WHERE username = '$username' AND id != $admin_id";
    $username_result = mysqli_query($konek, $username_check);
    
    if (mysqli_num_rows($username_result) > 0) {
        $error_message = "Username sudah digunakan!";
    } else {
        // Cek jika email sudah digunakan oleh admin lain
        $email_check = "SELECT id FROM admins WHERE email = '$email' AND id != $admin_id";
        $email_result = mysqli_query($konek, $email_check);
        
        if (mysqli_num_rows($email_result) > 0) {
            $error_message = "Email sudah digunakan!";
        } else {
            // Update profile image jika ada
            $profile_image = $admin['profile_image'];
            
            if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
                $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
                $file_type = $_FILES['profile_image']['type'];
                
                if (in_array($file_type, $allowed_types)) {
                    $upload_dir = '../uploads/admin/';
                    
                    // Buat folder jika belum ada
                    if (!file_exists($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    
                    $file_name = time() . '_' . basename($_FILES['profile_image']['name']);
                    $file_path = $upload_dir . $file_name;
                    
                    if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $file_path)) {
                        // Hapus gambar lama jika ada
                        if ($profile_image && file_exists($upload_dir . $profile_image)) {
                            unlink($upload_dir . $profile_image);
                        }
                        $profile_image = $file_name;
                    }
                }
            }
            
            // Update data admin
            $update_query = "UPDATE admins SET 
                            full_name = '$full_name',
                            username = '$username',
                            email = '$email',
                            profile_image = '$profile_image',
                            updated_at = NOW()
                            WHERE id = $admin_id";
            
            if (mysqli_query($konek, $update_query)) {
                // Update session data
                $_SESSION['admin_username'] = $username;
                $_SESSION['admin_full_name'] = $full_name;
                
                // Refresh admin data
                $result = mysqli_query($konek, $query);
                $admin = mysqli_fetch_assoc($result);
                
                $success_message = "Profil berhasil diperbarui!";
            } else {
                $error_message = "Gagal memperbarui profil: " . mysqli_error($konek);
            }
        }
    }
}

// Proses form update password
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Verifikasi password saat ini
    if (password_verify($current_password, $admin['password'])) {
        if ($new_password === $confirm_password) {
            if (strlen($new_password) >= 6) {
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                
                $update_query = "UPDATE admins SET 
                                password = '$hashed_password',
                                updated_at = NOW()
                                WHERE id = $admin_id";
                
                if (mysqli_query($konek, $update_query)) {
                    $success_message = "Password berhasil diubah!";
                } else {
                    $error_message = "Gagal mengubah password: " . mysqli_error($konek);
                }
            } else {
                $error_message = "Password baru minimal 6 karakter!";
            }
        } else {
            $error_message = "Password baru dan konfirmasi tidak cocok!";
        }
    } else {
        $error_message = "Password saat ini salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Admin - Admin Blog</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #1a237e 0%, #283593 100%);
            color: white;
            padding: 20px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 3px 0 15px rgba(0,0,0,0.1);
        }

        .logo {
            text-align: center;
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 30px;
        }

        .logo h2 {
            font-size: 24px;
            color: white;
        }

        .logo span {
            color: #64b5f6;
        }

        .nav-menu {
            list-style: none;
            padding: 0 20px;
        }

        .nav-menu li {
            margin-bottom: 5px;
        }

        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            color: #b3c5e7;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .nav-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: white;
        }

        .nav-menu a.active {
            background: rgba(100, 181, 246, 0.2);
            color: #64b5f6;
            border-left: 4px solid #64b5f6;
        }

        .nav-menu i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .header h1 {
            color: #2c3e50;
            font-size: 28px;
        }

        .header h1 i {
            color: #64b5f6;
            margin-right: 10px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-info a {
            color: #7f8c8d;
            text-decoration: none;
            transition: color 0.3s;
        }

        .user-info a:hover {
            color: #3498db;
        }

        /* Profile Container */
        .profile-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }

        @media (max-width: 1024px) {
            .profile-container {
                grid-template-columns: 1fr;
            }
        }

        /* Profile Card */
        .profile-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }

        .profile-card h2 {
            color: #2c3e50;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .profile-card h2 i {
            color: #64b5f6;
        }

        /* Profile Info */
        .profile-info {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            margin-bottom: 30px;
        }

        .profile-image {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            overflow: hidden;
            margin-bottom: 20px;
            border: 5px solid #e3f2fd;
            position: relative;
        }

        .profile-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .profile-image-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0,0,0,0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity 0.3s;
            cursor: pointer;
        }

        .profile-image:hover .profile-image-overlay {
            opacity: 1;
        }

        .profile-image-overlay i {
            color: white;
            font-size: 24px;
        }

        .profile-name {
            font-size: 24px;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 5px;
        }

        .profile-username {
            color: #7f8c8d;
            margin-bottom: 15px;
        }

        .profile-stats {
            display: flex;
            gap: 30px;
            margin-top: 20px;
        }

        .profile-stat {
            text-align: center;
        }

        .stat-number {
            font-size: 24px;
            font-weight: 600;
            color: #2c3e50;
            display: block;
        }

        .stat-label {
            font-size: 12px;
            color: #7f8c8d;
            text-transform: uppercase;
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
        }

        .form-label.required:after {
            content: " *";
            color: #f44336;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: #2196f3;
            box-shadow: 0 0 0 3px rgba(33, 150, 243, 0.1);
        }

        .form-control[readonly] {
            background-color: #f5f7fa;
            cursor: not-allowed;
        }

        /* File Upload */
        .file-upload {
            border: 2px dashed #ddd;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 15px;
        }

        .file-upload:hover {
            border-color: #2196f3;
            background: #f8f9fa;
        }

        .file-upload i {
            font-size: 36px;
            color: #7f8c8d;
            margin-bottom: 10px;
        }

        .file-upload input {
            display: none;
        }

        .file-preview {
            margin-top: 15px;
            text-align: center;
        }

        .file-preview img {
            max-width: 150px;
            max-height: 150px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #e3f2fd;
        }

        /* Buttons */
        .form-actions {
            display: flex;
            gap: 15px;
            justify-content: flex-end;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
            transition: all 0.3s;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-primary {
            background: #2196f3;
            color: white;
        }

        .btn-primary:hover {
            background: #1976d2;
            transform: translateY(-2px);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #545b62;
        }

        .btn-danger {
            background: #f44336;
            color: white;
        }

        .btn-danger:hover {
            background: #d32f2f;
        }

        .btn-success {
            background: #4caf50;
            color: white;
        }

        .btn-success:hover {
            background: #388e3c;
        }

        /* Password Strength */
        .password-strength {
            margin-top: 10px;
        }

        .strength-bar {
            height: 5px;
            background: #eee;
            border-radius: 3px;
            overflow: hidden;
            margin-bottom: 5px;
        }

        .strength-fill {
            height: 100%;
            width: 0%;
            background: #f44336;
            transition: all 0.3s;
        }

        .strength-text {
            font-size: 12px;
            color: #7f8c8d;
        }

        /* Messages */
        .message {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .message-success {
            background: #e8f5e9;
            color: #2e7d32;
            border-left: 4px solid #4caf50;
        }

        .message-error {
            background: #ffebee;
            color: #c62828;
            border-left: 4px solid #f44336;
        }

        /* Info Box */
        .info-box {
            background: #e3f2fd;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #2196f3;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .sidebar {
                width: 70px;
            }
            
            .main-content {
                margin-left: 70px;
            }
            
            .logo h2 {
                font-size: 0;
            }
            
            .logo h2:after {
                content: "B";
                font-size: 24px;
            }
            
            .nav-menu a span {
                display: none;
            }
            
            .nav-menu a i {
                margin-right: 0;
                font-size: 20px;
            }
        }

        @media (max-width: 768px) {
            .form-actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
            
            .header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .profile-stats {
                flex-direction: column;
                gap: 15px;
            }
            
            .profile-image {
                width: 120px;
                height: 120px;
            }
        }

        /* Account Info */
        .account-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }

        @media (max-width: 768px) {
            .account-info {
                grid-template-columns: 1fr;
            }
        }

        .account-info-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            border-left: 4px solid #2196f3;
        }

        .account-info-label {
            font-size: 12px;
            color: #7f8c8d;
            text-transform: uppercase;
            margin-bottom: 5px;
        }

        .account-info-value {
            font-size: 16px;
            font-weight: 500;
            color: #2c3e50;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Blog<span>Admin</span></h2>
            </div>
            <ul class="nav-menu">
                <li><a href="dashboard.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="posts/list.php"><i class="fas fa-newspaper"></i> <span>Posts</span></a></li>
                <li><a href="categories/list.php"><i class="fas fa-folder"></i> <span>Kategori</span></a></li>
                <li><a href="tags/list.php"><i class="fas fa-tags"></i> <span>Tags</span></a></li>
                <li><a href="media/list.php"><i class="fas fa-image"></i> <span>Media</span></a></li>
                <li><a href="comments/list.php"><i class="fas fa-comments"></i> <span>Komentar</span></a></li>
                <li><a href="profile.php" class="active"><i class="fas fa-user"></i> <span>Profil</span></a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <h1><i class="fas fa-user"></i> Profil Admin</h1>
                <div class="user-info">
                    <span>Halo, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>

            <!-- Success Message -->
            <?php if(!empty($success_message)): ?>
                <div class="message message-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
                </div>
            <?php endif; ?>

            <!-- Error Message -->
            <?php if(!empty($error_message)): ?>
                <div class="message message-error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <!-- Profile Container -->
            <div class="profile-container">
                <!-- Left Column: Profile Info -->
                <div class="profile-card">
                    <h2><i class="fas fa-user-circle"></i> Informasi Profil</h2>
                    
                    <!-- Profile Image and Info -->
                    <div class="profile-info">
                        <div class="profile-image" onclick="document.getElementById('profileImageInput').click()">
                            <?php if(!empty($admin['profile_image'])): ?>
                                <img src="../uploads/admin/<?php echo htmlspecialchars($admin['profile_image']); ?>" 
                                     alt="Profile Image"
                                     id="profilePreview">
                            <?php else: ?>
                                <img src="https://ui-avatars.com/api/?name=<?php echo urlencode($admin['full_name']); ?>&background=2196f3&color=fff&size=150"
                                     alt="Profile Image"
                                     id="profilePreview">
                            <?php endif; ?>
                            <div class="profile-image-overlay">
                                <i class="fas fa-camera"></i>
                            </div>
                        </div>
                        
                        <div class="profile-name"><?php echo htmlspecialchars($admin['full_name']); ?></div>
                        <div class="profile-username">@<?php echo htmlspecialchars($admin['username']); ?></div>
                        
                        <div class="profile-stats">
                            <div class="profile-stat">
                                <?php
                                // Hitung jumlah artikel
                                $article_query = "SELECT COUNT(*) as count FROM articles WHERE author_id = $admin_id";
                                $article_result = mysqli_query($konek, $article_query);
                                $article_count = mysqli_fetch_assoc($article_result);
                                ?>
                                <span class="stat-number"><?php echo $article_count['count']; ?></span>
                                <span class="stat-label">Artikel</span>
                            </div>
                            <div class="profile-stat">
                                <span class="stat-number">#<?php echo $admin['id']; ?></span>
                                <span class="stat-label">ID Admin</span>
                            </div>
                        </div>
                    </div>

                    <!-- Account Information -->
                    <div class="account-info">
                        <div class="account-info-item">
                            <div class="account-info-label">Email</div>
                            <div class="account-info-value"><?php echo htmlspecialchars($admin['email']); ?></div>
                        </div>
                        <div class="account-info-item">
                            <div class="account-info-label">Tanggal Bergabung</div>
                            <div class="account-info-value"><?php echo date('d M Y', strtotime($admin['created_at'])); ?></div>
                        </div>
                        <div class="account-info-item">
                            <div class="account-info-label">Terakhir Update</div>
                            <div class="account-info-value"><?php echo date('d M Y H:i', strtotime($admin['updated_at'])); ?></div>
                        </div>
                        <div class="account-info-item">
                            <div class="account-info-label">Status</div>
                            <div class="account-info-value">Aktif</div>
                        </div>
                    </div>
                </div>

                <!-- Right Column: Edit Forms -->
                <div>
                    <!-- Edit Profile Form -->
                    <div class="profile-card" style="margin-bottom: 30px;">
                        <h2><i class="fas fa-edit"></i> Edit Profil</h2>
                        
                        <form action="" method="POST" enctype="multipart/form-data" id="profileForm">
                            <!-- Profile Image Upload -->
                            <div class="form-group">
                                <label class="form-label">Foto Profil</label>
                                <div class="file-upload" onclick="document.getElementById('profileImageInput').click()">
                                    <i class="fas fa-cloud-upload-alt"></i>
                                    <p>Klik untuk upload foto baru (Max: 2MB)</p>
                                    <p><small>Format: JPG, PNG, GIF, WebP</small></p>
                                    <input type="file" 
                                           id="profileImageInput" 
                                           name="profile_image" 
                                           accept="image/*"
                                           onchange="previewProfileImage(event)">
                                </div>
                                <div class="file-preview" id="imagePreviewContainer">
                                    <!-- Preview will be shown here -->
                                </div>
                            </div>

                            <!-- Full Name -->
                            <div class="form-group">
                                <label for="full_name" class="form-label">Nama Lengkap</label>
                                <input type="text" 
                                       id="full_name" 
                                       name="full_name" 
                                       class="form-control" 
                                       value="<?php echo htmlspecialchars($admin['full_name']); ?>"
                                       placeholder="Masukkan nama lengkap"
                                       maxlength="255">
                            </div>

                            <!-- Username -->
                            <div class="form-group">
                                <label for="username" class="form-label required">Username</label>
                                <input type="text" 
                                       id="username" 
                                       name="username" 
                                       class="form-control" 
                                       required 
                                       value="<?php echo htmlspecialchars($admin['username']); ?>"
                                       placeholder="Masukkan username"
                                       maxlength="100">
                            </div>

                            <!-- Email -->
                            <div class="form-group">
                                <label for="email" class="form-label required">Email</label>
                                <input type="email" 
                                       id="email" 
                                       name="email" 
                                       class="form-control" 
                                       required 
                                       value="<?php echo htmlspecialchars($admin['email']); ?>"
                                       placeholder="Masukkan email"
                                       maxlength="255">
                            </div>

                            <!-- Form Actions -->
                            <div class="form-actions">
                                <button type="submit" name="update_profile" class="btn btn-primary">
                                    <i class="fas fa-save"></i> Update Profil
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- Change Password Form -->
                    <div class="profile-card">
                        <h2><i class="fas fa-key"></i> Ganti Password</h2>
                        
                        <form action="" method="POST" id="passwordForm">
                            <!-- Current Password -->
                            <div class="form-group">
                                <label for="current_password" class="form-label required">Password Saat Ini</label>
                                <input type="password" 
                                       id="current_password" 
                                       name="current_password" 
                                       class="form-control" 
                                       required 
                                       placeholder="Masukkan password saat ini">
                            </div>

                            <!-- New Password -->
                            <div class="form-group">
                                <label for="new_password" class="form-label required">Password Baru</label>
                                <input type="password" 
                                       id="new_password" 
                                       name="new_password" 
                                       class="form-control" 
                                       required 
                                       placeholder="Masukkan password baru"
                                       minlength="6"
                                       oninput="checkPasswordStrength()">
                                <div class="password-strength">
                                    <div class="strength-bar">
                                        <div class="strength-fill" id="strengthFill"></div>
                                    </div>
                                    <div class="strength-text" id="strengthText">Kekuatan password</div>
                                </div>
                            </div>

                            <!-- Confirm Password -->
                            <div class="form-group">
                                <label for="confirm_password" class="form-label required">Konfirmasi Password</label>
                                <input type="password" 
                                       id="confirm_password" 
                                       name="confirm_password" 
                                       class="form-control" 
                                       required 
                                       placeholder="Konfirmasi password baru"
                                       minlength="6">
                                <div id="passwordMatch" style="font-size: 12px; margin-top: 5px;"></div>
                            </div>

                            <!-- Password Requirements -->
                            <div class="info-box">
                                <h4><i class="fas fa-info-circle"></i> Persyaratan Password</h4>
                                <ul style="margin-left: 20px; margin-top: 10px; font-size: 13px;">
                                    <li>Minimal 6 karakter</li>
                                    <li>Disarankan kombinasi huruf dan angka</li>
                                    <li>Disarankan menggunakan simbol (!@#$%^&*)</li>
                                    <li>Jangan gunakan password yang mudah ditebak</li>
                                </ul>
                            </div>

                            <!-- Form Actions -->
                            <div class="form-actions">
                                <button type="submit" name="update_password" class="btn btn-success">
                                    <i class="fas fa-key"></i> Ganti Password
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Profile image preview
        function previewProfileImage(event) {
            const input = event.target;
            const previewContainer = document.getElementById('imagePreviewContainer');
            const mainPreview = document.getElementById('profilePreview');
            
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    // Update main profile preview
                    mainPreview.src = e.target.result;
                    
                    // Show in preview container
                    previewContainer.innerHTML = `
                        <img src="${e.target.result}" alt="Preview">
                        <p style="margin-top: 10px; font-size: 12px; color: #7f8c8d;">
                            Preview foto baru
                        </p>
                    `;
                }
                
                reader.readAsDataURL(input.files[0]);
            }
        }

        // Password strength checker
        function checkPasswordStrength() {
            const password = document.getElementById('new_password').value;
            const strengthFill = document.getElementById('strengthFill');
            const strengthText = document.getElementById('strengthText');
            
            // Reset
            strengthFill.style.width = '0%';
            strengthFill.style.background = '#f44336';
            strengthText.textContent = 'Kekuatan password';
            strengthText.style.color = '#7f8c8d';
            
            if (password.length === 0) return;
            
            let strength = 0;
            
            // Length check
            if (password.length >= 6) strength += 25;
            if (password.length >= 8) strength += 25;
            
            // Character variety
            if (/[a-z]/.test(password)) strength += 10;
            if (/[A-Z]/.test(password)) strength += 10;
            if (/[0-9]/.test(password)) strength += 15;
            if (/[^A-Za-z0-9]/.test(password)) strength += 15;
            
            // Update strength bar
            strengthFill.style.width = strength + '%';
            
            // Update colors and text
            if (strength < 50) {
                strengthFill.style.background = '#f44336';
                strengthText.textContent = 'Lemah';
                strengthText.style.color = '#f44336';
            } else if (strength < 75) {
                strengthFill.style.background = '#ff9800';
                strengthText.textContent = 'Cukup';
                strengthText.style.color = '#ff9800';
            } else {
                strengthFill.style.background = '#4caf50';
                strengthText.textContent = 'Kuat';
                strengthText.style.color = '#4caf50';
            }
        }

        // Password confirmation check
        document.getElementById('confirm_password').addEventListener('input', function() {
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = this.value;
            const matchElement = document.getElementById('passwordMatch');
            
            if (confirmPassword.length === 0) {
                matchElement.textContent = '';
                matchElement.style.color = '#7f8c8d';
                return;
            }
            
            if (newPassword === confirmPassword) {
                matchElement.textContent = '✓ Password cocok';
                matchElement.style.color = '#4caf50';
            } else {
                matchElement.textContent = '✗ Password tidak cocok';
                matchElement.style.color = '#f44336';
            }
        });

        // Form validation for profile
        document.getElementById('profileForm').addEventListener('submit', function(e) {
            const username = document.getElementById('username').value.trim();
            const email = document.getElementById('email').value.trim();
            const fullName = document.getElementById('full_name').value.trim();
            
            if (!username) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Username Kosong',
                    text: 'Silakan masukkan username!'
                });
                return false;
            }
            
            if (!email) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Email Kosong',
                    text: 'Silakan masukkan email!'
                });
                return false;
            }
            
            // Validate email format
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Format Email Tidak Valid',
                    text: 'Silakan masukkan format email yang valid!'
                });
                return false;
            }
            
            // Check if username changed
            const originalUsername = '<?php echo $admin['username']; ?>';
            if (username !== originalUsername) {
                Swal.fire({
                    title: 'Update Profil',
                    html: `Username akan diubah dari <strong>${originalUsername}</strong> menjadi <strong>${username}</strong>`,
                    icon: 'info',
                    showCancelButton: true,
                    confirmButtonText: 'Ya, Update',
                    cancelButtonText: 'Batal'
                }).then((result) => {
                    if (!result.isConfirmed) {
                        e.preventDefault();
                    }
                });
            }
        });

        // Form validation for password
        document.getElementById('passwordForm').addEventListener('submit', function(e) {
            const currentPassword = document.getElementById('current_password').value;
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (!currentPassword) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Password Saat Ini Kosong',
                    text: 'Silakan masukkan password saat ini!'
                });
                return false;
            }
            
            if (newPassword.length < 6) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Password Terlalu Pendek',
                    text: 'Password baru minimal 6 karakter!'
                });
                return false;
            }
            
            if (newPassword !== confirmPassword) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Password Tidak Cocok',
                    text: 'Password baru dan konfirmasi tidak cocok!'
                });
                return false;
            }
            
            // Show confirmation
            Swal.fire({
                title: 'Ganti Password?',
                text: 'Anda yakin ingin mengganti password?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#4caf50',
                cancelButtonColor: '#6c757d',
                confirmButtonText: 'Ya, Ganti',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (!result.isConfirmed) {
                    e.preventDefault();
                } else {
                    // Show loading
                    Swal.fire({
                        title: 'Mengganti Password...',
                        allowOutsideClick: false,
                        showConfirmButton: false,
                        willOpen: () => {
                            Swal.showLoading();
                        }
                    });
                }
            });
        });

        // Initialize password strength check
        window.addEventListener('load', function() {
            checkPasswordStrength();
            
            // Set up real-time validation
            document.getElementById('new_password').addEventListener('input', function() {
                checkPasswordStrength();
                document.getElementById('confirm_password').dispatchEvent(new Event('input'));
            });
        });

        // Show password toggle (optional feature)
        function togglePasswordVisibility(inputId) {
            const input = document.getElementById(inputId);
            const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
            input.setAttribute('type', type);
        }
    </script>
</body>
</html>