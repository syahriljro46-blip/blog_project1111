<?php
session_start();
require_once '../../config/database.php';

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

// Warna default untuk tag
$default_colors = [
    '#4f5b93', '#f0db4f', '#ff2d20', '#61dafb', '#264de4',
    '#e34c26', '#00758f', '#7952b3', '#28a745', '#17a2b8',
    '#dc3545', '#fd7e14', '#6f42c1', '#20c997', '#e83e8c'
];

// Proses form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari form
    $name = mysqli_real_escape_string($konek, $_POST['name']);
    $description = mysqli_real_escape_string($konek, $_POST['description']);
    $color = mysqli_real_escape_string($konek, $_POST['color']);
    
    // Generate slug dari name
    $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
    
    // Cek jika slug sudah ada
    $slug_check_query = "SELECT COUNT(*) as count FROM tags WHERE slug LIKE '$slug%'";
    $slug_check_result = mysqli_query($konek, $slug_check_query);
    $slug_check = mysqli_fetch_assoc($slug_check_result);
    
    if ($slug_check['count'] > 0) {
        $slug = $slug . '-' . time();
    }
    
    // Insert ke database
    $query = "INSERT INTO tags (name, slug, description, color) 
              VALUES ('$name', '$slug', '$description', '$color')";
    
    if (mysqli_query($konek, $query)) {
        $tag_id = mysqli_insert_id($konek);
        
        // Log aktivitas
        $log_query = "INSERT INTO admin_logs (admin_id, action, details, created_at) 
                      VALUES ({$_SESSION['admin_id']}, 'create_tag', 'Membuat tag: $name', NOW())";
        mysqli_query($konek, $log_query);
        
        header("Location: list.php?success=created");
        exit();
    } else {
        $error = "Gagal menyimpan tag: " . mysqli_error($konek);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buat Tag Baru - Admin Blog</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #1a237e 0%, #283593 100%);
            color: white;
            padding: 20px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 3px 0 15px rgba(0,0,0,0.1);
        }

        .logo {
            text-align: center;
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 30px;
        }

        .logo h2 {
            font-size: 24px;
            color: white;
        }

        .logo span {
            color: #64b5f6;
        }

        .nav-menu {
            list-style: none;
            padding: 0 20px;
        }

        .nav-menu li {
            margin-bottom: 5px;
        }

        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            color: #b3c5e7;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .nav-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: white;
        }

        .nav-menu a.active {
            background: rgba(100, 181, 246, 0.2);
            color: #64b5f6;
            border-left: 4px solid #64b5f6;
        }

        .nav-menu i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .header h1 {
            color: #2c3e50;
            font-size: 28px;
        }

        .header h1 i {
            color: #64b5f6;
            margin-right: 10px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-info a {
            color: #7f8c8d;
            text-decoration: none;
            transition: color 0.3s;
        }

        .user-info a:hover {
            color: #3498db;
        }

        /* Form Container */
        .form-container {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
        }

        .form-label.required:after {
            content: " *";
            color: #f44336;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }

        .form-control:focus {
            outline: none;
            border-color: #2196f3;
            box-shadow: 0 0 0 3px rgba(33, 150, 243, 0.1);
        }

        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }

        /* Color Picker */
        .color-picker {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 10px;
        }

        .color-option {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
            border: 3px solid transparent;
        }

        .color-option:hover {
            transform: scale(1.1);
        }

        .color-option.selected {
            border-color: #333;
            box-shadow: 0 0 0 2px #fff, 0 0 0 4px #333;
        }

        /* Color Input */
        .color-input-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .color-input-group input[type="color"] {
            width: 50px;
            height: 50px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        .color-input-group input[type="text"] {
            flex: 1;
        }

        /* Buttons */
        .form-actions {
            display: flex;
            gap: 15px;
            justify-content: flex-end;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
            transition: all 0.3s;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-primary {
            background: #2196f3;
            color: white;
        }

        .btn-primary:hover {
            background: #1976d2;
            transform: translateY(-2px);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #545b62;
        }

        /* Character Counter */
        .char-counter {
            text-align: right;
            font-size: 12px;
            color: #7f8c8d;
            margin-top: 5px;
        }

        /* Slug Preview */
        .slug-preview {
            background: #f8f9fa;
            padding: 10px 15px;
            border-radius: 6px;
            margin-top: 10px;
            font-size: 14px;
            color: #495057;
            border: 1px solid #ddd;
        }

        .slug-preview span {
            color: #2196f3;
            font-weight: 500;
        }

        /* Tag Preview */
        .tag-preview {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            border-radius: 20px;
            margin-top: 10px;
            font-weight: 500;
        }

        /* Error Message */
        .error-message {
            background: #ffebee;
            color: #c62828;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #f44336;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .sidebar {
                width: 70px;
            }
            
            .main-content {
                margin-left: 70px;
            }
            
            .logo h2 {
                font-size: 0;
            }
            
            .logo h2:after {
                content: "B";
                font-size: 24px;
            }
            
            .nav-menu a span {
                display: none;
            }
            
            .nav-menu a i {
                margin-right: 0;
                font-size: 20px;
            }
        }

        @media (max-width: 768px) {
            .form-actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                justify-content: center;
            }
            
            .header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .color-input-group {
                flex-direction: column;
                align-items: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Blog<span>Admin</span></h2>
            </div>
            <ul class="nav-menu">
                <li><a href="../dashboard.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="../posts/list.php"><i class="fas fa-newspaper"></i> <span>Posts</span></a></li>
                <li><a href="../categories/list.php"><i class="fas fa-folder"></i> <span>Kategori</span></a></li>
                <li><a href="create.php" class="active"><i class="fas fa-plus-circle"></i> <span>Buat Tag</span></a></li>
                <li><a href="../media/list.php"><i class="fas fa-image"></i> <span>Media</span></a></li>
                <li><a href="../comments/list.php"><i class="fas fa-comments"></i> <span>Komentar</span></a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <h1><i class="fas fa-plus-circle"></i> Buat Tag Baru</h1>
                <div class="user-info">
                    <span>Halo, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>

            <!-- Error Message -->
            <?php if(isset($error)): ?>
                <div class="error-message">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <!-- Form Container -->
            <div class="form-container">
                <form action="" method="POST" id="tagForm">
                    <!-- Nama Tag -->
                    <div class="form-group">
                        <label for="name" class="form-label required">Nama Tag</label>
                        <input type="text" 
                               id="name" 
                               name="name" 
                               class="form-control" 
                               required 
                               placeholder="Masukkan nama tag..."
                               maxlength="100"
                               oninput="generateSlug()">
                        <div class="char-counter">
                            <span id="nameCounter">0</span>/100 karakter
                        </div>
                    </div>

                    <!-- Slug Preview -->
                    <div class="form-group">
                        <label class="form-label">Slug (URL)</label>
                        <div class="slug-preview" id="slugPreview">
                            https://blog.com/tag/<span id="slugValue">nama-tag</span>
                        </div>
                    </div>

                    <!-- Deskripsi -->
                    <div class="form-group">
                        <label for="description" class="form-label">Deskripsi</label>
                        <textarea id="description" 
                                  name="description" 
                                  class="form-control" 
                                  placeholder="Deskripsi singkat tentang tag ini..."
                                  maxlength="500"
                                  oninput="updateDescriptionCounter()"></textarea>
                        <div class="char-counter">
                            <span id="descriptionCounter">0</span>/500 karakter
                        </div>
                    </div>

                    <!-- Warna -->
                    <div class="form-group">
                        <label for="color" class="form-label required">Warna Tag</label>
                        
                        <!-- Pilihan Warna Cepat -->
                        <div class="color-picker">
                            <?php foreach($default_colors as $color): ?>
                                <div class="color-option" 
                                     style="background-color: <?php echo $color; ?>"
                                     data-color="<?php echo $color; ?>"
                                     onclick="selectColor('<?php echo $color; ?>')"></div>
                            <?php endforeach; ?>
                        </div>

                        <!-- Input Warna Custom -->
                        <div class="color-input-group" style="margin-top: 15px;">
                            <input type="color" 
                                   id="colorPicker" 
                                   name="color" 
                                   value="#6c757d"
                                   onchange="updateColorInput(this.value)">
                            <input type="text" 
                                   id="colorInput" 
                                   name="color" 
                                   class="form-control" 
                                   value="#6c757d"
                                   placeholder="#6c757d"
                                   maxlength="7"
                                   pattern="^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$"
                                   oninput="updateColorPreview(this.value)">
                        </div>
                        
                        <!-- Preview Tag -->
                        <div id="tagPreview" class="tag-preview" style="background-color: #6c757d; color: white;">
                            <span id="tagPreviewText">Tag Preview</span>
                        </div>
                    </div>

                    <!-- Form Actions -->
                    <div class="form-actions">
                        <a href="list.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Batal
                        </a>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Simpan Tag
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Nama character counter
        const nameInput = document.getElementById('name');
        const nameCounter = document.getElementById('nameCounter');
        
        nameInput.addEventListener('input', function() {
            nameCounter.textContent = this.value.length;
            updateTagPreview();
        });

        // Deskripsi character counter
        const descriptionInput = document.getElementById('description');
        const descriptionCounter = document.getElementById('descriptionCounter');
        
        function updateDescriptionCounter() {
            descriptionCounter.textContent = descriptionInput.value.length;
        }
        descriptionInput.addEventListener('input', updateDescriptionCounter);

        // Generate slug from name
        function generateSlug() {
            const name = document.getElementById('name').value;
            let slug = name
                .toLowerCase()
                .replace(/[^a-z0-9\s-]/g, '')
                .replace(/\s+/g, '-')
                .replace(/-+/g, '-')
                .trim();
            
            if (!slug) {
                slug = 'tag-' + Date.now();
            }
            
            document.getElementById('slugValue').textContent = slug;
            updateTagPreview();
        }

        // Color selection
        function selectColor(color) {
            document.getElementById('colorInput').value = color;
            document.getElementById('colorPicker').value = color;
            updateColorPreview(color);
            
            // Update selected state
            document.querySelectorAll('.color-option').forEach(option => {
                option.classList.remove('selected');
            });
            event.target.classList.add('selected');
        }

        // Update color input from color picker
        function updateColorInput(color) {
            document.getElementById('colorInput').value = color;
            updateColorPreview(color);
        }

        // Update color preview
        function updateColorPreview(color) {
            const tagPreview = document.getElementById('tagPreview');
            tagPreview.style.backgroundColor = color;
            
            // Determine text color based on background brightness
            const hex = color.replace('#', '');
            const r = parseInt(hex.substr(0, 2), 16);
            const g = parseInt(hex.substr(2, 2), 16);
            const b = parseInt(hex.substr(4, 2), 16);
            const brightness = (r * 299 + g * 587 + b * 114) / 1000;
            
            tagPreview.style.color = brightness > 128 ? '#333' : 'white';
            
            // Update color picker to match
            document.getElementById('colorPicker').value = color;
            
            // Update selected state in color options
            document.querySelectorAll('.color-option').forEach(option => {
                option.classList.remove('selected');
                if (option.dataset.color === color) {
                    option.classList.add('selected');
                }
            });
        }

        // Update tag preview
        function updateTagPreview() {
            const name = document.getElementById('name').value || 'Tag Preview';
            document.getElementById('tagPreviewText').textContent = name;
        }

        // Form validation
        document.getElementById('tagForm').addEventListener('submit', function(e) {
            const name = document.getElementById('name').value.trim();
            const color = document.getElementById('colorInput').value;
            
            if (!name) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Nama Tag Kosong',
                    text: 'Silakan masukkan nama tag!'
                });
                return false;
            }
            
            // Validate color format
            const colorRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/;
            if (!colorRegex.test(color)) {
                e.preventDefault();
                Swal.fire({
                    icon: 'error',
                    title: 'Format Warna Tidak Valid',
                    text: 'Silakan masukkan format warna HEX yang valid (contoh: #FF0000 atau #F00)'
                });
                return false;
            }
            
            // Show loading
            Swal.fire({
                title: 'Menyimpan Tag...',
                allowOutsideClick: false,
                showConfirmButton: false,
                willOpen: () => {
                    Swal.showLoading();
                }
            });
        });

        // Initialize color options
        window.addEventListener('load', function() {
            // Select first color option by default
            const firstColor = document.querySelector('.color-option');
            if (firstColor) {
                firstColor.classList.add('selected');
            }
            
            // Initialize counters
            nameCounter.textContent = nameInput.value.length;
            descriptionCounter.textContent = descriptionInput.value.length;
        });
    </script>
</body>
</html>