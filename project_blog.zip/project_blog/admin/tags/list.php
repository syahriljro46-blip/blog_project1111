<?php
session_start();
require_once '../../config/database.php';

// Cek apakah admin sudah login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

// Query untuk mendapatkan semua tags dengan jumlah artikel
$query = "SELECT 
            t.*,
            COUNT(at.article_id) as article_count
          FROM tags t
          LEFT JOIN article_tags at ON t.id = at.tag_id
          GROUP BY t.id
          ORDER BY t.created_at DESC";
$result = mysqli_query($konek, $query);

// Hitung total tags
$total_query = "SELECT COUNT(*) as total FROM tags";
$total_result = mysqli_query($konek, $total_query);
$total_data = mysqli_fetch_assoc($total_result);
$total_tags = $total_data['total'];

// Pesan sukses dan error
$success_message = '';
$error_message = '';

if(isset($_GET['success'])) {
    if($_GET['success'] == 'created') {
        $success_message = "Tag berhasil dibuat!";
    } elseif($_GET['success'] == 'updated') {
        $success_message = "Tag berhasil diupdate!";
    } elseif($_GET['success'] == 'deleted') {
        $success_message = "Tag berhasil dihapus!";
    }
}

if(isset($_GET['error'])) {
    if($_GET['error'] == 'delete_failed') {
        $error_message = "Gagal menghapus tag!";
    } elseif($_GET['error'] == 'not_found') {
        $error_message = "Tag tidak ditemukan!";
    } elseif($_GET['error'] == 'invalid_id') {
        $error_message = "ID tag tidak valid!";
    } else {
        $error_message = "Terjadi kesalahan!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Tags - Admin Blog</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
        }

        .container {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, #1a237e 0%, #283593 100%);
            color: white;
            padding: 20px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 3px 0 15px rgba(0,0,0,0.1);
        }

        .logo {
            text-align: center;
            padding: 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 30px;
        }

        .logo h2 {
            font-size: 24px;
            color: white;
        }

        .logo span {
            color: #64b5f6;
        }

        .nav-menu {
            list-style: none;
            padding: 0 20px;
        }

        .nav-menu li {
            margin-bottom: 5px;
        }

        .nav-menu a {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            color: #b3c5e7;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }

        .nav-menu a:hover {
            background: rgba(255,255,255,0.1);
            color: white;
        }

        .nav-menu a.active {
            background: rgba(100, 181, 246, 0.2);
            color: #64b5f6;
            border-left: 4px solid #64b5f6;
        }

        .nav-menu i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }

        /* Header */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .header h1 {
            color: #2c3e50;
            font-size: 28px;
        }

        .header h1 i {
            color: #64b5f6;
            margin-right: 10px;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-info a {
            color: #7f8c8d;
            text-decoration: none;
            transition: color 0.3s;
        }

        .user-info a:hover {
            color: #3498db;
        }

        /* Stats Cards */
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            transition: transform 0.3s;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 20px;
            font-size: 24px;
        }

        .stat-icon.total {
            background: #e3f2fd;
            color: #1976d2;
        }

        .stat-icon.popular {
            background: #f3e5f5;
            color: #7b1fa2;
        }

        .stat-icon.recent {
            background: #e8f5e9;
            color: #388e3c;
        }

        .stat-info h3 {
            font-size: 14px;
            color: #7f8c8d;
            margin-bottom: 5px;
        }

        .stat-info .number {
            font-size: 28px;
            font-weight: bold;
            color: #2c3e50;
        }

        /* Tags Table */
        .tags-table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }

        .table-header {
            padding: 20px;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .table-header h2 {
            color: #2c3e50;
        }

        .actions {
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
            transition: all 0.3s;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-primary {
            background: #2196f3;
            color: white;
        }

        .btn-primary:hover {
            background: #1976d2;
            transform: translateY(-2px);
        }

        .btn-success {
            background: #4caf50;
            color: white;
        }

        .btn-success:hover {
            background: #388e3c;
        }

        .btn-danger {
            background: #f44336;
            color: white;
        }

        .btn-danger:hover {
            background: #d32f2f;
        }

        .btn-warning {
            background: #ff9800;
            color: white;
        }

        .btn-warning:hover {
            background: #f57c00;
        }

        .btn-info {
            background: #17a2b8;
            color: white;
        }

        .btn-info:hover {
            background: #138496;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead {
            background: #f8f9fa;
        }

        th {
            padding: 15px;
            text-align: left;
            color: #2c3e50;
            font-weight: 600;
            border-bottom: 2px solid #eee;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #eee;
            vertical-align: middle;
        }

        tr:hover {
            background: #f9f9f9;
        }

        .tag-name {
            font-weight: 500;
            color: #2c3e50;
            display: block;
            margin-bottom: 5px;
        }

        .tag-meta {
            font-size: 12px;
            color: #7f8c8d;
        }

        .tag-meta i {
            margin-right: 5px;
        }

        .badge {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
            display: inline-block;
        }

        .badge-count {
            background: #e3f2fd;
            color: #1976d2;
        }

        .tag-color {
            width: 20px;
            height: 20px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 10px;
            vertical-align: middle;
            border: 2px solid #fff;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .actions-cell {
            display: flex;
            gap: 8px;
        }

        .btn-small {
            padding: 6px 12px;
            font-size: 12px;
            border-radius: 6px;
        }

        .btn-icon {
            width: 32px;
            height: 32px;
            padding: 0;
            justify-content: center;
            border-radius: 50%;
        }

        .stats-cell {
            text-align: center;
        }

        .stat-number {
            font-size: 18px;
            font-weight: bold;
            color: #2c3e50;
            display: block;
        }

        .stat-label {
            font-size: 11px;
            color: #7f8c8d;
            text-transform: uppercase;
        }

        /* Search and Filter */
        .search-filter {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            align-items: center;
        }

        .search-box {
            flex: 1;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 12px 20px 12px 45px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s;
        }

        .search-box input:focus {
            outline: none;
            border-color: #2196f3;
            box-shadow: 0 0 0 3px rgba(33, 150, 243, 0.1);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #7f8c8d;
        }

        .filter-select {
            padding: 12px 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background: white;
            font-size: 14px;
            color: #333;
            min-width: 150px;
        }

        /* No Tags */
        .no-tags {
            text-align: center;
            padding: 50px;
            color: #7f8c8d;
        }

        .no-tags i {
            font-size: 48px;
            margin-bottom: 20px;
            color: #bdc3c7;
        }

        /* Tag Cloud */
        .tag-cloud {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 30px;
        }

        .tag-cloud-item {
            background: white;
            padding: 12px 20px;
            border-radius: 25px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            text-decoration: none;
            color: #333;
        }

        .tag-cloud-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }

        .tag-cloud-count {
            background: #e3f2fd;
            color: #1976d2;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 12px;
            font-weight: 500;
        }

        /* Responsive */
        @media (max-width: 1024px) {
            .sidebar {
                width: 70px;
            }
            
            .main-content {
                margin-left: 70px;
            }
            
            .logo h2 {
                font-size: 0;
            }
            
            .logo h2:after {
                content: "B";
                font-size: 24px;
            }
            
            .nav-menu a span {
                display: none;
            }
            
            .nav-menu a i {
                margin-right: 0;
                font-size: 20px;
            }
        }

        @media (max-width: 768px) {
            .stats-cards {
                grid-template-columns: 1fr;
            }
            
            table {
                display: block;
                overflow-x: auto;
            }
            
            .header {
                flex-direction: column;
                gap: 15px;
                text-align: center;
            }
            
            .search-filter {
                flex-direction: column;
            }
            
            .actions-cell {
                flex-wrap: wrap;
                justify-content: center;
            }
            
            .btn-small {
                padding: 4px 8px;
                font-size: 11px;
            }
            
            .tag-cloud {
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Blog<span>Admin</span></h2>
            </div>
            <ul class="nav-menu">
                <li><a href="../dashboard.php"><i class="fas fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="../posts/list.php"><i class="fas fa-newspaper"></i> <span>Posts</span></a></li>
                <li><a href="../categories/list.php"><i class="fas fa-folder"></i> <span>Kategori</span></a></li>
                <li><a href="list.php" class="active"><i class="fas fa-tags"></i> <span>Tags</span></a></li>
                <li><a href="../media/list.php"><i class="fas fa-image"></i> <span>Media</span></a></li>
                <li><a href="../comments/list.php"><i class="fas fa-comments"></i> <span>Komentar</span></a></li>
                <li><a href="../logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Header -->
            <div class="header">
                <h1><i class="fas fa-tags"></i> Manajemen Tags</h1>
                <div class="user-info">
                    <span>Halo, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
                    <a href="../logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                </div>
            </div>

            <!-- Stats Cards -->
            <div class="stats-cards">
                <div class="stat-card">
                    <div class="stat-icon total">
                        <i class="fas fa-tags"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Total Tags</h3>
                        <div class="number"><?php echo $total_tags; ?></div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon popular">
                        <i class="fas fa-fire"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Tag Paling Populer</h3>
                        <div class="number">
                            <?php
                            $popular_query = "SELECT name FROM tags ORDER BY post_count DESC LIMIT 1";
                            $popular_result = mysqli_query($konek, $popular_query);
                            if($popular = mysqli_fetch_assoc($popular_result)) {
                                echo htmlspecialchars($popular['name']);
                            } else {
                                echo "-";
                            }
                            ?>
                        </div>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon recent">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-info">
                        <h3>Tag Terbaru</h3>
                        <div class="number">
                            <?php
                            $recent_query = "SELECT name FROM tags ORDER BY created_at DESC LIMIT 1";
                            $recent_result = mysqli_query($konek, $recent_query);
                            if($recent = mysqli_fetch_assoc($recent_result)) {
                                echo htmlspecialchars($recent['name']);
                            } else {
                                echo "-";
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tag Cloud -->
            <div class="tag-cloud">
                <?php
                mysqli_data_seek($result, 0); // Reset pointer
                while($tag = mysqli_fetch_assoc($result)): 
                ?>
                    <a href="?filter=<?php echo $tag['id']; ?>" class="tag-cloud-item">
                        <span class="tag-color" style="background-color: <?php echo $tag['color']; ?>"></span>
                        <span><?php echo htmlspecialchars($tag['name']); ?></span>
                        <span class="tag-cloud-count"><?php echo $tag['article_count']; ?></span>
                    </a>
                <?php endwhile; ?>
            </div>

            <!-- Search and Filter -->
            <div class="search-filter">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" id="searchInput" placeholder="Cari tags...">
                </div>
                <select class="filter-select" id="sortFilter">
                    <option value="name">Sort by Name</option>
                    <option value="popular">Sort by Popularity</option>
                    <option value="recent">Sort by Recent</option>
                </select>
                <a href="create.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Tag Baru
                </a>
            </div>

            <!-- Tags Table -->
            <div class="tags-table">
                <div class="table-header">
                    <h2>Daftar Tags</h2>
                    <div class="actions">
                        <button class="btn btn-info" onclick="exportTags()">
                            <i class="fas fa-download"></i> Export
                        </button>
                    </div>
                </div>

                <?php if(mysqli_num_rows($result) > 0): ?>
                    <table id="tagsTable">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tag</th>
                                <th>Slug</th>
                                <th>Deskripsi</th>
                                <th>Artikel</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            mysqli_data_seek($result, 0); // Reset pointer lagi
                            while($tag = mysqli_fetch_assoc($result)): 
                            ?>
                                <tr>
                                    <td>#<?php echo $tag['id']; ?></td>
                                    <td>
                                        <span class="tag-name">
                                            <span class="tag-color" style="background-color: <?php echo $tag['color']; ?>"></span>
                                            <?php echo htmlspecialchars($tag['name']); ?>
                                        </span>
                                        <div class="tag-meta">
                                            <i class="fas fa-hashtag"></i> <?php echo htmlspecialchars($tag['slug']); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <code><?php echo htmlspecialchars($tag['slug']); ?></code>
                                    </td>
                                    <td>
                                        <?php echo !empty($tag['description']) ? htmlspecialchars(substr($tag['description'], 0, 100)) . '...' : '<span style="color:#7f8c8d; font-style:italic;">Tidak ada deskripsi</span>'; ?>
                                    </td>
                                    <td class="stats-cell">
                                        <span class="stat-number"><?php echo $tag['article_count']; ?></span>
                                        <span class="stat-label">Artikel</span>
                                    </td>
                                    <td>
                                        <?php echo date('d M Y', strtotime($tag['created_at'])); ?><br>
                                        <small><?php echo date('H:i', strtotime($tag['created_at'])); ?></small>
                                    </td>
                                    <td class="actions-cell">
                                        <a href="edit.php?id=<?php echo $tag['id']; ?>" 
                                           class="btn btn-warning btn-small"
                                           title="Edit Tag">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="delete.php?id=<?php echo $tag['id']; ?>" 
                                           class="btn btn-danger btn-small"
                                           onclick="return confirmDelete(<?php echo $tag['id']; ?>, '<?php echo addslashes($tag['name']); ?>')"
                                           title="Hapus Tag">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                        <a href="../../tag.php?slug=<?php echo $tag['slug']; ?>" 
                                           target="_blank" 
                                           class="btn btn-primary btn-small"
                                           title="View Tag">
                                            <i class="fas fa-external-link-alt"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="no-tags">
                        <i class="fas fa-tags"></i>
                        <h3>Belum ada tags</h3>
                        <p>Tidak ada tags yang ditemukan. <a href="create.php">Buat tag pertama</a></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            const filter = this.value.toLowerCase();
            const rows = document.querySelectorAll('#tagsTable tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });

        // Sort functionality
        document.getElementById('sortFilter').addEventListener('change', function() {
            const sortBy = this.value;
            const rows = Array.from(document.querySelectorAll('#tagsTable tbody tr'));
            
            rows.sort((a, b) => {
                if (sortBy === 'name') {
                    const nameA = a.cells[1].textContent.toLowerCase();
                    const nameB = b.cells[1].textContent.toLowerCase();
                    return nameA.localeCompare(nameB);
                } else if (sortBy === 'popular') {
                    const countA = parseInt(a.cells[4].querySelector('.stat-number').textContent);
                    const countB = parseInt(b.cells[4].querySelector('.stat-number').textContent);
                    return countB - countA;
                } else if (sortBy === 'recent') {
                    const dateA = new Date(a.cells[5].textContent);
                    const dateB = new Date(b.cells[5].textContent);
                    return dateB - dateA;
                }
                return 0;
            });
            
            const tbody = document.querySelector('#tagsTable tbody');
            tbody.innerHTML = '';
            rows.forEach(row => tbody.appendChild(row));
        });

        // Delete confirmation
        function confirmDelete(id, name) {
            Swal.fire({
                title: 'Hapus Tag?',
                html: `Tag <strong>"${name}"</strong> akan dihapus secara permanen.`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Batal'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = `delete.php?id=${id}`;
                }
            });
            return false;
        }

        // Export function
        function exportTags() {
            Swal.fire({
                title: 'Export Tags',
                text: 'Pilih format export:',
                icon: 'info',
                showCancelButton: true,
                confirmButtonText: 'CSV',
                cancelButtonText: 'JSON',
                showDenyButton: true,
                denyButtonText: 'PDF'
            }).then((result) => {
                if (result.isConfirmed) {
                    window.location.href = 'export.php?format=csv';
                } else if (result.dismiss === Swal.DismissReason.cancel) {
                    window.location.href = 'export.php?format=json';
                } else if (result.isDenied) {
                    window.location.href = 'export.php?format=pdf';
                }
            });
        }

        // Show success messages
        <?php if(!empty($success_message)): ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil!',
                text: '<?php echo addslashes($success_message); ?>',
                timer: 3000,
                showConfirmButton: false
            });
        <?php endif; ?>

        <?php if(!empty($error_message)): ?>
            Swal.fire({
                icon: 'error',
                title: 'Error!',
                text: '<?php echo addslashes($error_message); ?>'
            });
        <?php endif; ?>
    </script>
</body>
</html>