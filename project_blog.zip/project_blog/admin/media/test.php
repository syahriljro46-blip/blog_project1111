<?php
session_start();
require_once '../../config/database.php';

// Cek jika belum login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];
$test_results = [];
$error = '';

// Test upload directory
$upload_dir = '../../uploads/';

// Run tests
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Test 1: Directory existence and permissions
    if (!is_dir($upload_dir)) {
        $test_results[] = [
            'name' => 'Directory Existence',
            'status' => 'error',
            'message' => 'Uploads directory tidak ditemukan'
        ];
    } else {
        $test_results[] = [
            'name' => 'Directory Existence',
            'status' => 'success',
            'message' => 'Directory ditemukan: ' . realpath($upload_dir)
        ];
    }
    
    // Test 2: Directory permissions
    if (is_dir($upload_dir)) {
        if (is_writable($upload_dir)) {
            $test_results[] = [
                'name' => 'Directory Permissions',
                'status' => 'success',
                'message' => 'Directory writable (0755 atau lebih tinggi)'
            ];
        } else {
            $test_results[] = [
                'name' => 'Directory Permissions',
                'status' => 'error',
                'message' => 'Directory tidak writable. Set permissions ke 0755'
            ];
        }
    }
    
    // Test 3: PHP file upload settings
    $upload_max_filesize = ini_get('upload_max_filesize');
    $post_max_size = ini_get('post_max_size');
    $max_file_uploads = ini_get('max_file_uploads');
    
    $test_results[] = [
        'name' => 'PHP Upload Settings',
        'status' => 'info',
        'message' => "upload_max_filesize: $upload_max_filesize, post_max_size: $post_max_size, max_file_uploads: $max_file_uploads"
    ];
    
    // Test 4: Test file upload (simulate)
    $test_file_path = $upload_dir . 'test_' . time() . '.txt';
    $test_content = 'Test file created by media system at ' . date('Y-m-d H:i:s');
    
    if (file_put_contents($test_file_path, $test_content)) {
        $test_results[] = [
            'name' => 'File Creation Test',
            'status' => 'success',
            'message' => 'Berhasil membuat test file: ' . basename($test_file_path)
        ];
        
        // Clean up test file
        unlink($test_file_path);
    } else {
        $test_results[] = [
            'name' => 'File Creation Test',
            'status' => 'error',
            'message' => 'Gagal membuat test file. Cek permissions.'
        ];
    }
    
    // Test 5: Check existing files count
    if (is_dir($upload_dir)) {
        $files = scandir($upload_dir);
        $file_count = count(array_filter($files, function($file) use ($upload_dir) {
            return $file !== '.' && $file !== '..' && !is_dir($upload_dir . $file);
        }));
        
        $test_results[] = [
            'name' => 'Existing Files',
            'status' => 'info',
            'message' => "Found $file_count files in uploads directory"
        ];
    }
    
    // Test 6: Check disk space
    if (is_dir($upload_dir)) {
        $disk_free_space = disk_free_space($upload_dir);
        $disk_total_space = disk_total_space($upload_dir);
        $free_percent = round(($disk_free_space / $disk_total_space) * 100, 2);
        
        $test_results[] = [
            'name' => 'Disk Space',
            'status' => $free_percent < 10 ? 'warning' : 'success',
            'message' => "Free space: " . formatFileSize($disk_free_space) . 
                        " (" . $free_percent . "% free of " . formatFileSize($disk_total_space) . ")"
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test Media System - Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            color: #333;
        }
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            height: 100vh;
        }
        .logo {
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }
        .logo h2 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        .logo p {
            font-size: 12px;
            opacity: 0.8;
        }
        .nav-menu {
            list-style: none;
        }
        .nav-item {
            margin-bottom: 5px;
        }
        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        .nav-link:hover, .nav-link.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }
        .nav-icon {
            font-size: 18px;
        }
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }
        .header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-title h1 {
            font-size: 28px;
            color: #333;
            margin-bottom: 5px;
        }
        .page-title p {
            color: #666;
            font-size: 14px;
        }
        .btn-back {
            padding: 10px 20px;
            background: #f8f9fa;
            color: #333;
            text-decoration: none;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .test-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            max-width: 800px;
            margin: 0 auto;
        }
        .test-description {
            color: #666;
            line-height: 1.6;
            margin-bottom: 30px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        .test-results {
            margin-top: 30px;
        }
        .test-item {
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-left: 4px solid #ddd;
            background: #f8f9fa;
            transition: all 0.3s;
        }
        .test-item.success {
            border-left-color: #28a745;
            background: #d4edda;
        }
        .test-item.error {
            border-left-color: #dc3545;
            background: #f8d7da;
        }
        .test-item.warning {
            border-left-color: #ffc107;
            background: #fff3cd;
        }
        .test-item.info {
            border-left-color: #17a2b8;
            background: #d1ecf1;
        }
        .test-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        .test-name {
            font-weight: 500;
            font-size: 16px;
        }
        .test-status {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        .success .test-status {
            background: #28a745;
            color: white;
        }
        .error .test-status {
            background: #dc3545;
            color: white;
        }
        .warning .test-status {
            background: #ffc107;
            color: #333;
        }
        .info .test-status {
            background: #17a2b8;
            color: white;
        }
        .test-message {
            color: #666;
            font-size: 14px;
            line-height: 1.5;
        }
        .test-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
            justify-content: center;
        }
        .btn-test {
            padding: 15px 30px;
            background: linear-gradient(135deg, #17a2b8 0%, #138496 100%);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .btn-test:hover {
            transform: translateY(-2px);
        }
        .summary {
            display: flex;
            gap: 20px;
            margin-top: 30px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 8px;
            flex-wrap: wrap;
        }
        .summary-item {
            text-align: center;
            flex: 1;
            min-width: 150px;
        }
        .summary-number {
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .summary-label {
            font-size: 14px;
            color: #666;
        }
        .user-info {
            padding: 20px;
            text-align: center;
            border-top: 1px solid rgba(255,255,255,0.1);
            margin-top: 20px;
        }
        .user-avatar {
            width: 50px;
            height: 50px;
            background: white;
            border-radius: 50%;
            margin: 0 auto 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            font-weight: bold;
            font-size: 20px;
        }
        .logout-link {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background: rgba(255,255,255,0.1);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
        }
        @media (max-width: 768px) {
            .admin-container {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Admin Panel</h2>
                <p>MyBlog Management</p>
            </div>
            
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="../dashboard.php" class="nav-link">
                        <span class="nav-icon">📊</span>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../article/index.php" class="nav-link">
                        <span class="nav-icon">📝</span>
                        <span>Kelola Artikel</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../categories/list.php" class="nav-link">
                        <span class="nav-icon">📚</span>
                        <span>Kelola Kategori</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="upload.php" class="nav-link">
                        <span class="nav-icon">🖼️</span>
                        <span>Upload Media</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="list.php" class="nav-link">
                        <span class="nav-icon">📁</span>
                        <span>Kelola Media</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="test.php" class="nav-link active">
                        <span class="nav-icon">🔧</span>
                        <span>Test System</span>
                    </a>
                </li>
            </ul>
            
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($_SESSION['admin_username'], 0, 1)); ?>
                </div>
                <div>
                    <strong><?php echo $_SESSION['admin_username']; ?></strong>
                    <p style="font-size: 12px; opacity: 0.8; margin-top: 5px;">Administrator</p>
                </div>
                <a href="../logout.php" class="logout-link">Logout</a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div class="page-title">
                    <h1>Test Media System</h1>
                    <p>Test sistem upload dan manajemen media</p>
                </div>
                <a href="list.php" class="btn-back">← Kembali ke Media</a>
            </div>

            <div class="test-container">
                <div class="test-description">
                    <h3>📋 Deskripsi Test</h3>
                    <p>Sistem ini akan melakukan beberapa test untuk memastikan sistem media berjalan dengan baik:</p>
                    <ul style="margin-top: 10px; padding-left: 20px;">
                        <li>✅ Cek keberadaan dan permissions directory uploads</li>
                        <li>✅ Cek setting PHP untuk file upload</li>
                        <li>✅ Test kemampuan membuat dan menghapus file</li>
                        <li>✅ Cek kapasitas penyimpanan yang tersedia</li>
                        <li>✅ Hitung jumlah file yang sudah ada</li>
                    </ul>
                </div>

                <form method="POST" action="">
                    <div class="test-actions">
                        <button type="submit" class="btn-test">🚀 Jalankan Test</button>
                    </div>
                </form>

                <?php if(count($test_results) > 0): ?>
                    <div class="test-results">
                        <h3 style="margin-bottom: 20px; color: #333;">📊 Hasil Test</h3>
                        
                        <?php 
                        $success_count = 0;
                        $error_count = 0;
                        $warning_count = 0;
                        $info_count = 0;
                        
                        foreach($test_results as $test): 
                            switch($test['status']) {
                                case 'success': $success_count++; break;
                                case 'error': $error_count++; break;
                                case 'warning': $warning_count++; break;
                                case 'info': $info_count++; break;
                            }
                        ?>
                            <div class="test-item <?php echo $test['status']; ?>">
                                <div class="test-header">
                                    <div class="test-name"><?php echo $test['name']; ?></div>
                                    <div class="test-status"><?php echo strtoupper($test['status']); ?></div>
                                </div>
                                <div class="test-message"><?php echo $test['message']; ?></div>
                            </div>
                        <?php endforeach; ?>
                        
                        <div class="summary">
                            <div class="summary-item">
                                <div class="summary-number" style="color: #28a745;"><?php echo $success_count; ?></div>
                                <div class="summary-label">Berhasil</div>
                            </div>
                            <div class="summary-item">
                                <div class="summary-number" style="color: #dc3545;"><?php echo $error_count; ?></div>
                                <div class="summary-label">Error</div>
                            </div>
                            <div class="summary-item">
                                <div class="summary-number" style="color: #ffc107;"><?php echo $warning_count; ?></div>
                                <div class="summary-label">Warning</div>
                            </div>
                            <div class="summary-item">
                                <div class="summary-number" style="color: #17a2b8;"><?php echo $info_count; ?></div>
                                <div class="summary-label">Info</div>
                            </div>
                        </div>
                        
                        <div style="margin-top: 30px; padding: 20px; background: #f8f9fa; border-radius: 8px;">
                            <h4 style="margin-bottom: 15px; color: #333;">💡 Rekomendasi:</h4>
                            <ul style="color: #666; line-height: 1.6;">
                                <?php if($error_count > 0): ?>
                                    <li>Perbaiki error terlebih dahulu sebelum menggunakan sistem media</li>
                                <?php endif; ?>
                                <?php if($warning_count > 0): ?>
                                    <li>Perhatikan warning untuk performa optimal</li>
                                <?php endif; ?>
                                <li>Pastikan directory <strong>uploads/</strong> memiliki permission 0755</li>
                                <li>Ukuran file maksimal disarankan: 2-5MB untuk gambar</li>
                                <li>Backup file penting secara berkala</li>
                            </ul>
                        </div>
                    </div>
                <?php endif; ?>
                
                <div style="margin-top: 40px; padding: 20px; background: #e8f4ff; border-radius: 8px; border-left: 4px solid #4dabf7;">
                    <h4 style="margin-bottom: 10px; color: #1971c2;">🔧 Troubleshooting:</h4>
                    <p style="color: #1971c2; line-height: 1.6;">
                        Jika ada error, coba langkah berikut:<br>
                        1. Cek apakah folder <strong>uploads/</strong> ada dan writable<br>
                        2. Cek PHP settings di php.ini (upload_max_filesize, post_max_size)<br>
                        3. Restart web server (Apache/Nginx)<br>
                        4. Cek disk space yang tersedia<br>
                        5. Cek error log PHP untuk detail error
                    </p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php
function formatFileSize($bytes) {
    if ($bytes == 0) return '0 Bytes';
    $k = 1024;
    $sizes = ['Bytes', 'KB', 'MB', 'GB'];
    $i = floor(log($bytes) / log($k));
    return number_format($bytes / pow($k, $i), 2) . ' ' . $sizes[$i];
}
?>