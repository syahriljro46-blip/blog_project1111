<?php
session_start();
require_once '../../config/database.php';

// Cek jika belum login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];
$deleted_count = 0;
$error = '';

// Ambil file yang akan dihapus
$files_to_delete = [];
if (isset($_GET['file'])) {
    // Single file deletion
    $files_to_delete[] = $_GET['file'];
} elseif (isset($_GET['files']) && is_array($_GET['files'])) {
    // Bulk deletion
    $files_to_delete = $_GET['files'];
}

// Handle deletion
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['confirm_delete'])) {
    $upload_dir = '../../uploads/';
    
    if (isset($_POST['files']) && is_array($_POST['files'])) {
        foreach ($_POST['files'] as $filename) {
            $filename = basename($filename); // Security: hanya nama file
            $file_path = $upload_dir . $filename;
            
            if (file_exists($file_path) && is_file($file_path)) {
                // Check if file is used in any article
                $check_usage = mysqli_query($konek, 
                    "SELECT COUNT(*) as count FROM articles WHERE featured_image = '" . mysqli_real_escape_string($konek, $filename) . "'");
                $usage_count = mysqli_fetch_assoc($check_usage)['count'];
                
                if ($usage_count > 0) {
                    $error .= "File $filename digunakan dalam $usage_count artikel. Tidak bisa dihapus.<br>";
                    continue;
                }
                
                // Delete file
                if (unlink($file_path)) {
                    $deleted_count++;
                } else {
                    $error .= "Gagal menghapus file $filename<br>";
                }
            } else {
                $error .= "File $filename tidak ditemukan<br>";
            }
        }
        
        if ($deleted_count > 0) {
            header("Location: list.php?deleted=$deleted_count");
            exit();
        }
    }
}

// Get file info for confirmation
$file_info = [];
$upload_dir = '../../uploads/';
foreach ($files_to_delete as $filename) {
    $filename = basename($filename);
    $file_path = $upload_dir . $filename;
    
    if (file_exists($file_path)) {
        $file_info[] = [
            'name' => $filename,
            'path' => $file_path,
            'size' => filesize($file_path),
            'modified' => filemtime($file_path),
            'type' => mime_content_type($file_path),
            'url' => '../uploads/' . $filename,
            'is_image' => strpos(mime_content_type($file_path), 'image/') === 0
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hapus Media - Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        .delete-container {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0,0,0,0.1);
            max-width: 600px;
            width: 100%;
        }
        .warning-icon {
            font-size: 60px;
            color: #dc3545;
            margin-bottom: 20px;
            text-align: center;
        }
        .delete-title {
            font-size: 24px;
            color: #333;
            margin-bottom: 15px;
            text-align: center;
        }
        .delete-message {
            color: #666;
            line-height: 1.6;
            margin-bottom: 25px;
            text-align: center;
        }
        .files-list {
            max-height: 300px;
            overflow-y: auto;
            margin: 20px 0;
            border: 1px solid #eee;
            border-radius: 8px;
            padding: 15px;
        }
        .file-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            border-bottom: 1px solid #f0f0f0;
            background: #f8f9fa;
            border-radius: 5px;
            margin-bottom: 10px;
        }
        .file-item:last-child {
            border-bottom: none;
            margin-bottom: 0;
        }
        .file-preview {
            width: 60px;
            height: 60px;
            background: white;
            border-radius: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            flex-shrink: 0;
        }
        .file-preview img {
            max-width: 100%;
            max-height: 100%;
            object-fit: cover;
        }
        .file-info {
            flex: 1;
        }
        .file-name {
            font-weight: 500;
            margin-bottom: 5px;
            word-break: break-all;
        }
        .file-details {
            font-size: 12px;
            color: #666;
        }
        .warning-box {
            background: #fff3cd;
            color: #856404;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
            border-left: 4px solid #ffc107;
        }
        .warning-box strong {
            display: block;
            margin-bottom: 5px;
        }
        .delete-actions {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 30px;
        }
        .btn {
            padding: 15px 30px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s;
            text-align: center;
            min-width: 150px;
        }
        .btn-delete {
            background: #dc3545;
            color: white;
        }
        .btn-delete:hover {
            background: #c82333;
            transform: translateY(-2px);
        }
        .btn-cancel {
            background: #6c757d;
            color: white;
        }
        .btn-cancel:hover {
            background: #5a6268;
            transform: translateY(-2px);
        }
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #dc3545;
        }
        .file-count {
            text-align: center;
            font-size: 14px;
            color: #666;
            margin-bottom: 15px;
        }
        @media (max-width: 480px) {
            .delete-container {
                padding: 25px;
            }
            .delete-actions {
                flex-direction: column;
            }
            .btn {
                width: 100%;
                min-width: auto;
            }
            .file-item {
                flex-direction: column;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <div class="delete-container">
        <div class="warning-icon">⚠️</div>
        <h1 class="delete-title">Hapus Media</h1>
        
        <?php if($error): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <div class="file-count">
            Akan menghapus <strong><?php echo count($file_info); ?> file</strong>
        </div>
        
        <?php if(count($file_info) > 0): ?>
            <div class="files-list">
                <?php foreach($file_info as $file): ?>
                    <div class="file-item">
                        <div class="file-preview">
                            <?php if($file['is_image']): ?>
                                <img src="<?php echo $file['url']; ?>" 
                                     alt="<?php echo htmlspecialchars($file['name']); ?>"
                                     onerror="this.style.display='none'; this.parentElement.innerHTML='<div style=\'font-size:24px;color:#667eea;\'>📄</div>'">
                            <?php else: ?>
                                <div style="font-size: 24px; color: #667eea;">📄</div>
                            <?php endif; ?>
                        </div>
                        <div class="file-info">
                            <div class="file-name"><?php echo htmlspecialchars($file['name']); ?></div>
                            <div class="file-details">
                                <?php echo formatFileSize($file['size']); ?> • 
                                <?php echo date('d/m/Y H:i', $file['modified']); ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="warning-box">
                <strong>Peringatan!</strong>
                <ul style="margin-top: 10px; padding-left: 20px;">
                    <li>Tindakan ini tidak dapat dibatalkan</li>
                    <li>File akan dihapus permanen dari server</li>
                    <li>Jika file digunakan di artikel, link gambar akan rusak</li>
                </ul>
            </div>
            
            <form method="POST" action="">
                <?php foreach($file_info as $file): ?>
                    <input type="hidden" name="files[]" value="<?php echo htmlspecialchars($file['name']); ?>">
                <?php endforeach; ?>
                
                <div class="delete-actions">
                    <button type="submit" name="confirm_delete" value="1" class="btn btn-delete"
                            onclick="return confirm('Yakin 100% ingin menghapus <?php echo count($file_info); ?> file?')">
                        Ya, Hapus Semua
                    </button>
                    <a href="list.php" class="btn btn-cancel">Batal</a>
                </div>
            </form>
            
        <?php else: ?>
            <div class="delete-message">
                Tidak ada file yang valid untuk dihapus.
            </div>
            <div class="delete-actions">
                <a href="list.php" class="btn btn-cancel">Kembali ke Media</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
function formatFileSize($bytes) {
    if ($bytes == 0) return '0 Bytes';
    $k = 1024;
    $sizes = ['Bytes', 'KB', 'MB', 'GB'];
    $i = floor(log($bytes) / log($k));
    return number_format($bytes / pow($k, $i), 2) . ' ' . $sizes[$i];
}
?>