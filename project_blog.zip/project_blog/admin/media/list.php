<?php
session_start();
require_once '../../config/database.php';

// Cek jika belum login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];

// Handle search
$search = isset($_GET['search']) ? mysqli_real_escape_string($konek, $_GET['search']) : '';
$type = isset($_GET['type']) ? $_GET['type'] : 'all';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'newest';
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

// Scan uploads directory
$upload_dir = '../../uploads/';
$files = [];
$total_files = 0;

if (is_dir($upload_dir)) {
    $scan = scandir($upload_dir);
    foreach ($scan as $file) {
        if ($file !== '.' && $file !== '..' && !is_dir($upload_dir . $file)) {
            $file_path = $upload_dir . $file;
            $file_info = [
                'name' => $file,
                'path' => $file_path,
                'size' => filesize($file_path),
                'modified' => filemtime($file_path),
                'type' => mime_content_type($file_path),
                'url' => '../uploads/' . $file,
                'is_image' => strpos(mime_content_type($file_path), 'image/') === 0
            ];
            
            // Apply filters
            $include = true;
            
            if (!empty($search) && stripos($file, $search) === false) {
                $include = false;
            }
            
            if ($type === 'images' && !$file_info['is_image']) {
                $include = false;
            } elseif ($type === 'other' && $file_info['is_image']) {
                $include = false;
            }
            
            if ($include) {
                $files[] = $file_info;
                $total_files++;
            }
        }
    }
    
    // Apply sorting
    usort($files, function($a, $b) use ($sort) {
        switch($sort) {
            case 'oldest':
                return $a['modified'] - $b['modified'];
            case 'largest':
                return $b['size'] - $a['size'];
            case 'smallest':
                return $a['size'] - $b['size'];
            case 'name_asc':
                return strcasecmp($a['name'], $b['name']);
            case 'name_desc':
                return strcasecmp($b['name'], $a['name']);
            case 'newest':
            default:
                return $b['modified'] - $a['modified'];
        }
    });
    
    // Pagination
    $total_pages = ceil($total_files / $limit);
    $files = array_slice($files, $offset, $limit);
}

// Get storage statistics
$storage_stats = getStorageStats($upload_dir);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Media - Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            color: #333;
        }
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            height: 100vh;
        }
        .logo {
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }
        .logo h2 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        .logo p {
            font-size: 12px;
            opacity: 0.8;
        }
        .nav-menu {
            list-style: none;
        }
        .nav-item {
            margin-bottom: 5px;
        }
        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        .nav-link:hover, .nav-link.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }
        .nav-icon {
            font-size: 18px;
        }
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }
        .header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-title h1 {
            font-size: 28px;
            color: #333;
            margin-bottom: 5px;
        }
        .page-title p {
            color: #666;
            font-size: 14px;
        }
        .btn-upload {
            padding: 12px 25px;
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: transform 0.2s;
        }
        .btn-upload:hover {
            transform: translateY(-2px);
        }
        .stats-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            text-align: center;
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            font-size: 40px;
            margin-bottom: 15px;
            color: #667eea;
        }
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #333;
            margin: 10px 0;
        }
        .stat-label {
            font-size: 14px;
            color: #666;
        }
        .storage-bar {
            height: 8px;
            background: #f0f0f0;
            border-radius: 4px;
            margin-top: 10px;
            overflow: hidden;
        }
        .storage-fill {
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 4px;
            transition: width 0.3s;
        }
        .filter-section {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        .filter-form {
            display: flex;
            gap: 15px;
            align-items: flex-end;
            flex-wrap: wrap;
        }
        .filter-group {
            flex: 1;
            min-width: 200px;
        }
        .filter-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #555;
        }
        select, input[type="text"] {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 5px;
            font-size: 14px;
            transition: border 0.3s;
        }
        select:focus, input[type="text"]:focus {
            border-color: #667eea;
            outline: none;
        }
        .btn-filter {
            padding: 12px 25px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
            transition: background 0.3s;
        }
        .btn-filter:hover {
            background: #5a6fd8;
        }
        .btn-reset {
            padding: 12px 20px;
            background: #f8f9fa;
            color: #666;
            border: 1px solid #ddd;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
        }
        .media-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        .media-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            transition: all 0.3s;
            position: relative;
        }
        .media-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }
        .media-preview {
            height: 150px;
            background: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
        }
        .media-preview img {
            max-width: 100%;
            max-height: 100%;
            object-fit: cover;
        }
        .file-icon {
            font-size: 60px;
            color: #667eea;
            opacity: 0.7;
        }
        .media-overlay {
            position: absolute;
            top: 10px;
            right: 10px;
            display: flex;
            gap: 5px;
            opacity: 0;
            transition: opacity 0.3s;
        }
        .media-card:hover .media-overlay {
            opacity: 1;
        }
        .btn-overlay {
            width: 35px;
            height: 35px;
            background: rgba(0,0,0,0.7);
            color: white;
            border: none;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s;
        }
        .btn-overlay:hover {
            background: rgba(0,0,0,0.9);
        }
        .media-info {
            padding: 15px;
        }
        .media-name {
            font-size: 14px;
            font-weight: 500;
            margin-bottom: 5px;
            word-break: break-all;
            line-height: 1.3;
        }
        .media-meta {
            font-size: 11px;
            color: #666;
            display: flex;
            justify-content: space-between;
            margin-top: 8px;
        }
        .media-actions {
            display: flex;
            gap: 8px;
            margin-top: 10px;
        }
        .btn-action {
            flex: 1;
            padding: 8px;
            border: none;
            border-radius: 5px;
            font-size: 12px;
            cursor: pointer;
            text-decoration: none;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 5px;
            transition: all 0.3s;
        }
        .btn-view {
            background: #17a2b8;
            color: white;
        }
        .btn-delete {
            background: #dc3545;
            color: white;
        }
        .btn-action:hover {
            opacity: 0.9;
            transform: translateY(-2px);
        }
        .empty-state {
            grid-column: 1 / -1;
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }
        .empty-state h3 {
            font-size: 1.5em;
            margin-bottom: 10px;
            color: #333;
        }
        .pagination {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin: 40px 0;
            flex-wrap: wrap;
        }
        .page-link {
            padding: 10px 15px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 5px;
            color: #333;
            text-decoration: none;
            transition: all 0.3s;
        }
        .page-link:hover {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        .page-link.active {
            background: #667eea;
            color: white;
            border-color: #667eea;
        }
        .bulk-actions {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            align-items: center;
        }
        .checkbox-select {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
        }
        .checkbox-select input[type="checkbox"] {
            width: 18px;
            height: 18px;
        }
        .user-info {
            padding: 20px;
            text-align: center;
            border-top: 1px solid rgba(255,255,255,0.1);
            margin-top: 20px;
        }
        .user-avatar {
            width: 50px;
            height: 50px;
            background: white;
            border-radius: 50%;
            margin: 0 auto 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            font-weight: bold;
            font-size: 20px;
        }
        .logout-link {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background: rgba(255,255,255,0.1);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
        }
        @media (max-width: 768px) {
            .admin-container {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
            }
            .main-content {
                margin-left: 0;
            }
            .media-grid {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            }
            .filter-form {
                flex-direction: column;
            }
            .filter-group {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Admin Panel</h2>
                <p>MyBlog Management</p>
            </div>
            
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="../dashboard.php" class="nav-link">
                        <span class="nav-icon">📊</span>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../article/index.php" class="nav-link">
                        <span class="nav-icon">📝</span>
                        <span>Kelola Artikel</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../categories/list.php" class="nav-link">
                        <span class="nav-icon">📚</span>
                        <span>Kelola Kategori</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="upload.php" class="nav-link">
                        <span class="nav-icon">🖼️</span>
                        <span>Upload Media</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="list.php" class="nav-link active">
                        <span class="nav-icon">📁</span>
                        <span>Kelola Media</span>
                    </a>
                </li>
            </ul>
            
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($_SESSION['admin_username'], 0, 1)); ?>
                </div>
                <div>
                    <strong><?php echo $_SESSION['admin_username']; ?></strong>
                    <p style="font-size: 12px; opacity: 0.8; margin-top: 5px;">Administrator</p>
                </div>
                <a href="../logout.php" class="logout-link">Logout</a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div class="page-title">
                    <h1>Kelola Media</h1>
                    <p>Kelola semua file media yang diupload</p>
                </div>
                <a href="upload.php" class="btn-upload">
                    <span>📤</span> Upload Baru
                </a>
            </div>

            <div class="stats-cards">
                <div class="stat-card">
                    <div class="stat-icon">📁</div>
                    <div class="stat-number"><?php echo $storage_stats['total_files']; ?></div>
                    <div class="stat-label">Total File</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">🖼️</div>
                    <div class="stat-number"><?php echo $storage_stats['image_files']; ?></div>
                    <div class="stat-label">File Gambar</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">💾</div>
                    <div class="stat-number"><?php echo formatFileSize($storage_stats['total_size']); ?></div>
                    <div class="stat-label">Total Ukuran</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">📊</div>
                    <div class="stat-number"><?php echo round(($storage_stats['total_size'] / (100 * 1024 * 1024)) * 100, 1); ?>%</div>
                    <div class="stat-label">Penyimpanan Terpakai</div>
                    <div class="storage-bar">
                        <div class="storage-fill" style="width: <?php echo min(100, ($storage_stats['total_size'] / (100 * 1024 * 1024)) * 100); ?>%"></div>
                    </div>
                    <div style="font-size: 11px; color: #666; margin-top: 5px;">
                        Maks: 100MB
                    </div>
                </div>
            </div>

            <div class="filter-section">
                <form method="GET" action="" class="filter-form">
                    <div class="filter-group">
                        <label>Cari File</label>
                        <input type="text" name="search" placeholder="Nama file..." 
                               value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    
                    <div class="filter-group">
                        <label>Tipe File</label>
                        <select name="type">
                            <option value="all" <?php echo $type == 'all' ? 'selected' : ''; ?>>Semua File</option>
                            <option value="images" <?php echo $type == 'images' ? 'selected' : ''; ?>>Hanya Gambar</option>
                            <option value="other" <?php echo $type == 'other' ? 'selected' : ''; ?>>File Lainnya</option>
                        </select>
                    </div>
                    
                    <div class="filter-group">
                        <label>Urutkan</label>
                        <select name="sort">
                            <option value="newest" <?php echo $sort == 'newest' ? 'selected' : ''; ?>>Terbaru</option>
                            <option value="oldest" <?php echo $sort == 'oldest' ? 'selected' : ''; ?>>Terlama</option>
                            <option value="largest" <?php echo $sort == 'largest' ? 'selected' : ''; ?>>Terbesar</option>
                            <option value="smallest" <?php echo $sort == 'smallest' ? 'selected' : ''; ?>>Terkecil</option>
                            <option value="name_asc" <?php echo $sort == 'name_asc' ? 'selected' : ''; ?>>Nama A-Z</option>
                            <option value="name_desc" <?php echo $sort == 'name_desc' ? 'selected' : ''; ?>>Nama Z-A</option>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn-filter">Terapkan Filter</button>
                    
                    <?php if(!empty($search) || $type != 'all' || $sort != 'newest'): ?>
                        <a href="list.php" class="btn-reset">Reset</a>
                    <?php endif; ?>
                </form>
            </div>

            <?php if(count($files) > 0): ?>
                <div class="bulk-actions">
                    <label class="checkbox-select">
                        <input type="checkbox" id="selectAll" onchange="toggleSelectAll()">
                        <span>Pilih Semua</span>
                    </label>
                    <button type="button" class="btn-action btn-delete" onclick="deleteSelected()" style="padding: 10px 20px;">
                        Hapus yang Dipilih
                    </button>
                </div>

                <div class="media-grid">
                    <?php foreach($files as $file): ?>
                        <div class="media-card">
                            <div class="media-preview">
                                <?php if($file['is_image']): ?>
                                    <img src="<?php echo $file['url']; ?>" 
                                         alt="<?php echo htmlspecialchars($file['name']); ?>"
                                         onerror="this.style.display='none'; this.parentElement.innerHTML='<div class=\'file-icon\'>📷</div>'">
                                <?php else: ?>
                                    <div class="file-icon">📄</div>
                                <?php endif; ?>
                                
                                <div class="media-overlay">
                                    <button type="button" class="btn-overlay" 
                                            onclick="copyUrl('<?php echo $file['url']; ?>')"
                                            title="Copy URL">
                                        🔗
                                    </button>
                                    <button type="button" class="btn-overlay" 
                                            onclick="previewFile('<?php echo $file['url']; ?>', '<?php echo $file['name']; ?>')"
                                            title="Preview">
                                        👁️
                                    </button>
                                </div>
                            </div>
                            <div class="media-info">
                                <div class="media-name" title="<?php echo htmlspecialchars($file['name']); ?>">
                                    <?php echo htmlspecialchars(substr($file['name'], 0, 25)); ?>
                                    <?php if(strlen($file['name']) > 25): ?>...<?php endif; ?>
                                </div>
                                <div class="media-meta">
                                    <span><?php echo formatFileSize($file['size']); ?></span>
                                    <span><?php echo date('d/m/Y', $file['modified']); ?></span>
                                </div>
                                <div class="media-actions">
                                    <a href="<?php echo $file['url']; ?>" target="_blank" class="btn-action btn-view">Lihat</a>
                                    <a href="delete.php?file=<?php echo urlencode($file['name']); ?>" 
                                       class="btn-action btn-delete"
                                       onclick="return confirm('Hapus file <?php echo addslashes($file['name']); ?>?')">Hapus</a>
                                </div>
                                <div style="margin-top: 10px; font-size: 11px; color: #999;">
                                    <input type="checkbox" class="file-select" value="<?php echo htmlspecialchars($file['name']); ?>">
                                    <span>Pilih</span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <?php if($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if($page > 1): ?>
                            <a href="?search=<?php echo urlencode($search); ?>&type=<?php echo $type; ?>&sort=<?php echo $sort; ?>&page=<?php echo $page-1; ?>" 
                               class="page-link">← Prev</a>
                        <?php endif; ?>
                        
                        <?php 
                        $start = max(1, $page - 2);
                        $end = min($total_pages, $page + 2);
                        
                        for($i = $start; $i <= $end; $i++): ?>
                            <?php if($i == $page): ?>
                                <span class="page-link active"><?php echo $i; ?></span>
                            <?php else: ?>
                                <a href="?search=<?php echo urlencode($search); ?>&type=<?php echo $type; ?>&sort=<?php echo $sort; ?>&page=<?php echo $i; ?>" 
                                   class="page-link"><?php echo $i; ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if($page < $total_pages): ?>
                            <a href="?search=<?php echo urlencode($search); ?>&type=<?php echo $type; ?>&sort=<?php echo $sort; ?>&page=<?php echo $page+1; ?>" 
                               class="page-link">Next →</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
            <?php else: ?>
                <div class="empty-state">
                    <h3>Tidak ada file ditemukan</h3>
                    <p><?php 
                        if(!empty($search)) {
                            echo "Tidak ada file dengan nama '" . htmlspecialchars($search) . "'";
                        } elseif($type == 'images') {
                            echo "Belum ada file gambar";
                        } elseif($type == 'other') {
                            echo "Belum ada file selain gambar";
                        } else {
                            echo "Belum ada file media. Mulai upload file pertama Anda!";
                        }
                    ?></p>
                    <a href="upload.php" class="btn-upload" style="margin-top: 20px;">Upload File Pertama</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Preview Modal -->
    <div id="previewModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.9); z-index: 1000; align-items: center; justify-content: center;">
        <div style="background: white; padding: 20px; border-radius: 10px; max-width: 90%; max-height: 90%; position: relative;">
            <button onclick="closePreview()" style="position: absolute; top: 10px; right: 10px; background: #dc3545; color: white; border: none; border-radius: 50%; width: 30px; height: 30px; cursor: pointer;">✕</button>
            <div id="previewContent" style="max-width: 800px; max-height: 600px; overflow: auto;"></div>
            <div id="previewInfo" style="margin-top: 15px; text-align: center; color: #333;"></div>
        </div>
    </div>

    <script>
    function toggleSelectAll() {
        const selectAll = document.getElementById('selectAll').checked;
        document.querySelectorAll('.file-select').forEach(checkbox => {
            checkbox.checked = selectAll;
        });
    }
    
    function deleteSelected() {
        const selected = Array.from(document.querySelectorAll('.file-select:checked'))
            .map(cb => cb.value);
        
        if (selected.length === 0) {
            alert('Pilih file terlebih dahulu!');
            return;
        }
        
        if (confirm(`Hapus ${selected.length} file yang dipilih?`)) {
            // Redirect to bulk delete page
            const query = selected.map(file => `files[]=${encodeURIComponent(file)}`).join('&');
            window.location.href = `delete.php?${query}`;
        }
    }
    
    function copyUrl(url) {
        navigator.clipboard.writeText(url)
            .then(() => alert('URL berhasil disalin!'))
            .catch(() => {
                // Fallback for older browsers
                const textArea = document.createElement('textarea');
                textArea.value = url;
                document.body.appendChild(textArea);
                textArea.select();
                document.execCommand('copy');
                document.body.removeChild(textArea);
                alert('URL berhasil disalin!');
            });
    }
    
    function previewFile(url, name) {
        const modal = document.getElementById('previewModal');
        const content = document.getElementById('previewContent');
        const info = document.getElementById('previewInfo');
        
        if (url.match(/\.(jpg|jpeg|png|gif|webp|svg)$/i)) {
            content.innerHTML = `<img src="${url}" alt="${name}" style="max-width: 100%;">`;
        } else {
            content.innerHTML = `<div style="text-align: center; padding: 40px;">
                <div style="font-size: 60px; color: #667eea;">📄</div>
                <p style="margin-top: 20px; color: #666;">Preview tidak tersedia untuk file ini</p>
            </div>`;
        }
        
        info.innerHTML = `<strong>${name}</strong><br>
                         <a href="${url}" target="_blank" style="color: #667eea;">Buka di tab baru</a>`;
        
        modal.style.display = 'flex';
    }
    
    function closePreview() {
        document.getElementById('previewModal').style.display = 'none';
    }
    
    // Close modal on ESC key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closePreview();
        }
    });
    
    // Close modal on outside click
    document.getElementById('previewModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closePreview();
        }
    });
    </script>
</body>
</html>

<?php
// Helper functions
function getStorageStats($dir) {
    $stats = [
        'total_files' => 0,
        'image_files' => 0,
        'total_size' => 0
    ];
    
    if (is_dir($dir)) {
        $scan = scandir($dir);
        foreach ($scan as $file) {
            if ($file !== '.' && $file !== '..' && !is_dir($dir . $file)) {
                $file_path = $dir . $file;
                $stats['total_files']++;
                $stats['total_size'] += filesize($file_path);
                
                if (strpos(mime_content_type($file_path), 'image/') === 0) {
                    $stats['image_files']++;
                }
            }
        }
    }
    
    return $stats;
}

function formatFileSize($bytes) {
    if ($bytes == 0) return '0 Bytes';
    $k = 1024;
    $sizes = ['Bytes', 'KB', 'MB', 'GB'];
    $i = floor(log($bytes) / log($k));
    return number_format($bytes / pow($k, $i), 2) . ' ' . $sizes[$i];
}
?>