<?php
session_start();
require_once '../../config/database.php';

// Cek jika belum login
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];
$success = '';
$error = '';
$uploaded_files = [];

// Create uploads directory if not exists
$upload_dir = '../../uploads/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['files'])) {
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'];
    $max_size = 5 * 1024 * 1024; // 5MB
    $max_files = 10;
    
    $files = $_FILES['files'];
    $file_count = count($files['name']);
    
    // Validate number of files
    if ($file_count > $max_files) {
        $error = "Maksimal $max_files file per upload!";
    } else {
        for ($i = 0; $i < $file_count; $i++) {
            if ($files['error'][$i] === UPLOAD_ERR_OK) {
                $file_name = $files['name'][$i];
                $file_tmp = $files['tmp_name'][$i];
                $file_size = $files['size'][$i];
                $file_type = $files['type'][$i];
                
                // Validate file type
                if (!in_array($file_type, $allowed_types)) {
                    $error = "File $file_name: Jenis file tidak didukung!";
                    continue;
                }
                
                // Validate file size
                if ($file_size > $max_size) {
                    $error = "File $file_name: Ukuran file terlalu besar (maks 5MB)!";
                    continue;
                }
                
                // Generate unique filename
                $file_extension = pathinfo($file_name, PATHINFO_EXTENSION);
                $unique_name = 'media_' . time() . '_' . uniqid() . '.' . $file_extension;
                $destination = $upload_dir . $unique_name;
                
                // Move uploaded file
                if (move_uploaded_file($file_tmp, $destination)) {
                    $uploaded_files[] = [
                        'original_name' => $file_name,
                        'saved_name' => $unique_name,
                        'size' => $file_size,
                        'type' => $file_type,
                        'url' => '../uploads/' . $unique_name
                    ];
                } else {
                    $error = "Gagal mengupload file $file_name!";
                }
            } elseif ($files['error'][$i] !== UPLOAD_ERR_NO_FILE) {
                $error = "Error upload file $file_name: " . $files['error'][$i];
            }
        }
        
        if (count($uploaded_files) > 0) {
            $success = count($uploaded_files) . " file berhasil diupload!";
        }
    }
}

// Scan uploads directory for existing files
$existing_files = [];
if (is_dir($upload_dir)) {
    $scan = scandir($upload_dir);
    foreach ($scan as $file) {
        if ($file !== '.' && $file !== '..' && !is_dir($upload_dir . $file)) {
            $file_path = $upload_dir . $file;
            $existing_files[] = [
                'name' => $file,
                'size' => filesize($file_path),
                'modified' => filemtime($file_path),
                'type' => mime_content_type($file_path),
                'url' => '../uploads/' . $file
            ];
        }
    }
    // Sort by modification time (newest first)
    usort($existing_files, function($a, $b) {
        return $b['modified'] - $a['modified'];
    });
    $existing_files = array_slice($existing_files, 0, 20); // Show latest 20 files
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Media - Admin</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            color: #333;
        }
        .admin-container {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 250px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        .logo {
            padding: 0 20px 30px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 20px;
        }
        .logo h2 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        .logo p {
            font-size: 12px;
            opacity: 0.8;
        }
        .nav-menu {
            list-style: none;
        }
        .nav-item {
            margin-bottom: 5px;
        }
        .nav-link {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 15px 20px;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        .nav-link:hover, .nav-link.active {
            background: rgba(255,255,255,0.1);
            border-left-color: white;
        }
        .nav-icon {
            font-size: 18px;
        }
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }
        .header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .page-title h1 {
            font-size: 28px;
            color: #333;
            margin-bottom: 5px;
        }
        .page-title p {
            color: #666;
            font-size: 14px;
        }
        .btn-manage {
            padding: 10px 20px;
            background: #f8f9fa;
            color: #333;
            text-decoration: none;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        .upload-container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        .upload-area {
            border: 3px dashed #ddd;
            border-radius: 10px;
            padding: 40px;
            text-align: center;
            transition: all 0.3s;
            cursor: pointer;
            position: relative;
        }
        .upload-area:hover, .upload-area.dragover {
            border-color: #667eea;
            background: #f8f9fa;
        }
        .upload-icon {
            font-size: 60px;
            color: #667eea;
            margin-bottom: 20px;
        }
        .upload-text {
            font-size: 18px;
            color: #333;
            margin-bottom: 10px;
        }
        .upload-hint {
            color: #666;
            font-size: 14px;
            margin-bottom: 20px;
        }
        .file-input {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            opacity: 0;
            cursor: pointer;
        }
        .file-list {
            margin-top: 20px;
            max-height: 200px;
            overflow-y: auto;
        }
        .file-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px;
            border: 1px solid #eee;
            border-radius: 5px;
            margin-bottom: 10px;
            background: #f8f9fa;
        }
        .file-info {
            display: flex;
            align-items: center;
            gap: 10px;
            flex: 1;
        }
        .file-icon {
            font-size: 20px;
            color: #667eea;
        }
        .file-name {
            font-weight: 500;
            word-break: break-all;
        }
        .file-size {
            font-size: 12px;
            color: #666;
        }
        .upload-actions {
            display: flex;
            gap: 15px;
            margin-top: 20px;
            justify-content: center;
        }
        .btn-upload {
            padding: 15px 30px;
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .btn-upload:hover {
            transform: translateY(-2px);
        }
        .btn-clear {
            padding: 15px 30px;
            background: #6c757d;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
        }
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #28a745;
        }
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #dc3545;
        }
        .recent-files {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
        }
        .section-title {
            font-size: 20px;
            margin-bottom: 20px;
            color: #333;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .files-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 20px;
        }
        .file-card {
            border: 1px solid #eee;
            border-radius: 8px;
            overflow: hidden;
            transition: all 0.3s;
        }
        .file-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .file-preview {
            height: 120px;
            background: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        .file-preview img {
            max-width: 100%;
            max-height: 100%;
            object-fit: cover;
        }
        .file-details {
            padding: 10px;
            background: white;
        }
        .file-title {
            font-size: 12px;
            font-weight: 500;
            margin-bottom: 5px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .file-meta {
            font-size: 10px;
            color: #666;
            display: flex;
            justify-content: space-between;
        }
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #666;
        }
        .empty-state h3 {
            font-size: 1.2em;
            margin-bottom: 10px;
            color: #333;
        }
        .user-info {
            padding: 20px;
            text-align: center;
            border-top: 1px solid rgba(255,255,255,0.1);
            margin-top: 20px;
        }
        .user-avatar {
            width: 50px;
            height: 50px;
            background: white;
            border-radius: 50%;
            margin: 0 auto 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #667eea;
            font-weight: bold;
            font-size: 20px;
        }
        .logout-link {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background: rgba(255,255,255,0.1);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-size: 12px;
        }
        .uploaded-list {
            margin-top: 20px;
        }
        .uploaded-item {
            background: #e8f5e9;
            border: 1px solid #c8e6c9;
            border-radius: 5px;
            padding: 10px;
            margin-bottom: 10px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        @media (max-width: 768px) {
            .admin-container {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
            }
            .main-content {
                margin-left: 0;
            }
            .files-grid {
                grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="logo">
                <h2>Admin Panel</h2>
                <p>MyBlog Management</p>
            </div>
            
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="../dashboard.php" class="nav-link">
                        <span class="nav-icon">📊</span>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../article/index.php" class="nav-link">
                        <span class="nav-icon">📝</span>
                        <span>Kelola Artikel</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../categories/list.php" class="nav-link">
                        <span class="nav-icon">📚</span>
                        <span>Kelola Kategori</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="upload.php" class="nav-link active">
                        <span class="nav-icon">🖼️</span>
                        <span>Upload Media</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="list.php" class="nav-link">
                        <span class="nav-icon">📁</span>
                        <span>Kelola Media</span>
                    </a>
                </li>
            </ul>
            
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($_SESSION['admin_username'], 0, 1)); ?>
                </div>
                <div>
                    <strong><?php echo $_SESSION['admin_username']; ?></strong>
                    <p style="font-size: 12px; opacity: 0.8; margin-top: 5px;">Administrator</p>
                </div>
                <a href="../logout.php" class="logout-link">Logout</a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <div class="page-title">
                    <h1>Upload Media</h1>
                    <p>Upload gambar untuk artikel blog Anda</p>
                </div>
                <a href="list.php" class="btn-manage">📁 Kelola Media</a>
            </div>

            <?php if($success): ?>
                <div class="success-message">
                    <?php echo $success; ?>
                    <?php if(count($uploaded_files) > 0): ?>
                        <div class="uploaded-list">
                            <?php foreach($uploaded_files as $file): ?>
                                <div class="uploaded-item">
                                    <div>
                                        <strong><?php echo htmlspecialchars($file['original_name']); ?></strong>
                                        <div style="font-size: 12px; color: #666;">
                                            Disimpan sebagai: <?php echo $file['saved_name']; ?>
                                        </div>
                                    </div>
                                    <a href="<?php echo $file['url']; ?>" target="_blank" style="font-size: 12px;">Lihat</a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <?php if($error): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="upload-container">
                <form method="POST" action="" enctype="multipart/form-data" id="uploadForm">
                    <div class="upload-area" id="uploadArea" onclick="document.getElementById('files').click()">
                        <div class="upload-icon">📤</div>
                        <div class="upload-text">Klik atau tarik file ke sini</div>
                        <div class="upload-hint">
                            File gambar (JPG, PNG, GIF, WEBP, SVG)<br>
                            Maksimal 5MB per file, maksimal 10 file
                        </div>
                        <input type="file" id="files" name="files[]" multiple class="file-input" 
                               accept=".jpg,.jpeg,.png,.gif,.webp,.svg" onchange="updateFileList()">
                    </div>
                    
                    <div class="file-list" id="fileList"></div>
                    
                    <div class="upload-actions">
                        <button type="submit" class="btn-upload">Upload File</button>
                        <button type="button" class="btn-clear" onclick="clearFileList()">Clear</button>
                    </div>
                </form>
            </div>

            <div class="recent-files">
                <h2 class="section-title">
                    <span>🕒</span> File Terbaru
                </h2>
                
                <?php if(count($existing_files) > 0): ?>
                    <div class="files-grid">
                        <?php foreach($existing_files as $file): ?>
                            <div class="file-card">
                                <div class="file-preview">
                                    <?php if(strpos($file['type'], 'image/') === 0): ?>
                                        <img src="<?php echo $file['url']; ?>" 
                                             alt="<?php echo htmlspecialchars($file['name']); ?>"
                                             onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgdmlld0JveD0iMCAwIDEwMCAxMDAiIGZpbGw9IiNlZWVlZWUiPjxyZWN0IHdpZHRoPSIxMDAiIGhlaWdodD0iMTAwIi8+PHRleHQgeD0iNTAiIHk9IjUwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkb21pbmFudC1iYXNlbGluZT0iY2VudHJhbCIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjEwIj5JbWFnZTwvdGV4dD48L3N2Zz4='">
                                    <?php else: ?>
                                        <div style="font-size: 40px; color: #667eea;">📄</div>
                                    <?php endif; ?>
                                </div>
                                <div class="file-details">
                                    <div class="file-title" title="<?php echo htmlspecialchars($file['name']); ?>">
                                        <?php echo htmlspecialchars(substr($file['name'], 0, 20)); ?>
                                        <?php if(strlen($file['name']) > 20): ?>...<?php endif; ?>
                                    </div>
                                    <div class="file-meta">
                                        <span><?php echo formatFileSize($file['size']); ?></span>
                                        <span><?php echo date('d/m', $file['modified']); ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div style="text-align: center; margin-top: 20px;">
                        <a href="list.php" style="color: #667eea; text-decoration: none; font-weight: 500;">
                            Lihat semua file →
                        </a>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <h3>Belum ada file</h3>
                        <p>Upload file pertama Anda di atas</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
    let selectedFiles = [];
    
    function updateFileList() {
        const fileInput = document.getElementById('files');
        const fileList = document.getElementById('fileList');
        const uploadArea = document.getElementById('uploadArea');
        
        selectedFiles = Array.from(fileInput.files);
        fileList.innerHTML = '';
        
        if (selectedFiles.length > 0) {
            uploadArea.style.borderColor = '#28a745';
            uploadArea.style.background = '#f8f9fa';
            
            selectedFiles.forEach((file, index) => {
                const fileItem = document.createElement('div');
                fileItem.className = 'file-item';
                fileItem.innerHTML = `
                    <div class="file-info">
                        <div class="file-icon">📷</div>
                        <div>
                            <div class="file-name">${file.name}</div>
                            <div class="file-size">${formatFileSize(file.size)}</div>
                        </div>
                    </div>
                    <button type="button" onclick="removeFile(${index})" style="background: none; border: none; color: #dc3545; cursor: pointer;">✕</button>
                `;
                fileList.appendChild(fileItem);
            });
        } else {
            uploadArea.style.borderColor = '#ddd';
            uploadArea.style.background = 'transparent';
        }
    }
    
    function removeFile(index) {
        const fileInput = document.getElementById('files');
        const dt = new DataTransfer();
        
        selectedFiles.forEach((file, i) => {
            if (i !== index) {
                dt.items.add(file);
            }
        });
        
        selectedFiles = Array.from(dt.files);
        fileInput.files = dt.files;
        updateFileList();
    }
    
    function clearFileList() {
        document.getElementById('files').value = '';
        selectedFiles = [];
        updateFileList();
    }
    
    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
    
    // Drag and drop functionality
    const uploadArea = document.getElementById('uploadArea');
    
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });
    
    uploadArea.addEventListener('dragleave', () => {
        uploadArea.classList.remove('dragover');
    });
    
    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        const fileInput = document.getElementById('files');
        
        // Combine existing files with dropped files
        const dt = new DataTransfer();
        
        // Add existing files
        for (const file of selectedFiles) {
            dt.items.add(file);
        }
        
        // Add dropped files
        for (const file of files) {
            dt.items.add(file);
        }
        
        // Update file input
        fileInput.files = dt.files;
        updateFileList();
    });
    
    // Prevent form submission if no files
    document.getElementById('uploadForm').addEventListener('submit', function(e) {
        if (selectedFiles.length === 0) {
            e.preventDefault();
            alert('Pilih file terlebih dahulu!');
        }
    });
    </script>
</body>
</html>

<?php
// Helper function to format file size
function formatFileSize($bytes) {
    if ($bytes == 0) return '0 Bytes';
    $k = 1024;
    $sizes = ['Bytes', 'KB', 'MB', 'GB'];
    $i = floor(log($bytes) / log($k));
    return number_format($bytes / pow($k, $i), 2) . ' ' . $sizes[$i];
}
?>