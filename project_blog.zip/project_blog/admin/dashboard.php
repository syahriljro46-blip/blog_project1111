<?php
session_start();
require_once '../config/database.php';

// Cek jika belum login, redirect ke login
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Ambil data admin
$admin_id = $_SESSION['admin_id'];
$admin_query = mysqli_query($konek, "SELECT * FROM admins WHERE id = $admin_id");
$admin = mysqli_fetch_assoc($admin_query);

// Hitung total artikel
$total_articles = mysqli_fetch_assoc(mysqli_query($konek, "SELECT COUNT(*) as total FROM articles WHERE author_id = $admin_id"))['total'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f4f4;
        }
        .header {
            background: #333;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 0 20px;
        }
        .welcome {
            background: white;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-card h3 {
            margin-top: 0;
            color: #333;
        }
        .stat-number {
            font-size: 36px;
            font-weight: bold;
            color: #007bff;
            margin: 10px 0;
        }
        .menu {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        .btn {
            padding: 10px 20px;
            background: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
        }
        .btn:hover {
            background: #0056b3;
        }
        .btn-logout {
            background: #dc3545;
        }
        .btn-logout:hover {
            background: #c82333;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Dashboard Admin</h1>
        <div>
            <span>Halo, <?php echo $admin['username']; ?>!</span>
            <a href="logout.php" class="btn btn-logout" style="margin-left: 15px;">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="welcome">
            <h2>Selamat datang, <?php echo $admin['full_name'] ?: $admin['username']; ?>!</h2>
            <p>Anda login sebagai administrator.</p>
            
            <div class="menu">
                <a href="article/index.php" class="btn">Kelola Artikel</a>
                <a href="categories/list.php" class="btn">Kelola Kategori</a>
                <a href="comments/list.php" class="btn">Lihat Komentar</a>
                 <a href="user/list_user.php" class="btn">Lihat User</a>
            </div>
        </div>
        
        <div class="stats">
            <div class="stat-card">
                <h3>Total Artikel</h3>
                <div class="stat-number"><?php echo $total_articles; ?></div>
                <p>Artikel yang telah dibuat</p>
            </div>
            
            <?php
            // Hitung artikel yang dipublish
            $published_articles = mysqli_fetch_assoc(mysqli_query($konek, 
                "SELECT COUNT(*) as total FROM articles WHERE author_id = $admin_id AND is_published = 1"))['total'];
            ?>
            <div class="stat-card">
                <h3>Artikel Dipublikasi</h3>
                <div class="stat-number"><?php echo $published_articles; ?></div>
                <p>Artikel yang sudah live</p>
            </div>
            
            <?php
            // Hitung total views
            $total_views = mysqli_fetch_assoc(mysqli_query($konek, 
                "SELECT SUM(view_count) as total FROM articles WHERE author_id = $admin_id"))['total'];
            $total_views = $total_views ?: 0;
            ?>
            <div class="stat-card">
                <h3>Total Views</h3>
                <div class="stat-number"><?php echo number_format($total_views); ?></div>
                <p>Total pembaca artikel</p>
            </div>
        </div>
    </div>
</body>
</html>