<?php
session_start();
require_once '../config/database.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

// Ambil data user saat ini
$query = "SELECT * FROM users WHERE id = '$user_id'";
$result = mysqli_query($konek, $query);
$user = mysqli_fetch_assoc($result);

if (!$user) {
    session_destroy();
    header('Location: login.php');
    exit();
}

// Proses update profile
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = mysqli_real_escape_string($konek, $_POST['full_name']);
    $email = mysqli_real_escape_string($konek, $_POST['email']);
    $bio = mysqli_real_escape_string($konek, $_POST['bio'] ?? '');
    $website = mysqli_real_escape_string($konek, $_POST['website'] ?? '');
    $location = mysqli_real_escape_string($konek, $_POST['location'] ?? '');
    
    // Validasi
    if (empty($full_name) || empty($email)) {
        $error = "Nama lengkap dan email harus diisi!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Format email tidak valid!";
    } elseif ($email != $user['email']) {
        // Cek jika email sudah digunakan user lain
        $check_email = "SELECT id FROM users WHERE email = '$email' AND id != '$user_id'";
        $email_result = mysqli_query($konek, $check_email);
        
        if (mysqli_num_rows($email_result) > 0) {
            $error = "Email sudah digunakan oleh user lain!";
        }
    } else {
        // Upload profile image jika ada
        $profile_image = $user['profile_image'];
        
        if (isset($_FILES['profile_image']) && $_FILES['profile_image']['error'] == 0) {
            $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
            $file_type = $_FILES['profile_image']['type'];
            $file_size = $_FILES['profile_image']['size'];
            $file_tmp = $_FILES['profile_image']['tmp_name'];
            
            // Validasi file
            if (!in_array($file_type, $allowed_types)) {
                $error = "Hanya file JPG, JPEG, PNG, dan GIF yang diizinkan!";
            } elseif ($file_size > 2 * 1024 * 1024) { // 2MB
                $error = "Ukuran file maksimal 2MB!";
            } else {
                // Generate nama file unik
                $file_ext = strtolower(pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION));
                $new_filename = 'profile_' . $user_id . '_' . time() . '.' . $file_ext;
                $upload_path = '../uploads/profiles/' . $new_filename;
                
                // Buat folder jika belum ada
                if (!is_dir('../uploads/profiles')) {
                    mkdir('../uploads/profiles', 0777, true);
                }
                
                // Hapus foto lama jika ada
                if ($profile_image && file_exists('../uploads/profiles/' . $profile_image)) {
                    unlink('../uploads/profiles/' . $profile_image);
                }
                
                // Upload file baru
                if (move_uploaded_file($file_tmp, $upload_path)) {
                    $profile_image = $new_filename;
                } else {
                    $error = "Gagal mengupload foto profil!";
                }
            }
        }
        
        // Update data user jika tidak ada error
        if (empty($error)) {
            // Tambahkan kolom bio, website, location jika belum ada
            $check_columns = "SHOW COLUMNS FROM users LIKE 'bio'";
            $columns_result = mysqli_query($konek, $check_columns);
            
            if (mysqli_num_rows($columns_result) == 0) {
                // Tambahkan kolom baru
                $add_columns = "ALTER TABLE users 
                                ADD COLUMN bio TEXT AFTER profile_image,
                                ADD COLUMN website VARCHAR(255) AFTER bio,
                                ADD COLUMN location VARCHAR(100) AFTER website";
                mysqli_query($konek, $add_columns);
            }
            
            // Update query
            $update_query = "UPDATE users SET 
                            full_name = '$full_name',
                            email = '$email',
                            profile_image = '$profile_image',
                            bio = '$bio',
                            website = '$website',
                            location = '$location',
                            updated_at = NOW()
                            WHERE id = '$user_id'";
            
            if (mysqli_query($konek, $update_query)) {
                $message = "Profile berhasil diperbarui!";
                
                // Update session data
                $_SESSION['user_fullname'] = $full_name;
                $_SESSION['user_email'] = $email;
                if ($profile_image) {
                    $_SESSION['user_profile_image'] = $profile_image;
                }
                
                // Refresh user data
                $result = mysqli_query($konek, $query);
                $user = mysqli_fetch_assoc($result);
            } else {
                $error = "Gagal memperbarui profile: " . mysqli_error($konek);
            }
        }
    }
}

// Hitung statistik user
$stats_query = "SELECT 
                (SELECT COUNT(*) FROM comments WHERE user_id = '$user_id') as total_comments,
                (SELECT COUNT(*) FROM article_likes WHERE user_id = '$user_id') as total_likes,
                (SELECT COUNT(*) FROM saved_posts WHERE user_id = '$user_id') as total_saved";
$stats_result = mysqli_query($konek, $stats_query);
$stats = mysqli_fetch_assoc($stats_result);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Saya - BlogKu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .profile-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 60px 0 30px;
            margin-bottom: -50px;
            border-radius: 0 0 20px 20px;
            position: relative;
        }
        .profile-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
            overflow: hidden;
        }
        .profile-avatar {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            border: 5px solid white;
            object-fit: cover;
            margin-top: -75px;
            margin-bottom: 20px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
        }
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            color: #667eea;
            margin-bottom: 5px;
        }
        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        .nav-tabs .nav-link {
            border: none;
            color: #6c757d;
            font-weight: 500;
            padding: 12px 20px;
        }
        .nav-tabs .nav-link.active {
            color: #667eea;
            border-bottom: 3px solid #667eea;
            background: transparent;
        }
        .form-control:focus {
            border-color: #764ba2;
            box-shadow: 0 0 0 0.25rem rgba(118, 75, 162, 0.25);
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 10px 30px;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }
        .profile-info {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
        }
        .info-item {
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        .info-item:last-child {
            border-bottom: none;
        }
        .info-label {
            font-weight: 600;
            color: #333;
            min-width: 120px;
            display: inline-block;
        }
        .info-value {
            color: #666;
        }
        .avatar-upload {
            position: relative;
            display: inline-block;
        }
        .avatar-edit {
            position: absolute;
            right: 10px;
            bottom: 10px;
            z-index: 1;
        }
        .avatar-edit input {
            display: none;
        }
        .avatar-edit label {
            width: 40px;
            height: 40px;
            background: #667eea;
            border: 3px solid white;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            transition: all 0.3s;
        }
        .avatar-edit label:hover {
            background: #764ba2;
            transform: scale(1.1);
        }
        .tab-content {
            padding: 30px 0;
        }
        .member-since {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 10px 20px;
            border-radius: 10px;
            margin-top: 20px;
        }
        .social-links a {
            color: #667eea;
            margin-right: 15px;
            font-size: 1.2rem;
            transition: color 0.3s;
        }
        .social-links a:hover {
            color: #764ba2;
        }
        .activity-item {
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        .activity-item:last-child {
            border-bottom: none;
        }
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #667eea;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
        }
    </style>
</head>
<body>
    <?php include '../includes/user_navbar.php'; ?>
    
    <!-- Profile Header -->
    <div class="profile-header">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto text-center">
                    <h1 class="mb-0">Profile Saya</h1>
                    <p class="lead">Kelola informasi akun dan preferensi Anda</p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="container mt-5 mb-5">
        <!-- Pesan Notifikasi -->
        <?php if ($message): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle"></i> <?php echo $message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle"></i> <?php echo $error; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <!-- Sidebar Profil -->
            <div class="col-lg-4 mb-4">
                <div class="profile-card text-center p-4">
                    <!-- Avatar -->
                    <div class="avatar-upload">
                        <?php if ($user['profile_image']): ?>
                            <img src="../uploads/profiles/<?php echo $user['profile_image']; ?>" 
                                 class="profile-avatar" 
                                 alt="<?php echo htmlspecialchars($user['full_name']); ?>"
                                 id="profileAvatar">
                        <?php else: ?>
                            <div class="profile-avatar bg-secondary d-flex align-items-center justify-content-center mx-auto"
                                 style="font-size: 3rem; color: white;">
                                <?php echo strtoupper(substr($user['full_name'], 0, 1)); ?>
                            </div>
                        <?php endif; ?>
                        
                        <div class="avatar-edit">
                            <input type="file" id="avatarInput" name="profile_image" 
                                   accept="image/*" form="profileForm">
                            <label for="avatarInput" title="Ubah foto">
                                <i class="bi bi-camera"></i>
                            </label>
                        </div>
                    </div>
                    
                    <!-- Nama User -->
                    <h3 class="mb-2"><?php echo htmlspecialchars($user['full_name']); ?></h3>
                    <p class="text-muted mb-3">
                        <i class="bi bi-at"></i> <?php echo htmlspecialchars($user['username']); ?>
                    </p>
                    
                    <!-- Statistik -->
                    <div class="row mt-4">
                        <div class="col-4">
                            <div class="stat-card">
                                <div class="stat-number"><?php echo $stats['total_comments']; ?></div>
                                <div class="stat-label">Komentar</div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="stat-card">
                                <div class="stat-number"><?php echo $stats['total_likes']; ?></div>
                                <div class="stat-label">Suka</div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="stat-card">
                                <div class="stat-number"><?php echo $stats['total_saved']; ?></div>
                                <div class="stat-label">Tersimpan</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Member Since -->
                    <div class="member-since">
                        <i class="bi bi-calendar-check"></i> Member sejak 
                        <?php echo date('F Y', strtotime($user['created_at'])); ?>
                    </div>
                    
                    <!-- Quick Actions -->
                    <div class="mt-4">
                        <a href="change_password.php" class="btn btn-outline-primary btn-sm w-100 mb-2">
                            <i class="bi bi-key"></i> Ubah Password
                        </a>
                        <a href="dashboard.php" class="btn btn-outline-secondary btn-sm w-100">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                    </div>
                </div>
                
                <!-- Info Profil -->
                <div class="profile-info">
                    <h5><i class="bi bi-info-circle"></i> Informasi Profil</h5>
                    <div class="info-item">
                        <span class="info-label">Username:</span>
                        <span class="info-value"><?php echo htmlspecialchars($user['username']); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label">Email:</span>
                        <span class="info-value"><?php echo htmlspecialchars($user['email']); ?></span>
                    </div>
                    <?php if (!empty($user['location'])): ?>
                        <div class="info-item">
                            <span class="info-label">Lokasi:</span>
                            <span class="info-value"><?php echo htmlspecialchars($user['location']); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if (!empty($user['website'])): ?>
                        <div class="info-item">
                            <span class="info-label">Website:</span>
                            <span class="info-value">
                                <a href="<?php echo htmlspecialchars($user['website']); ?>" target="_blank">
                                    <?php echo htmlspecialchars($user['website']); ?>
                                </a>
                            </span>
                        </div>
                    <?php endif; ?>
                    <div class="info-item">
                        <span class="info-label">Terakhir diupdate:</span>
                        <span class="info-value">
                            <?php echo date('d/m/Y H:i', strtotime($user['updated_at'])); ?>
                        </span>
                    </div>
                </div>
            </div>
            
            <!-- Main Content -->
            <div class="col-lg-8">
                <div class="profile-card p-4">
                    <!-- Tabs -->
                    <ul class="nav nav-tabs" id="profileTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="edit-tab" data-bs-toggle="tab" 
                                    data-bs-target="#edit" type="button" role="tab">
                                <i class="bi bi-pencil"></i> Edit Profil
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="activity-tab" data-bs-toggle="tab" 
                                    data-bs-target="#activity" type="button" role="tab">
                                <i class="bi bi-clock-history"></i> Aktivitas Terbaru
                            </button>
                        </li>
                    </ul>
                    
                    <!-- Tab Content -->
                    <div class="tab-content" id="profileTabContent">
                        <!-- Tab 1: Edit Profil -->
                        <div class="tab-pane fade show active" id="edit" role="tabpanel">
                            <form method="POST" action="" enctype="multipart/form-data" id="profileForm">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="full_name" class="form-label">
                                            <i class="bi bi-person"></i> Nama Lengkap
                                        </label>
                                        <input type="text" class="form-control" id="full_name" 
                                               name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" 
                                               required>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="email" class="form-label">
                                            <i class="bi bi-envelope"></i> Email
                                        </label>
                                        <input type="email" class="form-control" id="email" 
                                               name="email" value="<?php echo htmlspecialchars($user['email']); ?>" 
                                               required>
                                        <div class="form-text">Email akan digunakan untuk notifikasi</div>
                                    </div>
                                    
                                    <div class="col-12 mb-3">
                                        <label for="bio" class="form-label">
                                            <i class="bi bi-card-text"></i> Bio (Optional)
                                        </label>
                                        <textarea class="form-control" id="bio" name="bio" 
                                                  rows="3" maxlength="200"><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                                        <div class="form-text">
                                            Maksimal 200 karakter. 
                                            <span id="bioCount">0/200</span>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="website" class="form-label">
                                            <i class="bi bi-globe"></i> Website (Optional)
                                        </label>
                                        <input type="url" class="form-control" id="website" 
                                               name="website" value="<?php echo htmlspecialchars($user['website'] ?? ''); ?>">
                                        <div class="form-text">Contoh: https://websiteanda.com</div>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="location" class="form-label">
                                            <i class="bi bi-geo-alt"></i> Lokasi (Optional)
                                        </label>
                                        <input type="text" class="form-control" id="location" 
                                               name="location" value="<?php echo htmlspecialchars($user['location'] ?? ''); ?>">
                                        <div class="form-text">Contoh: Jakarta, Indonesia</div>
                                    </div>
                                    
                                    <div class="col-12 mb-4">
                                        <label class="form-label">
                                            <i class="bi bi-image"></i> Foto Profil
                                        </label>
                                        <div class="input-group">
                                            <input type="file" class="form-control" 
                                                   name="profile_image" accept="image/*"
                                                   id="profileImageInput">
                                            <span class="input-group-text">
                                                <i class="bi bi-upload"></i>
                                            </span>
                                        </div>
                                        <div class="form-text">
                                            Ukuran maksimal 2MB. Format: JPG, PNG, GIF
                                        </div>
                                        
                                        <!-- Image Preview -->
                                        <div class="mt-3" id="imagePreview" style="display: none;">
                                            <h6>Preview:</h6>
                                            <img id="previewImage" class="img-thumbnail" 
                                                 style="max-width: 200px; max-height: 200px;">
                                        </div>
                                    </div>
                                    
                                    <div class="col-12">
                                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                            <button type="reset" class="btn btn-secondary me-md-2">
                                                <i class="bi bi-arrow-clockwise"></i> Reset
                                            </button>
                                            <button type="submit" class="btn btn-primary">
                                                <i class="bi bi-save"></i> Simpan Perubahan
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        
                        <!-- Tab 2: Aktivitas -->
                        <div class="tab-pane fade" id="activity" role="tabpanel">
                            <h5>Aktivitas Terbaru</h5>
                            
                            <?php
                            // Ambil aktivitas terbaru user
                            $activity_query = "(
                                SELECT 'comment' as type, c.content, a.title, a.slug, c.created_at 
                                FROM comments c 
                                JOIN articles a ON c.article_id = a.id 
                                WHERE c.user_id = '$user_id' 
                                ORDER BY c.created_at DESC LIMIT 5
                            ) UNION (
                                SELECT 'like' as type, NULL as content, a.title, a.slug, al.created_at 
                                FROM article_likes al 
                                JOIN articles a ON al.article_id = a.id 
                                WHERE al.user_id = '$user_id' 
                                ORDER BY al.created_at DESC LIMIT 5
                            ) UNION (
                                SELECT 'save' as type, NULL as content, a.title, a.slug, sp.created_at 
                                FROM saved_posts sp 
                                JOIN articles a ON sp.article_id = a.id 
                                WHERE sp.user_id = '$user_id' 
                                ORDER BY sp.created_at DESC LIMIT 5
                            ) ORDER BY created_at DESC LIMIT 10";
                            
                            $activity_result = mysqli_query($konek, $activity_query);
                            
                            if (mysqli_num_rows($activity_result) > 0):
                                while ($activity = mysqli_fetch_assoc($activity)):
                            ?>
                                <div class="activity-item d-flex align-items-center">
                                    <div class="activity-icon">
                                        <?php if ($activity['type'] == 'comment'): ?>
                                            <i class="bi bi-chat-left-text"></i>
                                        <?php elseif ($activity['type'] == 'like'): ?>
                                            <i class="bi bi-heart"></i>
                                        <?php else: ?>
                                            <i class="bi bi-bookmark"></i>
                                        <?php endif; ?>
                                    </div>
                                    <div class="flex-grow-1">
                                        <div class="d-flex justify-content-between">
                                            <h6 class="mb-1">
                                                <a href="../post.php?slug=<?php echo $activity['slug']; ?>" 
                                                   class="text-decoration-none">
                                                    <?php echo htmlspecialchars($activity['title']); ?>
                                                </a>
                                            </h6>
                                            <small class="text-muted">
                                                <?php echo date('d M', strtotime($activity['created_at'])); ?>
                                            </small>
                                        </div>
                                        <p class="mb-1 small text-muted">
                                            <?php if ($activity['type'] == 'comment'): ?>
                                                <i class="bi bi-chat-left-text"></i> 
                                                <?php echo substr($activity['content'], 0, 80); ?>...
                                            <?php elseif ($activity['type'] == 'like'): ?>
                                                <i class="bi bi-heart-fill text-danger"></i> Menyukai artikel
                                            <?php else: ?>
                                                <i class="bi bi-bookmark-fill text-warning"></i> Menyimpan artikel
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                </div>
                            <?php 
                                endwhile;
                            else:
                            ?>
                                <div class="text-center py-4">
                                    <i class="bi bi-activity" style="font-size: 3rem; color: #dee2e6;"></i>
                                    <p class="mt-3 text-muted">Belum ada aktivitas</p>
                                </div>
                            <?php endif; ?>
                            
                            <!-- View More -->
                            <div class="text-center mt-3">
                                <a href="dashboard.php" class="btn btn-outline-primary btn-sm">
                                    <i class="bi bi-eye"></i> Lihat Semua Aktivitas
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Keamanan Akun -->
                <div class="profile-card p-4 mt-4">
                    <h5><i class="bi bi-shield-check"></i> Keamanan Akun</h5>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="alert alert-info">
                                <h6><i class="bi bi-info-circle"></i> Tips Keamanan:</h6>
                                <ul class="mb-0 small">
                                    <li>Gunakan password yang kuat</li>
                                    <li>Jangan bagikan informasi login</li>
                                    <li>Ganti password secara berkala</li>
                                    <li>Periksa aktivitas mencurigakan</li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="d-grid gap-2">
                                <a href="change_password.php" class="btn btn-outline-primary">
                                    <i class="bi bi-key"></i> Ubah Password
                                </a>
                                <button class="btn btn-outline-danger" 
                                        onclick="confirm('Apakah Anda yakin?') ? window.location='delete_account.php' : null">
                                    <i class="bi bi-trash"></i> Hapus Akun
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Character counter for bio
        const bioTextarea = document.getElementById('bio');
        const bioCount = document.getElementById('bioCount');
        
        function updateBioCount() {
            const length = bioTextarea.value.length;
            bioCount.textContent = length + '/200';
            
            if (length > 180) {
                bioCount.className = 'text-warning';
            } else {
                bioCount.className = 'text-muted';
            }
        }
        
        // Initialize
        updateBioCount();
        bioTextarea.addEventListener('input', updateBioCount);
        
        // Image preview
        const profileImageInput = document.getElementById('profileImageInput');
        const previewImage = document.getElementById('previewImage');
        const imagePreview = document.getElementById('imagePreview');
        const profileAvatar = document.getElementById('profileAvatar');
        
        profileImageInput.addEventListener('change', function() {
            const file = this.files[0];
            
            if (file) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    previewImage.src = e.target.result;
                    imagePreview.style.display = 'block';
                    
                    // Also update profile avatar preview
                    if (profileAvatar) {
                        profileAvatar.src = e.target.result;
                    }
                }
                
                reader.readAsDataURL(file);
            } else {
                imagePreview.style.display = 'none';
            }
        });
        
        // Avatar upload preview
        const avatarInput = document.getElementById('avatarInput');
        avatarInput.addEventListener('change', function() {
            const file = this.files[0];
            
            if (file) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    if (profileAvatar) {
                        profileAvatar.src = e.target.result;
                    }
                    
                    // Also update file input
                    const dataTransfer = new DataTransfer();
                    dataTransfer.items.add(file);
                    profileImageInput.files = dataTransfer.files;
                }
                
                reader.readAsDataURL(file);
            }
        });
        
        // Form validation
        document.getElementById('profileForm').addEventListener('submit', function(e) {
            const email = document.getElementById('email').value;
            const website = document.getElementById('website').value;
            const profileImage = profileImageInput.files[0];
            
            // Email validation
            if (!validateEmail(email)) {
                e.preventDefault();
                alert('Format email tidak valid!');
                return;
            }
            
            // Website validation (if not empty)
            if (website && !website.startsWith('http://') && !website.startsWith('https://')) {
                e.preventDefault();
                alert('Website harus dimulai dengan http:// atau https://');
                return;
            }
            
            // File size validation
            if (profileImage) {
                if (profileImage.size > 2 * 1024 * 1024) {
                    e.preventDefault();
                    alert('Ukuran file maksimal 2MB!');
                    return;
                }
                
                const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
                if (!allowedTypes.includes(profileImage.type)) {
                    e.preventDefault();
                    alert('Hanya file JPG, JPEG, PNG, dan GIF yang diizinkan!');
                    return;
                }
            }
        });
        
        function validateEmail(email) {
            const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }
        
        // Auto save draft (optional)
        let draftTimeout;
        const formFields = document.querySelectorAll('#profileForm input, #profileForm textarea');
        
        formFields.forEach(field => {
            field.addEventListener('input', function() {
                clearTimeout(draftTimeout);
                
                draftTimeout = setTimeout(() => {
                    // Save to localStorage as draft
                    const formData = {};
                    formFields.forEach(f => {
                        if (f.name) {
                            formData[f.name] = f.value;
                        }
                    });
                    
                    localStorage.setItem('profileDraft', JSON.stringify(formData));
                    console.log('Draft saved');
                }, 2000);
            });
        });
        
        // Load draft on page load
        document.addEventListener('DOMContentLoaded', function() {
            const draft = localStorage.getItem('profileDraft');
            if (draft) {
                if (confirm('Ada draft yang belum disimpan. Muat draft?')) {
                    const formData = JSON.parse(draft);
                    
                    formFields.forEach(field => {
                        if (field.name && formData[field.name] !== undefined) {
                            field.value = formData[field.name];
                        }
                    });
                    
                    updateBioCount();
                }
                
                localStorage.removeItem('profileDraft');
            }
        });
        
        // Clear draft on successful submit
        document.getElementById('profileForm').addEventListener('submit', function() {
            localStorage.removeItem('profileDraft');
        });
    </script>
</body>
</html>