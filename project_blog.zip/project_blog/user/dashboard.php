<?php
session_start();
require_once '../config/database.php';

// Cek jika belum login, redirect ke login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Ambil data user
$user_query = mysqli_query($konek, "SELECT * FROM users WHERE id = $user_id");
$user = mysqli_fetch_assoc($user_query);

// Hitung statistik user
$total_comments = mysqli_fetch_assoc(mysqli_query($konek, 
    "SELECT COUNT(*) as total FROM comments WHERE user_id = $user_id"))['total'];

$total_likes = mysqli_fetch_assoc(mysqli_query($konek, 
    "SELECT COUNT(*) as total FROM article_likes WHERE user_id = $user_id"))['total'];

// Ambil artikel favorit user
$favorite_articles = mysqli_query($konek, 
    "SELECT a.* FROM articles a 
     JOIN article_likes al ON a.id = al.article_id 
     WHERE al.user_id = $user_id AND a.is_published = 1 
     ORDER BY al.created_at DESC LIMIT 5");

// Ambil komentar terbaru user
$recent_comments = mysqli_query($konek, 
    "SELECT c.*, a.title as article_title FROM comments c 
     JOIN articles a ON c.article_id = a.id 
     WHERE c.user_id = $user_id 
     ORDER BY c.created_at DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard User - Blog</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background: #f8f9fa;
            color: #333;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: #667eea;
            font-weight: bold;
        }
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        .welcome-section {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            font-size: 40px;
            margin-bottom: 10px;
            color: #667eea;
        }
        .stat-number {
            font-size: 32px;
            font-weight: bold;
            color: #333;
            margin: 10px 0;
        }
        .sections {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
        }
        .section-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
        }
        .section-title {
            color: #333;
            margin-top: 0;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }
        .article-list, .comment-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .article-item, .comment-item {
            padding: 15px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .article-item:last-child, .comment-item:last-child {
            border-bottom: none;
        }
        .article-title, .comment-article {
            font-weight: 600;
            color: #333;
            text-decoration: none;
            display: block;
            margin-bottom: 5px;
        }
        .article-title:hover, .comment-article:hover {
            color: #667eea;
        }
        .comment-content {
            color: #666;
            font-size: 14px;
            margin: 5px 0;
        }
        .comment-date {
            color: #999;
            font-size: 12px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 500;
            transition: transform 0.2s;
        }
        .btn:hover {
            transform: translateY(-2px);
            color: white;
        }
        .btn-logout {
            background: #f5576c;
            margin-left: 10px;
        }
        .empty-state {
            text-align: center;
            color: #999;
            padding: 40px 0;
        }
        .nav-links {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }
        @media (max-width: 768px) {
            .sections {
                grid-template-columns: 1fr;
            }
            .header {
                flex-direction: column;
                text-align: center;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div>
            <h1>Dashboard Member</h1>
            <p>Blog Community</p>
        </div>
        <div class="user-info">
            <div class="avatar">
                <?php echo strtoupper(substr($user['username'], 0, 1)); ?>
            </div>
            <div>
                <strong><?php echo $user['full_name'] ?: $user['username']; ?></strong>
                <p style="margin: 5px 0 0 0; font-size: 14px;">@<?php echo $user['username']; ?></p>
            </div>
            <a href="logout.php" class="btn btn-logout">Logout</a>
        </div>
    </div>
    
    <div class="container">
        <div class="welcome-section">
            <h2>Halo, <?php echo $user['full_name'] ?: $user['username']; ?>! 👋</h2>
            <p>Selamat datang di dashboard anggota blog kami. Berikut adalah aktivitas dan statistik Anda.</p>
            
            <div class="nav-links">
                <a href="../public/index.php" class="btn">Baca Artikel</a>
                <a href="../public/article.php" class="btn">Semua Artikel</a>
                <a href="#" class="btn">Edit Profil</a>
            </div>
        </div>
        
        <div class="stats">
            <div class="stat-card">
                <div class="stat-icon">📝</div>
                <div class="stat-number"><?php echo $total_comments; ?></div>
                <h3>Total Komentar</h3>
                <p>Komentar yang Anda tulis</p>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">❤️</div>
                <div class="stat-number"><?php echo $total_likes; ?></div>
                <h3>Artikel Disukai</h3>
                <p>Artikel yang Anda sukai</p>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">👤</div>
                <div class="stat-number">1</div>
                <h3>Akun Anda</h3>
                <p>Bergabung sejak: <?php echo date('d M Y', strtotime($user['created_at'])); ?></p>
            </div>
        </div>
        
        <div class="sections">
            <div class="section-card">
                <h3 class="section-title">Artikel Favorit Anda</h3>
                <?php if (mysqli_num_rows($favorite_articles) > 0): ?>
                    <ul class="article-list">
                        <?php while ($article = mysqli_fetch_assoc($favorite_articles)): ?>
                            <li class="article-item">
                                <a href="../public/post.php?id=<?php echo $article['id']; ?>" class="article-title">
                                    <?php echo htmlspecialchars($article['title']); ?>
                                </a>
                                <div style="font-size: 12px; color: #666;">
                                    <?php echo date('d M Y', strtotime($article['created_at'])); ?> • 
                                    <?php echo $article['view_count']; ?> views
                                </div>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                <?php else: ?>
                    <div class="empty-state">
                        <p>Anda belum menyukai artikel apapun</p>
                        <a href="../public/article.php" class="btn" style="margin-top: 10px;">Jelajahi Artikel</a>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="section-card">
                <h3 class="section-title">Komentar Terbaru</h3>
                <?php if (mysqli_num_rows($recent_comments) > 0): ?>
                    <ul class="comment-list">
                        <?php while ($comment = mysqli_fetch_assoc($recent_comments)): ?>
                            <li class="comment-item">
                                <a href="../public/post.php?id=<?php echo $comment['article_id']; ?>" class="comment-article">
                                    <?php echo htmlspecialchars($comment['article_title']); ?>
                                </a>
                                <div class="comment-content">
                                    <?php echo substr(htmlspecialchars($comment['content']), 0, 100); ?>...
                                </div>
                                <div class="comment-date">
                                    <?php echo date('d M Y H:i', strtotime($comment['created_at'])); ?>
                                    <?php if ($comment['is_approved']): ?>
                                        <span style="color: #28a745; margin-left: 10px;">✓ Disetujui</span>
                                    <?php else: ?>
                                        <span style="color: #ffc107; margin-left: 10px;">⏳ Menunggu</span>
                                    <?php endif; ?>
                                </div>
                            </li>
                        <?php endwhile; ?>
                    </ul>
                <?php else: ?>
                    <div class="empty-state">
                        <p>Anda belum menulis komentar</p>
                        <a href="../public/article.php" class="btn" style="margin-top: 10px;">Lihat Artikel</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>