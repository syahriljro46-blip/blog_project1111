<?php
session_start();
require_once '../config/database.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Cek apakah ada parameter comment_id
if (!isset($_GET['comment_id'])) {
    header('Location: my_comment.php');
    exit();
}

$comment_id = mysqli_real_escape_string($konek, $_GET['comment_id']);

// Verifikasi bahwa comment milik user yang login
$verify_query = "SELECT id FROM comments WHERE id = '$comment_id' AND user_id = '$user_id'";
$verify_result = mysqli_query($konek, $verify_query);

if (mysqli_num_rows($verify_result) == 0) {
    $_SESSION['error'] = "Komentar tidak ditemukan atau Anda tidak memiliki akses!";
    header('Location: my_comment.php');
    exit();
}

// Proses hapus komentar
if (isset($_GET['confirm']) && $_GET['confirm'] == 'yes') {
    // Hapus komentar
    $delete_query = "DELETE FROM comments WHERE id = '$comment_id'";
    
    if (mysqli_query($konek, $delete_query)) {
        $_SESSION['message'] = "Komentar berhasil dihapus!";
        
        // Update jumlah komentar di artikel (opsional)
        // $update_article = "UPDATE articles SET comment_count = comment_count - 1 WHERE id = (SELECT article_id FROM comments WHERE id = '$comment_id')";
        // mysqli_query($konek, $update_article);
        
        header('Location: my_comment.php');
        exit();
    } else {
        $_SESSION['error'] = "Gagal menghapus komentar: " . mysqli_error($konek);
        header('Location: my_comment.php');
        exit();
    }
}

// Ambil data komentar untuk konfirmasi
$comment_query = "SELECT c.*, a.title, a.slug 
                  FROM comments c 
                  JOIN articles a ON c.article_id = a.id 
                  WHERE c.id = '$comment_id' AND c.user_id = '$user_id'";
$comment_result = mysqli_query($onek, $comment_query);
$comment_data = mysqli_fetch_assoc($comment_result);

if (!$comment_data) {
    $_SESSION['error'] = "Komentar tidak ditemukan!";
    header('Location: my_comment.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hapus Komentar - BlogKu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
        }
        .confirmation-card {
            max-width: 600px;
            margin: 0 auto;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            border: none;
        }
        .confirmation-header {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a52 100%);
            color: white;
            border-radius: 15px 15px 0 0 !important;
            padding: 25px;
        }
        .comment-preview {
            background-color: #f8f9fa;
            border-left: 4px solid #dc3545;
            padding: 15px;
            border-radius: 5px;
            margin: 20px 0;
        }
        .article-link {
            color: #667eea;
            text-decoration: none;
        }
        .article-link:hover {
            text-decoration: underline;
        }
        .btn-danger {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a52 100%);
            border: none;
            padding: 10px 30px;
        }
        .btn-danger:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(255, 107, 107, 0.4);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card confirmation-card">
                    <div class="card-header confirmation-header text-center">
                        <h3><i class="bi bi-trash"></i> Hapus Komentar</h3>
                        <p class="mb-0">Konfirmasi penghapusan komentar</p>
                    </div>
                    <div class="card-body p-4">
                        <!-- Warning Alert -->
                        <div class="alert alert-warning" role="alert">
                            <h5 class="alert-heading"><i class="bi bi-exclamation-triangle"></i> Peringatan!</h5>
                            <p class="mb-0">Anda akan menghapus komentar Anda. Tindakan ini tidak dapat dibatalkan!</p>
                        </div>
                        
                        <!-- Informasi Komentar -->
                        <div class="mb-4">
                            <h5>Detail Komentar:</h5>
                            <p><strong>Artikel:</strong> 
                                <a href="../post.php?slug=<?php echo $comment_data['slug']; ?>" 
                                   class="article-link" target="_blank">
                                    <?php echo htmlspecialchars($comment_data['title']); ?>
                                </a>
                            </p>
                            <p><strong>Ditulis pada:</strong> 
                                <?php echo date('d F Y H:i', strtotime($comment_data['created_at'])); ?>
                            </p>
                        </div>
                        
                        <!-- Preview Komentar -->
                        <div class="comment-preview">
                            <h6><i class="bi bi-chat-text"></i> Isi Komentar:</h6>
                            <p class="mb-0"><?php echo nl2br(htmlspecialchars($comment_data['content'])); ?></p>
                        </div>
                        
                        <!-- Statistik Komentar -->
                        <?php
                        // Hitung total komentar user
                        $total_query = "SELECT COUNT(*) as total FROM comments WHERE user_id = '$user_id'";
                        $total_result = mysqli_query($konek, $total_query);
                        $total_data = mysqli_fetch_assoc($total_result);
                        ?>
                        <div class="alert alert-info">
                            <p class="mb-0">
                                <i class="bi bi-info-circle"></i> 
                                Setelah penghapusan ini, Anda akan memiliki 
                                <strong><?php echo $total_data['total'] - 1; ?></strong> 
                                komentar yang tersisa.
                            </p>
                        </div>
                        
                        <!-- Tombol Konfirmasi -->
                        <div class="d-grid gap-2 d-md-flex justify-content-md-center mt-4">
                            <a href="my_comment.php" class="btn btn-secondary me-md-2">
                                <i class="bi bi-x-circle"></i> Batal
                            </a>
                            <a href="delete_comment.php?comment_id=<?php echo $comment_id; ?>&confirm=yes" 
                               class="btn btn-danger">
                                <i class="bi bi-trash"></i> Ya, Hapus Komentar
                            </a>
                        </div>
                        
                        <!-- Tips -->
                        <div class="mt-4 p-3 bg-light border rounded">
                            <h6><i class="bi bi-lightbulb"></i> Tips:</h6>
                            <ul class="mb-0 small">
                                <li>Pertimbangkan untuk mengedit komentar jika hanya ada kesalahan kecil</li>
                                <li>Komentar yang dihapus tidak dapat dikembalikan</li>
                                <li>Komunitas menghargai kontribusi positif dan konstruktif</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>