<?php
session_start();
require_once '../config/database.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Pagination
$limit = 15; // Jumlah komentar per halaman
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Filter
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';

// Base query
$base_query = "SELECT c.*, 
                      a.title, 
                      a.slug,
                      a.featured_image,
                      cat.name as category_name,
                      COUNT(DISTINCT cm.id) as reply_count
               FROM comments c
               JOIN articles a ON c.article_id = a.id
               LEFT JOIN categories cat ON a.category_id = cat.id
               LEFT JOIN comments cm ON c.id = cm.parent_id
               WHERE c.user_id = '$user_id'";

// Apply filter
switch ($filter) {
    case 'approved':
        $base_query .= " AND c.is_approved = 1";
        break;
    case 'pending':
        $base_query .= " AND c.is_approved = 0";
        break;
    case 'recent':
        $base_query .= " ORDER BY c.created_at DESC";
        break;
    default:
        $base_query .= " ORDER BY c.created_at DESC";
}

// Hitung total komentar
$count_query = "SELECT COUNT(*) as total FROM comments WHERE user_id = '$user_id'";
$count_result = mysqli_query($konek, $count_query);
$count_data = mysqli_fetch_assoc($count_result);
$total_comments = $count_data['total'];
$total_pages = ceil($total_comments / $limit);

// Query dengan limit dan offset
$query = $base_query . " LIMIT $limit OFFSET $offset";
$result = mysqli_query($konek, $query);

// Hitung statistik
$stats_query = "SELECT 
                 SUM(CASE WHEN is_approved = 1 THEN 1 ELSE 0 END) as approved_count,
                 SUM(CASE WHEN is_approved = 0 THEN 1 ELSE 0 END) as pending_count
               FROM comments WHERE user_id = '$user_id'";
$stats_result = mysqli_query($konek, $stats_query);
$stats = mysqli_fetch_assoc($stats_result);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Komentar Saya - BlogKu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 60px 0;
            margin-bottom: 40px;
            border-radius: 0 0 20px 20px;
        }
        .comment-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            transition: transform 0.2s;
        }
        .comment-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
        }
        .status-badge {
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
        }
        .status-approved {
            background-color: #d4edda;
            color: #155724;
        }
        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }
        .article-link {
            color: #667eea;
            text-decoration: none;
            font-weight: 500;
        }
        .article-link:hover {
            text-decoration: underline;
            color: #764ba2;
        }
        .comment-content {
            max-height: 100px;
            overflow: hidden;
            position: relative;
        }
        .comment-content.expanded {
            max-height: none;
        }
        .read-more {
            color: #667eea;
            cursor: pointer;
            font-size: 0.9rem;
        }
        .action-buttons .btn {
            padding: 3px 8px;
            font-size: 0.85rem;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }
        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            color: #dee2e6;
        }
        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            color: #667eea;
        }
        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <?php include '../includes/user_navbar.php'; ?>
    
    <!-- Hero Section -->
    <div class="hero-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto text-center">
                    <h1><i class="bi bi-chat-left-text"></i> Komentar Saya</h1>
                    <p class="lead">Kelola dan tinjau semua komentar yang Anda tulis</p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="container mb-5">
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <!-- Statistik -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $total_comments; ?></div>
                    <div class="stat-label">Total Komentar</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $stats['approved_count'] ?? 0; ?></div>
                    <div class="stat-label">Disetujui</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $stats['pending_count'] ?? 0; ?></div>
                    <div class="stat-label">Menunggu</div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card">
                    <div class="stat-number">
                        <?php 
                        $avg_query = "SELECT AVG(LENGTH(content)) as avg_length FROM comments WHERE user_id = '$user_id'";
                        $avg_result = mysqli_query($konek, $avg_query);
                        $avg_data = mysqli_fetch_assoc($avg_result);
                        echo round($avg_data['avg_length'] ?? 0); 
                        ?>
                    </div>
                    <div class="stat-label">Rata-rata Karakter</div>
                </div>
            </div>
        </div>
        
        <!-- Filter -->
        <div class="card mb-4">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="btn-group" role="group">
                            <a href="?filter=all" class="btn <?php echo $filter == 'all' ? 'btn-primary' : 'btn-outline-primary'; ?>">
                                Semua
                            </a>
                            <a href="?filter=approved" class="btn <?php echo $filter == 'approved' ? 'btn-primary' : 'btn-outline-primary'; ?>">
                                Disetujui
                            </a>
                            <a href="?filter=pending" class="btn <?php echo $filter == 'pending' ? 'btn-primary' : 'btn-outline-primary'; ?>">
                                Menunggu
                            </a>
                            <a href="?filter=recent" class="btn <?php echo $filter == 'recent' ? 'btn-primary' : 'btn-outline-primary'; ?>">
                                Terbaru
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6 text-end">
                        <div class="input-group" style="max-width: 300px; float: right;">
                            <input type="text" class="form-control" placeholder="Cari komentar..." id="searchComments">
                            <button class="btn btn-primary" type="button">
                                <i class="bi bi-search"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Daftar Komentar -->
        <div id="commentsContainer">
            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php while ($comment = mysqli_fetch_assoc($result)): ?>
                    <div class="card comment-card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-8">
                                    <!-- Artikel Info -->
                                    <h6 class="mb-2">
                                        <a href="../post.php?slug=<?php echo $comment['slug']; ?>" 
                                           class="article-link" target="_blank">
                                            <i class="bi bi-file-text"></i> 
                                            <?php echo htmlspecialchars($comment['title']); ?>
                                        </a>
                                        <?php if ($comment['category_name']): ?>
                                            <small class="text-muted ms-2">
                                                <i class="bi bi-folder"></i> <?php echo $comment['category_name']; ?>
                                            </small>
                                        <?php endif; ?>
                                    </h6>
                                    
                                    <!-- Status & Tanggal -->
                                    <div class="d-flex align-items-center mb-3">
                                        <span class="status-badge <?php echo $comment['is_approved'] ? 'status-approved' : 'status-pending'; ?> me-2">
                                            <?php echo $comment['is_approved'] ? '✓ Disetujui' : '⏳ Menunggu'; ?>
                                        </span>
                                        <small class="text-muted">
                                            <i class="bi bi-clock"></i> 
                                            <?php echo date('d F Y H:i', strtotime($comment['created_at'])); ?>
                                        </small>
                                        <?php if ($comment['parent_id']): ?>
                                            <small class="text-muted ms-2">
                                                <i class="bi bi-reply"></i> Balasan
                                            </small>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <!-- Isi Komentar -->
                                    <div class="comment-content mb-3" id="comment-<?php echo $comment['id']; ?>">
                                        <?php echo nl2br(htmlspecialchars($comment['content'])); ?>
                                    </div>
                                    
                                    <?php if (strlen($comment['content']) > 200): ?>
                                        <a href="#" class="read-more" 
                                           onclick="toggleExpand('<?php echo $comment['id']; ?>')">
                                            Baca selengkapnya...
                                        </a>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="col-md-4 text-end">
                                    <!-- Action Buttons -->
                                    <div class="action-buttons mb-3">
                                        <a href="update_comment.php?comment_id=<?php echo $comment['id']; ?>" 
                                           class="btn btn-sm btn-outline-primary me-1">
                                            <i class="bi bi-pencil"></i> Edit
                                        </a>
                                        <a href="delete_comment.php?comment_id=<?php echo $comment['id']; ?>" 
                                           class="btn btn-sm btn-outline-danger"
                                           onclick="return confirm('Hapus komentar ini?')">
                                            <i class="bi bi-trash"></i> Hapus
                                        </a>
                                    </div>
                                    
                                    <!-- Info Tambahan -->
                                    <div class="small text-muted">
                                        <?php if ($comment['reply_count'] > 0): ?>
                                            <div class="mb-1">
                                                <i class="bi bi-reply-all"></i> 
                                                <?php echo $comment['reply_count']; ?> balasan
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if ($comment['updated_at'] != $comment['created_at']): ?>
                                            <div>
                                                <i class="bi bi-arrow-clockwise"></i> 
                                                Diperbarui: <?php echo date('d/m/Y', strtotime($comment['updated_at'])); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <!-- Empty State -->
                <div class="card">
                    <div class="card-body text-center py-5">
                        <i class="bi bi-chat-left-text" style="font-size: 4rem; color: #dee2e6;"></i>
                        <h3 class="mt-3">Belum Ada Komentar</h3>
                        <p class="text-muted mb-4">Anda belum menulis komentar apapun.</p>
                        <a href="../article.php" class="btn btn-primary">
                            <i class="bi bi-file-text"></i> Baca Artikel
                        </a>
                        <a href="../blog.php" class="btn btn-outline-primary ms-2">
                            <i class="bi bi-pencil"></i> Tulis Komentar
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <nav aria-label="Page navigation" class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>&filter=<?php echo $filter; ?>">
                                <i class="bi bi-chevron-left"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                    
                    <?php 
                    $start = max(1, $page - 2);
                    $end = min($total_pages, $page + 2);
                    
                    for ($i = $start; $i <= $end; $i++): ?>
                        <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>&filter=<?php echo $filter; ?>">
                                <?php echo $i; ?>
                            </a>
                        </li>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>&filter=<?php echo $filter; ?>">
                                <i class="bi bi-chevron-right"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        <?php endif; ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle expand/collapse comment
        function toggleExpand(commentId) {
            const content = document.getElementById('comment-' + commentId);
            const link = content.nextElementSibling;
            
            content.classList.toggle('expanded');
            
            if (content.classList.contains('expanded')) {
                link.textContent = 'Tampilkan lebih sedikit';
            } else {
                link.textContent = 'Baca selengkapnya...';
            }
        }
        
        // Search functionality
        document.getElementById('searchComments').addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const comments = document.querySelectorAll('.comment-card');
            
            comments.forEach(comment => {
                const content = comment.querySelector('.comment-content').textContent.toLowerCase();
                const title = comment.querySelector('.article-link').textContent.toLowerCase();
                
                if (content.includes(searchTerm) || title.includes(searchTerm)) {
                    comment.style.display = 'block';
                } else {
                    comment.style.display = 'none';
                }
            });
        });
        
        // Auto-expand comments on search
        document.getElementById('searchComments').addEventListener('input', function(e) {
            if (e.target.value.length > 0) {
                document.querySelectorAll('.comment-content').forEach(content => {
                    content.classList.add('expanded');
                    const link = content.nextElementSibling;
                    if (link && link.classList.contains('read-more')) {
                        link.textContent = 'Tampilkan lebih sedikit';
                    }
                });
            }
        });
    </script>
</body>
</html>