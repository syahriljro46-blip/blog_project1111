<?php
session_start();
require_once '../config/database.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['success' => false, 'message' => 'Silakan login terlebih dahulu']);
    exit();
}

// Cek apakah request adalah POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('HTTP/1.1 405 Method Not Allowed');
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan']);
    exit();
}

// Validasi input
if (!isset($_POST['article_id']) || empty($_POST['article_id'])) {
    echo json_encode(['success' => false, 'message' => 'ID artikel tidak valid']);
    exit();
}

$user_id = $_SESSION['user_id'];
$article_id = mysqli_real_escape_string($konek, $_POST['article_id']);

// Hapus like
$delete_query = "DELETE FROM article_likes WHERE user_id = '$user_id' AND article_id = '$article_id'";

if (mysqli_query($konek, $delete_query)) {
    // Update like count di artikel
    $update_query = "UPDATE articles SET view_count = view_count - 1 WHERE id = '$article_id'";
    mysqli_query($konek, $update_query);
    
    echo json_encode([
        'success' => true, 
        'message' => 'Artikel berhasil dihapus dari daftar suka'
    ]);
} else {
    echo json_encode([
        'success' => false, 
        'message' => 'Gagal menghapus like: ' . mysqli_error($konek)
    ]);
}
?>