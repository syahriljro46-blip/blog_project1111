<?php
session_start();
require_once '../config/database.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Pagination
$limit = 10; // Jumlah artikel per halaman
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Hitung total artikel yang disukai
$total_query = "SELECT COUNT(*) as total 
                FROM article_likes al 
                JOIN articles a ON al.article_id = a.id 
                WHERE al.user_id = '$user_id' AND a.is_published = 1";
$total_result = mysqli_query($konek, $total_query);
$total_data = mysqli_fetch_assoc($total_result);
$total_articles = $total_data['total'];
$total_pages = ceil($total_articles / $limit);

// Ambil artikel yang disukai
$query = "SELECT a.*, 
                 c.name as category_name,
                 c.slug as category_slug,
                 ad.username as author_name,
                 COUNT(DISTINCT al2.id) as like_count,
                 COUNT(DISTINCT cm.id) as comment_count
          FROM article_likes al
          JOIN articles a ON al.article_id = a.id
          LEFT JOIN categories c ON a.category_id = c.id
          LEFT JOIN admins ad ON a.author_id = ad.id
          LEFT JOIN article_likes al2 ON a.id = al2.article_id
          LEFT JOIN comments cm ON a.id = cm.article_id AND cm.is_approved = 1
          WHERE al.user_id = '$user_id' 
            AND a.is_published = 1
            AND a.published_at IS NOT NULL
          GROUP BY a.id
          ORDER BY al.created_at DESC
          LIMIT $limit OFFSET $offset";

$result = mysqli_query($konek, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Artikel yang Disukai - BlogKu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 60px 0;
            margin-bottom: 40px;
            border-radius: 0 0 20px 20px;
        }
        .article-card {
            border: none;
            border-radius: 15px;
            overflow: hidden;
            transition: transform 0.3s, box-shadow 0.3s;
            margin-bottom: 25px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .article-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0, 0, 0, 0.2);
        }
        .article-image {
            height: 200px;
            object-fit: cover;
            width: 100%;
        }
        .article-meta {
            color: #6c757d;
            font-size: 0.9rem;
        }
        .category-badge {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            text-decoration: none;
            display: inline-block;
            margin-bottom: 10px;
        }
        .like-btn {
            color: #dc3545;
            cursor: pointer;
        }
        .like-btn:hover {
            color: #c82333;
        }
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6c757d;
        }
        .empty-state i {
            font-size: 4rem;
            margin-bottom: 20px;
            color: #dee2e6;
        }
        .pagination .page-item.active .page-link {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-color: #667eea;
        }
    </style>
</head>
<body>
    <?php include '../includes/user_navbar.php'; ?>
    
    <!-- Hero Section -->
    <div class="hero-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto text-center">
                    <h1><i class="bi bi-heart-fill"></i> Artikel yang Disukai</h1>
                    <p class="lead">Kumpulan artikel yang telah Anda tandai sebagai favorit</p>
                    <div class="stats">
                        <span class="badge bg-light text-dark me-2">
                            <i class="bi bi-heart"></i> <?php echo $total_articles; ?> Artikel
                        </span>
                        <span class="badge bg-light text-dark">
                            <i class="bi bi-clock"></i> Terakhir diakses: <?php echo date('d/m/Y'); ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="container mb-5">
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <!-- Filter dan Sort -->
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="btn-group" role="group">
                    <a href="liked_post.php?sort=recent" class="btn btn-outline-primary">
                        <i class="bi bi-clock"></i> Terbaru
                    </a>
                    <a href="liked_post.php?sort=popular" class="btn btn-outline-primary">
                        <i class="bi bi-fire"></i> Populer
                    </a>
                </div>
            </div>
            <div class="col-md-6 text-end">
                <div class="input-group" style="max-width: 300px; float: right;">
                    <input type="text" class="form-control" placeholder="Cari artikel..." id="searchInput">
                    <button class="btn btn-primary" type="button">
                        <i class="bi bi-search"></i>
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Daftar Artikel -->
        <div class="row" id="articlesContainer">
            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php while ($article = mysqli_fetch_assoc($result)): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card article-card">
                            <?php if ($article['featured_image']): ?>
                                <img src="../uploads/<?php echo $article['featured_image']; ?>" 
                                     class="article-image" 
                                     alt="<?php echo htmlspecialchars($article['title']); ?>">
                            <?php else: ?>
                                <div class="article-image bg-secondary d-flex align-items-center justify-content-center">
                                    <i class="bi bi-image text-white" style="font-size: 3rem;"></i>
                                </div>
                            <?php endif; ?>
                            
                            <div class="card-body">
                                <?php if ($article['category_name']): ?>
                                    <a href="../blog.php?category=<?php echo $article['category_slug']; ?>" 
                                       class="category-badge">
                                        <?php echo $article['category_name']; ?>
                                    </a>
                                <?php endif; ?>
                                
                                <h5 class="card-title">
                                    <a href="../post.php?slug=<?php echo $article['slug']; ?>" 
                                       class="text-dark text-decoration-none">
                                        <?php echo htmlspecialchars($article['title']); ?>
                                    </a>
                                </h5>
                                
                                <p class="card-text text-muted">
                                    <?php echo substr(strip_tags($article['excerpt'] ?: $article['content']), 0, 100); ?>...
                                </p>
                                
                                <div class="article-meta d-flex justify-content-between align-items-center">
                                    <div>
                                        <small>
                                            <i class="bi bi-person"></i> <?php echo $article['author_name']; ?>
                                        </small>
                                        <small class="ms-2">
                                            <i class="bi bi-calendar"></i> 
                                            <?php echo date('d M Y', strtotime($article['created_at'])); ?>
                                        </small>
                                    </div>
                                    <div>
                                        <small class="me-2">
                                            <i class="bi bi-heart"></i> <?php echo $article['like_count']; ?>
                                        </small>
                                        <small>
                                            <i class="bi bi-chat"></i> <?php echo $article['comment_count']; ?>
                                        </small>
                                    </div>
                                </div>
                                
                                <div class="mt-3">
                                    <a href="../post.php?slug=<?php echo $article['slug']; ?>" 
                                       class="btn btn-sm btn-outline-primary">
                                        Baca Selengkapnya
                                    </a>
                                    <button class="btn btn-sm btn-outline-danger float-end unlike-btn" 
                                            data-article-id="<?php echo $article['id']; ?>">
                                        <i class="bi bi-heart-fill"></i> Batal Suka
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <!-- Empty State -->
                <div class="col-12">
                    <div class="empty-state">
                        <i class="bi bi-heart"></i>
                        <h3>Belum Ada Artikel yang Disukai</h3>
                        <p class="mb-4">Anda belum menyukai artikel apapun. Mulai jelajahi artikel menarik sekarang!</p>
                        <a href="../article.php" class="btn btn-primary">
                            <i class="bi bi-compass"></i> Jelajahi Artikel
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <nav aria-label="Page navigation" class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>">
                                <i class="bi bi-chevron-left"></i> Sebelumnya
                            </a>
                        </li>
                    <?php endif; ?>
                    
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>">
                                <?php echo $i; ?>
                            </a>
                        </li>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>">
                                Selanjutnya <i class="bi bi-chevron-right"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        <?php endif; ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Unlike article
        document.querySelectorAll('.unlike-btn').forEach(button => {
            button.addEventListener('click', function() {
                const articleId = this.dataset.articleId;
                const card = this.closest('.article-card');
                
                if (confirm('Anda yakin ingin menghapus artikel ini dari daftar suka?')) {
                    fetch('unlike_article.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'article_id=' + articleId
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            card.style.opacity = '0.5';
                            setTimeout(() => {
                                card.remove();
                                // Reload jika tidak ada artikel lagi
                                if (document.querySelectorAll('.article-card').length === 0) {
                                    location.reload();
                                }
                            }, 300);
                        } else {
                            alert(data.message || 'Gagal menghapus!');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Terjadi kesalahan!');
                    });
                }
            });
        });
        
        // Search functionality
        document.getElementById('searchInput').addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const articles = document.querySelectorAll('.article-card');
            
            articles.forEach(article => {
                const title = article.querySelector('.card-title').textContent.toLowerCase();
                const excerpt = article.querySelector('.card-text').textContent.toLowerCase();
                
                if (title.includes(searchTerm) || excerpt.includes(searchTerm)) {
                    article.style.display = 'block';
                } else {
                    article.style.display = 'none';
                }
            });
        });
    </script>
</body>
</html> 