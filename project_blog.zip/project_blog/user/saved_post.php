<?php
session_start();
require_once '../config/database.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Buat tabel saved_posts jika belum ada
$check_table = "SHOW TABLES LIKE 'saved_posts'";
$table_result = mysqli_query($konek, $check_table);

if (mysqli_num_rows($table_result) == 0) {
    // Buat tabel saved_posts
    $create_table = "CREATE TABLE saved_posts (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        article_id INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_save (user_id, article_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (article_id) REFERENCES articles(id) ON DELETE CASCADE
    )";
    
    mysqli_query($konek, $create_table);
}

// Pagination
$limit = 12; // Jumlah artikel per halaman
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Hitung total artikel yang disimpan
$total_query = "SELECT COUNT(*) as total 
                FROM saved_posts sp 
                JOIN articles a ON sp.article_id = a.id 
                WHERE sp.user_id = '$user_id' AND a.is_published = 1";
$total_result = mysqli_query($konek, $total_query);
$total_data = mysqli_fetch_assoc($total_result);
$total_articles = $total_data['total'];
$total_pages = ceil($total_articles / $limit);

// Ambil artikel yang disimpan
$query = "SELECT a.*, 
                 c.name as category_name,
                 c.slug as category_slug,
                 ad.username as author_name,
                 sp.created_at as saved_at,
                 COUNT(DISTINCT al.id) as like_count,
                 COUNT(DISTINCT cm.id) as comment_count
          FROM saved_posts sp
          JOIN articles a ON sp.article_id = a.id
          LEFT JOIN categories c ON a.category_id = c.id
          LEFT JOIN admins ad ON a.author_id = ad.id
          LEFT JOIN article_likes al ON a.id = al.article_id
          LEFT JOIN comments cm ON a.id = cm.article_id AND cm.is_approved = 1
          WHERE sp.user_id = '$user_id' 
            AND a.is_published = 1
            AND a.published_at IS NOT NULL
          GROUP BY a.id
          ORDER BY sp.created_at DESC
          LIMIT $limit OFFSET $offset";

$result = mysqli_query($konek, $query);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Artikel Tersimpan - BlogKu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .hero-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 60px 0;
            margin-bottom: 40px;
            border-radius: 0 0 20px 20px;
        }
        .article-card {
            border: none;
            border-radius: 15px;
            overflow: hidden;
            transition: all 0.3s ease;
            margin-bottom: 25px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            height: 100%;
        }
        .article-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }
        .article-image {
            height: 180px;
            object-fit: cover;
            width: 100%;
        }
        .card-body {
            padding: 20px;
        }
        .category-badge {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 3px 12px;
            border-radius: 15px;
            font-size: 0.75rem;
            text-decoration: none;
            display: inline-block;
            margin-bottom: 10px;
        }
        .card-title {
            font-size: 1.1rem;
            font-weight: 600;
            line-height: 1.4;
            margin-bottom: 10px;
        }
        .card-title a {
            color: #333;
            text-decoration: none;
        }
        .card-title a:hover {
            color: #667eea;
        }
        .card-text {
            color: #666;
            font-size: 0.9rem;
            line-height: 1.5;
            margin-bottom: 15px;
        }
        .article-meta {
            color: #6c757d;
            font-size: 0.8rem;
        }
        .saved-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background: rgba(255, 193, 7, 0.95);
            color: #000;
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 0.7rem;
            font-weight: 500;
            z-index: 2;
        }
        .empty-state {
            text-align: center;
            padding: 80px 20px;
            color: #6c757d;
        }
        .empty-state i {
            font-size: 5rem;
            margin-bottom: 20px;
            color: #dee2e6;
        }
        .view-options {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        .btn-view {
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
        }
        .btn-view.active {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
        }
        .unsave-btn {
            color: #ffc107;
            cursor: pointer;
            transition: color 0.3s;
        }
        .unsave-btn:hover {
            color: #e0a800;
        }
        .pagination .page-item.active .page-link {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-color: #667eea;
        }
    </style>
</head>
<body>
    <?php include '../includes/user_navbar.php'; ?>
    
    <!-- Hero Section -->
    <div class="hero-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8 mx-auto text-center">
                    <h1><i class="bi bi-bookmark-star-fill"></i> Artikel Tersimpan</h1>
                    <p class="lead">Kumpulan artikel yang telah Anda simpan untuk dibaca nanti</p>
                    <div class="stats">
                        <span class="badge bg-light text-dark me-2">
                            <i class="bi bi-bookmark"></i> <?php echo $total_articles; ?> Artikel
                        </span>
                        <span class="badge bg-light text-dark">
                            <i class="bi bi-folder"></i> <?php echo ceil($total_articles / 5); ?> Folder
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="container mb-5">
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['message']; unset($_SESSION['message']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <!-- View Options -->
        <div class="view-options">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <div class="btn-group" role="group">
                        <button type="button" class="btn btn-view active" data-view="grid">
                            <i class="bi bi-grid-3x3-gap"></i> Grid
                        </button>
                        <button type="button" class="btn btn-view" data-view="list">
                            <i class="bi bi-list-ul"></i> List
                        </button>
                    </div>
                    
                    <div class="btn-group ms-3" role="group">
                        <button type="button" class="btn btn-outline-secondary btn-sm" data-sort="recent">
                            <i class="bi bi-clock"></i> Terbaru
                        </button>
                        <button type="button" class="btn btn-outline-secondary btn-sm" data-sort="popular">
                            <i class="bi bi-fire"></i> Populer
                        </button>
                    </div>
                </div>
                <div class="col-md-6 text-end">
                    <div class="input-group" style="max-width: 300px; float: right;">
                        <input type="text" class="form-control" placeholder="Cari artikel tersimpan..." id="searchSaved">
                        <button class="btn btn-primary" type="button">
                            <i class="bi bi-search"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Daftar Artikel -->
        <div class="row" id="articlesContainer">
            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php while ($article = mysqli_fetch_assoc($result)): ?>
                    <div class="col-md-4 col-lg-3 mb-4">
                        <div class="card article-card">
                            <span class="saved-badge">
                                <i class="bi bi-bookmark-fill"></i> Tersimpan
                            </span>
                            
                            <?php if ($article['featured_image']): ?>
                                <img src="../uploads/<?php echo $article['featured_image']; ?>" 
                                     class="article-image" 
                                     alt="<?php echo htmlspecialchars($article['title']); ?>">
                            <?php else: ?>
                                <div class="article-image bg-light d-flex align-items-center justify-content-center">
                                    <i class="bi bi-file-text text-muted" style="font-size: 2rem;"></i>
                                </div>
                            <?php endif; ?>
                            
                            <div class="card-body">
                                <?php if ($article['category_name']): ?>
                                    <a href="../blog.php?category=<?php echo $article['category_slug']; ?>" 
                                       class="category-badge">
                                        <?php echo $article['category_name']; ?>
                                    </a>
                                <?php endif; ?>
                                
                                <h5 class="card-title">
                                    <a href="../post.php?slug=<?php echo $article['slug']; ?>" 
                                       class="text-decoration-none">
                                        <?php echo htmlspecialchars($article['title']); ?>
                                    </a>
                                </h5>
                                
                                <p class="card-text">
                                    <?php echo substr(strip_tags($article['excerpt'] ?: $article['content']), 0, 80); ?>...
                                </p>
                                
                                <div class="article-meta d-flex justify-content-between align-items-center">
                                    <div>
                                        <small>
                                            <i class="bi bi-person"></i> <?php echo $article['author_name']; ?>
                                        </small>
                                    </div>
                                    <div>
                                        <small class="text-muted">
                                            <i class="bi bi-calendar"></i> 
                                            <?php echo date('d M', strtotime($article['saved_at'])); ?>
                                        </small>
                                    </div>
                                </div>
                                
                                <div class="d-flex justify-content-between align-items-center mt-3">
                                    <a href="../post.php?slug=<?php echo $article['slug']; ?>" 
                                       class="btn btn-sm btn-outline-primary">
                                        Baca
                                    </a>
                                    
                                    <div>
                                        <small class="text-muted me-2">
                                            <i class="bi bi-heart"></i> <?php echo $article['like_count']; ?>
                                        </small>
                                        <small class="text-muted">
                                            <i class="bi bi-chat"></i> <?php echo $article['comment_count']; ?>
                                        </small>
                                    </div>
                                    
                                    <button class="btn btn-sm unsave-btn" 
                                            data-article-id="<?php echo $article['id']; ?>"
                                            title="Hapus dari tersimpan">
                                        <i class="bi bi-bookmark-x-fill"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <!-- Empty State -->
                <div class="col-12">
                    <div class="empty-state">
                        <i class="bi bi-bookmark-star"></i>
                        <h3>Belum Ada Artikel Tersimpan</h3>
                        <p class="mb-4">Simpan artikel menarik untuk dibaca nanti dengan mengklik tombol bookmark.</p>
                        <div class="d-grid gap-2 d-md-flex justify-content-center">
                            <a href="../article.php" class="btn btn-primary">
                                <i class="bi bi-compass"></i> Jelajahi Artikel
                            </a>
                            <a href="../blog.php" class="btn btn-outline-primary ms-2">
                                <i class="bi bi-lightning"></i> Artikel Populer
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        
        <!-- Pagination -->
        <?php if ($total_pages > 1): ?>
            <nav aria-label="Page navigation" class="mt-4">
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page - 1; ?>">
                                <i class="bi bi-chevron-left"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                    
                    <?php 
                    $start = max(1, $page - 2);
                    $end = min($total_pages, $page + 2);
                    
                    for ($i = $start; $i <= $end; $i++): ?>
                        <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>">
                                <?php echo $i; ?>
                            </a>
                        </li>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?page=<?php echo $page + 1; ?>">
                                <i class="bi bi-chevron-right"></i>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        <?php endif; ?>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle view between grid and list
        document.querySelectorAll('[data-view]').forEach(button => {
            button.addEventListener('click', function() {
                // Update active button
                document.querySelectorAll('[data-view]').forEach(btn => {
                    btn.classList.remove('active');
                });
                this.classList.add('active');
                
                // Change view
                const view = this.dataset.view;
                const container = document.getElementById('articlesContainer');
                
                if (view === 'list') {
                    container.classList.remove('row');
                    container.classList.add('list-view');
                    document.querySelectorAll('.article-card').forEach(card => {
                        card.style.height = 'auto';
                    });
                } else {
                    container.classList.add('row');
                    container.classList.remove('list-view');
                }
            });
        });
        
        // Unsave article
        document.querySelectorAll('.unsave-btn').forEach(button => {
            button.addEventListener('click', function() {
                const articleId = this.dataset.articleId;
                const card = this.closest('.article-card');
                
                if (confirm('Hapus artikel ini dari daftar tersimpan?')) {
                    fetch('unsave_article.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'article_id=' + articleId
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            card.style.transform = 'scale(0.9)';
                            card.style.opacity = '0';
                            
                            setTimeout(() => {
                                card.remove();
                                
                                // Reload if no articles left
                                if (document.querySelectorAll('.article-card').length === 0) {
                                    location.reload();
                                }
                            }, 300);
                            
                            // Show success message
                            const alert = document.createElement('div');
                            alert.className = 'alert alert-success alert-dismissible fade show position-fixed top-0 end-0 m-3';
                            alert.style.zIndex = '1050';
                            alert.innerHTML = `
                                <i class="bi bi-check-circle"></i> Artikel berhasil dihapus dari tersimpan
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            `;
                            document.body.appendChild(alert);
                            
                            setTimeout(() => {
                                alert.remove();
                            }, 3000);
                        } else {
                            alert(data.message || 'Gagal menghapus!');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Terjadi kesalahan!');
                    });
                }
            });
        });
        
        // Search functionality
        document.getElementById('searchSaved').addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const articles = document.querySelectorAll('.article-card');
            
            articles.forEach(article => {
                const title = article.querySelector('.card-title').textContent.toLowerCase();
                const excerpt = article.querySelector('.card-text').textContent.toLowerCase();
                
                if (title.includes(searchTerm) || excerpt.includes(searchTerm)) {
                    article.style.display = 'block';
                } else {
                    article.style.display = 'none';
                }
            });
        });
        
        // Sort functionality
        document.querySelectorAll('[data-sort]').forEach(button => {
            button.addEventListener('click', function() {
                const sort = this.dataset.sort;
                // Implement sort logic here or reload page with sort parameter
                window.location.href = `?sort=${sort}`;
            });
        });
    </script>
</body>
</html>