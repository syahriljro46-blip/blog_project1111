<?php
session_start();

// Hapus semua session user
unset($_SESSION['user_id']);
unset($_SESSION['user_username']);
unset($_SESSION['user_email']);
unset($_SESSION['user_name']);
unset($_SESSION['user_profile']);

// Redirect ke halaman login
header("Location: login.php");
exit();
?>