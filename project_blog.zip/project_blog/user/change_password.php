<?php
session_start();
require_once '../config/database.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $current_password = mysqli_real_escape_string($konek, $_POST['current_password']);
    $new_password = mysqli_real_escape_string($konek, $_POST['new_password']);
    $confirm_password = mysqli_real_escape_string($konek, $_POST['confirm_password']);
    
    // Validasi
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = "Semua field harus diisi!";
    } elseif ($new_password != $confirm_password) {
        $error = "Password baru tidak cocok!";
    } elseif (strlen($new_password) < 6) {
        $error = "Password minimal 6 karakter!";
    } else {
        // Ambil password lama dari database
        $query = "SELECT password FROM users WHERE id = '$user_id'";
        $result = mysqli_query($konek, $query);
        $user = mysqli_fetch_assoc($result);
        
        // Verifikasi password lama
        if (password_verify($current_password, $user['password'])) {
            // Hash password baru
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            // Update password
            $update_query = "UPDATE users SET password = '$hashed_password' WHERE id = '$user_id'";
            if (mysqli_query($konek, $update_query)) {
                $message = "Password berhasil diubah!";
                
                // Kirim notifikasi email (opsional)
                // ...
            } else {
                $error = "Gagal mengubah password: " . mysqli_error($konek);
            }
        } else {
            $error = "Password saat ini salah!";
        }
    }
}

// Ambil data user untuk ditampilkan
$user_query = "SELECT username, email, full_name FROM users WHERE id = '$user_id'";
$user_result = mysqli_query($konek, $user_query);
$user_data = mysqli_fetch_assoc($user_result);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ubah Password - BlogKu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .card {
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px 15px 0 0 !important;
        }
        .form-control:focus {
            border-color: #764ba2;
            box-shadow: 0 0 0 0.25rem rgba(118, 75, 162, 0.25);
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            padding: 10px 30px;
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }
        .user-info {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <?php include '../includes/user_navbar.php'; ?>
    
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center py-3">
                        <h3><i class="bi bi-shield-lock"></i> Ubah Password</h3>
                    </div>
                    <div class="card-body p-4">
                        <?php if ($message): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo $message; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($error): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo $error; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>
                        
                        <!-- Info User -->
                        <div class="user-info mb-4">
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong><i class="bi bi-person"></i> Username:</strong> <?php echo htmlspecialchars($user_data['username']); ?></p>
                                    <p><strong><i class="bi bi-envelope"></i> Email:</strong> <?php echo htmlspecialchars($user_data['email']); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong><i class="bi bi-person-badge"></i> Nama Lengkap:</strong> <?php echo htmlspecialchars($user_data['full_name']); ?></p>
                                    <p><strong><i class="bi bi-calendar"></i> Terakhir diubah:</strong> <?php echo date('d-m-Y H:i'); ?></p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Form Ubah Password -->
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="current_password" class="form-label">
                                    <i class="bi bi-key"></i> Password Saat Ini
                                </label>
                                <input type="password" class="form-control" id="current_password" 
                                       name="current_password" required>
                                <div class="form-text">Masukkan password Anda saat ini</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="new_password" class="form-label">
                                    <i class="bi bi-key-fill"></i> Password Baru
                                </label>
                                <input type="password" class="form-control" id="new_password" 
                                       name="new_password" required>
                                <div class="form-text">Minimal 6 karakter</div>
                            </div>
                            
                            <div class="mb-4">
                                <label for="confirm_password" class="form-label">
                                    <i class="bi bi-key-fill"></i> Konfirmasi Password Baru
                                </label>
                                <input type="password" class="form-control" id="confirm_password" 
                                       name="confirm_password" required>
                                <div class="form-text">Ulangi password baru</div>
                            </div>
                            
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <a href="dashboard.php" class="btn btn-secondary me-md-2">
                                    <i class="bi bi-arrow-left"></i> Kembali
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-check-circle"></i> Ubah Password
                                </button>
                            </div>
                        </form>
                        
                        <!-- Tips Keamanan -->
                        <div class="mt-4 p-3 bg-light border rounded">
                            <h5><i class="bi bi-lightbulb"></i> Tips Keamanan Password:</h5>
                            <ul class="mb-0">
                                <li>Gunakan kombinasi huruf besar, kecil, angka, dan simbol</li>
                                <li>Minimal 8 karakter untuk keamanan optimal</li>
                                <li>Jangan gunakan password yang sama dengan akun lain</li>
                                <li>Ganti password secara berkala setiap 3-6 bulan</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Toggle show/hide password
        document.addEventListener('DOMContentLoaded', function() {
            const togglePassword = (inputId) => {
                const input = document.getElementById(inputId);
                if (input.type === 'password') {
                    input.type = 'text';
                } else {
                    input.type = 'password';
                }
            };
            
            // Add toggle buttons
            ['current_password', 'new_password', 'confirm_password'].forEach(id => {
                const input = document.getElementById(id);
                const wrapper = input.parentElement;
                const toggleBtn = document.createElement('button');
                toggleBtn.type = 'button';
                toggleBtn.className = 'btn btn-outline-secondary btn-sm position-absolute end-0 top-50 translate-middle-y me-2';
                toggleBtn.innerHTML = '<i class="bi bi-eye"></i>';
                toggleBtn.style.zIndex = '5';
                wrapper.style.position = 'relative';
                wrapper.appendChild(toggleBtn);
                
                toggleBtn.addEventListener('click', () => togglePassword(id));
            });
        });
    </script>
</body>
</html>