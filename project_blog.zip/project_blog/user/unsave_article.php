<?php
session_start();
require_once '../config/database.php';

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['success' => false, 'message' => 'Silakan login terlebih dahulu']);
    exit();
}

// Cek apakah request adalah POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('HTTP/1.1 405 Method Not Allowed');
    echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan']);
    exit();
}

// Validasi input
if (!isset($_POST['article_id']) || empty($_POST['article_id'])) {
    echo json_encode(['success' => false, 'message' => 'ID artikel tidak valid']);
    exit();
}

$user_id = $_SESSION['user_id'];
$article_id = mysqli_real_escape_string($konek, $_POST['article_id']);

// Verifikasi artikel exist
$article_check = "SELECT id FROM articles WHERE id = '$article_id' AND is_published = 1";
$article_result = mysqli_query($konek, $article_check);

if (mysqli_num_rows($article_result) == 0) {
    echo json_encode(['success' => false, 'message' => 'Artikel tidak ditemukan']);
    exit();
}

// Hapus dari saved_posts
$delete_query = "DELETE FROM saved_posts WHERE user_id = '$user_id' AND article_id = '$article_id'";

if (mysqli_query($konek, $delete_query)) {
    // Update cache atau statistik jika diperlukan
    $affected_rows = mysqli_affected_rows($konek);
    
    if ($affected_rows > 0) {
        // Log aktivitas (opsional)
        $log_query = "INSERT INTO user_activity (user_id, activity_type, target_id, details) 
                      VALUES ('$user_id', 'unsave_article', '$article_id', 'Menghapus artikel dari tersimpan')";
        mysqli_query($konek, $log_query);
        
        echo json_encode([
            'success' => true, 
            'message' => 'Artikel berhasil dihapus dari tersimpan',
            'removed' => true
        ]);
    } else {
        echo json_encode([
            'success' => false, 
            'message' => 'Artikel tidak ditemukan di daftar tersimpan'
        ]);
    }
} else {
    echo json_encode([
        'success' => false, 
        'message' => 'Gagal menghapus: ' . mysqli_error($konek)
    ]);
}
?>