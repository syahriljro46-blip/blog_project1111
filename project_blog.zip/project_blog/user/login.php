<?php
session_start();
require_once '../config/database.php';

// Jika sudah login, redirect ke dashboard
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

// Kosongkan error - TIDAK ADA PESAN ERROR SPESIFIK
$username_value = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $username_value = htmlspecialchars($username);
    
    // Cari user dengan username atau email
    $sql = "SELECT * FROM users WHERE username = '$username' OR email = '$username'";
    $result = mysqli_query($konek, $sql);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        
        // Verifikasi password
        if (password_verify($password, $user['password'])) {
            // Set session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_username'] = $user['username'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_profile'] = $user['profile_image'];
            
            // Redirect ke dashboard - TIDAK ADA PESAN ERROR
            header("Location: dashboard.php");
            exit();
        }
    }
    
    // Jika sampai sini, berarti login gagal
    // Tapi kita TIDAK tampilkan pesan error
    // Hanya reset form (username tetap disimpan untuk UX)
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk Akun - Blog</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 400px;
        }
        .logo {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo h1 {
            color: #333;
            margin: 0;
            font-size: 28px;
        }
        .logo p {
            color: #666;
            margin-top: 5px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
        }
        input {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e1e1e1;
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 16px;
            transition: border 0.3s;
        }
        input:focus {
            border-color: #f5576c;
            outline: none;
        }
        button {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: transform 0.2s;
        }
        button:hover {
            transform: translateY(-2px);
        }
        .options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 15px;
            font-size: 14px;
        }
        .remember {
            display: flex;
            align-items: center;
            gap: 5px;
            color: #666;
        }
        .forgot {
            color: #f5576c;
            text-decoration: none;
        }
        .forgot:hover {
            text-decoration: underline;
        }
        .register-link {
            text-align: center;
            margin-top: 25px;
            color: #666;
        }
        .register-link a {
            color: #f5576c;
            text-decoration: none;
            font-weight: 500;
        }
        .register-link a:hover {
            text-decoration: underline;
        }
        .demo-info {
            background: #e8f4ff;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            border-left: 4px solid #4dabf7;
            font-size: 14px;
        }
        .demo-info strong {
            color: #1971c2;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <h1>Selamat Datang Kembali</h1>
            <p>Masuk untuk melanjutkan membaca</p>
        </div>
        
        <!-- Info demo account -->
        <div class="demo-info">
            <strong>Akun demo:</strong><br>
            Username: johndoe<br>
            Password: password123
        </div>
        
        <form method="POST" action="" id="loginForm">
            <div class="form-group">
                <label>Username atau Email</label>
                <input type="text" name="username" required 
                       placeholder="Masukkan username atau email"
                       value="<?php echo $username_value; ?>">
            </div>
            
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required 
                       placeholder="Masukkan password">
            </div>
            
            <div class="options">
                <label class="remember">
                    <input type="checkbox" name="remember"> Ingat saya
                </label>
                <a href="#" class="forgot">Lupa password?</a>
            </div>
            
            <button type="submit">Masuk</button>
            
            <div class="register-link">
                Belum punya akun? <a href="register.php">Daftar di sini</a>
            </div>
        </form>
    </div>
    
    <script>
    // Form akan dikirim normal tanpa alert error
    document.getElementById('loginForm').addEventListener('submit', function(e) {
        // Tidak ada validasi tambahan
        // Form akan dikirim ke server
    });
    
    // Optional: Reset form pada page refresh
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
    
    // Auto focus pada input pertama
    document.querySelector('input[name="username"]').focus();
    </script>
</body>
</html>