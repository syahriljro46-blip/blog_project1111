<?php
// KONEKSI DATABASE - SUPER SIMPLE
$host = "localhost";
$user = "root";
$pass = "";
$db   = "project_blog";

// Konek ke database
$konek = mysqli_connect($host, $user, $pass, $db);

// Kalo gagal, tampilkan error sederhana
if(!$konek) {
    die("Gagal konek ke database. Cek XAMPP nyala atau belum!");
}

echo "<!-- Koneksi database berhasil -->";
?>